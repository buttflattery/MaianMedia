<?php
/**
 * Hello View for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'view.html.php');
/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewAlbums extends MaianViewDefault
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		$albums =& $this->get('Data');
		$message = str_replace( "\\n", " ", _msg_javascript15);
		JToolBarHelper::title(JText::_(_msg_albums20), 'albums.png' );
		JToolBarHelper::addNewX();
		JToolBarHelper::editListX();
		JToolBarHelper::deleteList($message, "delete_albums", "Delete");
		//JToolBarHelper::custom("add_tracks", 'add-tracks', 'add-tracks',  JText::_(_msg_header5), false);
		
		$this->assignRef('albums', $albums);

		parent::display($tpl);
	}
}