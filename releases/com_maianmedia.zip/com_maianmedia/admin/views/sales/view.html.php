<?php
/**
 * Hello View for Hello World Component
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'view.html.php');
/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewSales extends MaianViewDefault
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		$sales =& $this->get('Data');

		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__m15_settings");
		$settings = $db->loadObjectList();

		JToolBarHelper::title( JText::_(_msg_header7), 'sales.png' );
		//JToolBarHelper::deleteList('delete', _msg_sales14 );
		JToolBarHelper::deleteList(JText::_(_msg_javascript33), "delete", JText::_(_msg_script8));

		$this->assignRef('settings', $settings[0]);
		$this->assignRef('sales', $sales);

		parent::display($tpl);
	}
}