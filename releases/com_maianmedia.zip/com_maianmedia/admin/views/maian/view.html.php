<?php
/**
 * About and credits View for MaianMedia
 *
 * @package    MaianMedia
 * @subpackage MaianViewMaian
 * @link http://aretimes.com
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'view.html.php');
/**
 * Settings View
 *
 * @package    MaianMedia
 * @subpackage MaianViewMaian
 */
class MaianViewMaian extends MaianViewDefault
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		JToolBarHelper::title(JText::_(_msg_public_header6), 'about.png');
		include_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'tmpl'.DS.'about.php');
	}
}