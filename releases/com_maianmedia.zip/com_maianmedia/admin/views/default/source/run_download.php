<?php
defined('_JEXEC') or die('Restricted access'); 
require_once(JPATH_LIBRARIES.DS.'joomla'.DS.'factory.php');

$url = "http://www.aretimes.com/aretimes/downloads/Joomla%201.5.x/com_maianmedia.zip";
@set_time_limit(0); // Make sure we don't timeout while downloading
$config =& JFactory::getConfig();
$config_tmp_path = rtrim($config->getValue('config.tmp_path'), '/');
//$file_path =$this->downloadRemoteFile($url,$config_tmp_path);

jimport('joomla.filesystem.archive');
//if(JArchive::extract($config_tmp_path.DS.$file_path, $config_tmp_path)){
	echo'<span id="update_text">The zip file has been downloaded to your server!!!</span>
			<div class="button2-right">
				<div class="start">
					<a id="getChecked" href="javascript:ajaxRequest(\'run_update\', \'index.php?option=com_maianmedia&amp;task=tools&amp;format=raw&amp;tool=run_update\', 1)"
									title="Start" onclick="">Run Update</a></div>
				</div><div id="run_update"></div>';
/*}else{
	jimport( 'joomla.error.error' );
	echo JError::getErrors();
}*/
?>

