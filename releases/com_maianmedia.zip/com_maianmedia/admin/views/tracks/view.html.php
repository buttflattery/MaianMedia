<?php
/**
 * Hello View for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'view.html.php');
/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewTracks extends MaianViewDefault
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		$albums =& $this->get('Albums');
		
		JToolBarHelper::title(   JText::_(_msg_header6), 'tracks.png' );
		//JToolBarHelper::addNewX();
		//JToolBarHelper::editListX();
		//JToolBarHelper::deleteList();

		$this->assignRef('albums', $albums);

		parent::display($tpl);
	}
}