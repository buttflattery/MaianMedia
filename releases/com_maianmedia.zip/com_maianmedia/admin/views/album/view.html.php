<?php
/**
 * Hello View for Hello World Component
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'view.html.php');
/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewAlbum extends MaianViewDefault
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		$album =& $this->get('Data');
		if(isset($album->id)){
			$isNew		= ($album->id < 1);
		}else{
			$isNew = false;
		}
		$text = $isNew ? JText::_('New') : JText::_( 'Edit' );
		JToolBarHelper::title(JText::_(_msg_albums2 ).': <small><small>[ ' . $text.' ]</small></small>', 'albums.png' );
		JToolBarHelper::save();
		JToolBarHelper::apply();

		if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}

		$this->assignRef('album', $album);

		parent::display($tpl);
	}

}