<?php
/**
* @version		1.0.0
* @package		AcePolls
* @subpackage	AcePolls
* @copyright	2009-2011 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

$controller	= JRequest::getCmd('controller', 'maianmedia');

JHTML::_('behavior.switcher');

// Load submenus
$controllers = array('&task=about' => JText::_('About'),
'&controller=settings&view=settings'=> JText::_('Settings'),
'&controller=category&view=category'=> JText::_('Categories'),
'&controller=albums&view=albums'=> JText::_('Manage Albums'),
'&controller=tracks&view=track&task=add'=> JText::_('Add Tracks'),
'&controller=tracks&view=tracks&task=manage'=> JText::_('Manage Tracks'),
'&controller=sales&view=sales'=> JText::_('View Sales'),
'&controller=sales&view=search'=> JText::_('Search Sales'),
'&controller=stats&view=stats'=> JText::_('Statistics'),
'&task=tools'=> JText::_('Tools'));	

foreach ($controllers as $key => $val) {
	$active	= ($controller == $key);
	JSubMenuHelper::addEntry($val, 'index.php?option=com_maianmedia'.$key, $active);
}
?>