<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
$md5='8b4c1bc8a6be9c2df10eb9063a39b607';?>