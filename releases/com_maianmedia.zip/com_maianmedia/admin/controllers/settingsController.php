<?php
/**
 * @package		Joomla
 * @subpackage	com_maianmedia
 * @copyright	Copyright (C) Vamba & Matthew Thomson. All rights reserved.
 * @license		GNU/GPL
 * @author 		Arelowo Alao (aretimes.com) & David Bennet (maianscriptworld.co.uk)
 * @based on  	com_ignitegallery
 * @author 		Matthew Thomson (ignitejoomlaextensions.com)
 * Joomla! and Maian Music are free software. You must attribute the work in the manner
 * specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 */
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * Hello World Component Controller
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianControllerSettings extends MaianControllerDefault
{
	/**
	 * The xml params element
	 *
	 * @access	private
	 * @var		object
	 * @since	1.5
	 */
	var $_xml = null;

	/**
	 * loaded elements
	 *
	 * @access	private
	 * @var		array
	 * @since	1.5
	 */
	var $_elements = array();

	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		//$this->registerTask( 'save' );
	}

	function save(){

		$tools = JRequest::getVar( 'tool');

		$msg = $this->saveData();

		// Check the table in so it can be edited.... we are done with it anyway
		if(isset($tools)){
			$link = 'index.php?option=com_maianmedia&task=tools';
		}else{
			$link = 'index.php?option=com_maianmedia&controller=settings&view=settings';
		}

		$this->setRedirect($link, $msg);
	}

	function apply(){

		$tools = JRequest::getVar( 'tool');

		$msg = $this->saveData();

		// Check the table in so it can be edited.... we are done with it anyway
		if(isset($tools)){
			$link = 'index.php?option=com_maianmedia&task=tools&tool=custom';
		}else{
			$link = 'index.php?option=com_maianmedia&controller=settings&view=settings';
		}

		$this->setRedirect($link, $msg);
	}
	/* save a record (and redirect to main page)
	 * @return void
	 */
	function saveData()
	{
		$model = $this->getModel('Settings');
		
		$this->updatePlayerParams();

		$paypal_mode = JRequest::getVar( 'paypal_mode');
		$log_errors = JRequest::getVar( 'log_errors');
		$ssl_enabled = JRequest::getVar( 'ssl_enabled');
		$smtp = JRequest::getVar( 'smtp');
		$enable_captcha = JRequest::getVar( 'enable_captcha');
		$days = JRequest::getVar( 'days');
		$minpay = JRequest::getVar( 'minpay');
		$ajax = JRequest::getVar( 'ajax');
		$search = JRequest::getVar( 'search');
		$tools = JRequest::getVar( 'tool');
		$download= JRequest::getVar('show_download');
		$nav= JRequest::getVar('show_nav');
		$reset= JRequest::getVar('reset');
		$append_url= JRequest::getVar('append_url');
		$enlargeit= JRequest::getVar('enlargeit');
		$select_lang= JRequest::getVar('select_lang');
		$hide_lightbox= JRequest::getVar('hide_lightbox');

		if(!isset($tools)){

			if($reset == '1'){
				$this->resetAllAlbumHits();
			}

			if(!isset($paypal_mode)){
				JRequest::setVar('paypal_mode', '0');
			}

			if(!isset($log_errors)){
				JRequest::setVar('log_errors', '0');
			}

			if(!isset($ssl_enabled)){
				JRequest::setVar('ssl_enabled', '0');
			}

			if(!isset($smtp)){
				JRequest::setVar('smtp', '0');
			}

			if(!isset($ajax)){
				JRequest::setVar('ajax', '0');
			}

			if(!isset($search)){
				JRequest::setVar('search', '0');
			}

			if(!isset($download)){
				JRequest::setVar('show_download', '0');
			}

			if(!isset($append_url)){
				JRequest::setVar('append_url', '0');
			}

			if(!isset($enlargeit)){
				JRequest::setVar('enlargeit', '0');
			}

			if(!isset($nav)){
				JRequest::setVar('show_nav', '0');
			}

			if(!isset($select_lang)){
				JRequest::setVar('select_lang', '0');
			}

			if(!isset($hide_lightbox)){
				JRequest::setVar('hide_lightbox', '0');
			}

			if(!isset($enable_captcha)){
				JRequest::setVar('enable_captcha', '0');
			}

			if($days == '0' || !isset($days)){
				JRequest::setVar('days', '14');
			}

			if($minpay == '0' || !isset($minpay)){
				JRequest::setVar('minpay', '10.00');
			}
		}

		if ($model->store($_POST)) {
			if(!isset($tools)){
				return JText::_( 'Settings Saved!' );
			}else{
				return JText::_( 'Custom Page Text Saved!' );
			}

		}else{
			return JText::_( 'There was an error saving the settings' );
		}


	}

	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		// loading view for this task
		//$group_path = JPATH_COMPONENT.DS.'views'.DS.'default.view.php';
		//require_once($group_path);
		JRequest::setVar( 'layout', 'form'  );


		parent::display();
	}

	function tplParams(){
		require_once(JPATH_COMPONENT.DS.'views'.DS.'settings'.DS.'tmpl'.DS.'tplParams.php');
	}

	function renderSettingsAjax(){

		$player = JRequest::getVar('player_');
		
		$XMLFile = JPATH_COMPONENT_SITE.DS.'players'.DS.$player.DS.'playerDetails.xml';
		$data = $this->_SETTINGS->player_params;
		echo '<div id="settings_player">'.$this->renderSettings($XMLFile, $this->_SETTINGS->player_params, false, 'player-params').'</div>';
	}

	/**
	 * Render
	 *
	 * @access	public
	 * @param	string	The name of the control, or the default text area if a setup file is not found
	 * @return	string	HTML
	 * @since	1.5
	 */
	function renderSettings($path, $data, $embed=false, $name='params')
	{
		$xml = & JFactory::getXMLParser('Simple');

		if ($xml->loadFile($path))
		{
			if ($params = & $xml->document->params) {
				foreach ($params as $param)
				{
					$this->setXML( $param );
					$result = true;
				}
			}
		}

		$ns = $this->stringToObject($data);
		$params = $this->getParams($name, '_default', $ns);
		$html = array ();

		$html[] = '<table width="100%" class="paramlist admintable" cellspacing="1">';

		if ($description = $this->_xml['_default']->attributes('description')) {
			// add the params description to the display
			$desc	= JText::_($description);
			$html[]	= '<tr><td class="paramlist_description" colspan="2">'.$desc.'</td></tr>';
		}

		foreach ($params as $param)
		{
			$html[] = '<tr>';

			if ($param[0]) {
				$html[] = '<td width="40%" class="paramlist_key"><span class="editlinktip">'.$param[0].'</span></td>';
				$html[] = '<td class="paramlist_value">'.$param[1].'</td>';
			} else {
				$html[] = '<td class="paramlist_value" colspan="2">'.$param[1].'</td>';
			}

			$html[] = '</tr>';
		}

		if (count($params) < 1) {
			$html[] = $tr."<td colspan=\"2\"><i>".JText::_('There are no Parameters for this item')."</i></td></tr>";
		}

		$html[] = '</table>';
		
		return implode("\n", $html);
	}

	/**
	 * Sets the XML object from custom xml files
	 *
	 * @access	public
	 * @param	object	An XML object
	 * @since	1.5
	 */
	function setXML( &$xml )
	{
		if (is_object( $xml ))
		{
			if ($group = $xml->attributes( 'group' )) {
				$this->_xml[$group] = $xml;
			} else {
				$this->_xml['_default'] = $xml;
			}
			if ($dir = $xml->attributes( 'addpath' )) {
				$this->addElementPath( JPATH_ROOT . str_replace('/', DS, $dir) );
			}
		}
	}

	/**
	 * Render a parameter type
	 *
	 * @param	object	A param tag node
	 * @param	string	The control name
	 * @return	array	Any array of the label, the form element and the tooltip
	 * @since	1.5
	 */
	function getParam(&$node, $control_name = 'params', $group = '_default', $values)
	{
		//get the type of the parameter
		$type = $node->attributes('type');

		//remove any occurance of a mos_ prefix
		$type = str_replace('mos_', '', $type);

		$element =& $this->loadElement($type);

		// error happened
		if ($element === false)
		{
			$result = array();
			$result[0] = $node->attributes('name');
			$result[1] = JText::_('Element not defined for type').' = '.$type;
			$result[5] = $result[0];
			return $result;
		}
		
		//get value
		$property = $node->attributes('name');

		if (isset($values->$property)) {
			$value = $values->$property;
		}else{
			$value = $this->get($node->attributes('name'), $node->attributes('default'), $group);
		}
		
		return $this->renderElement($node, $value, $control_name, $element);
	}

	/**
	 * Render all parameters
	 *
	 * @access	public
	 * @param	string	The name of the control, or the default text area if a setup file is not found
	 * @return	array	Aarray of all parameters, each as array Any array of the label, the form element and the tooltip
	 * @since	1.5
	 */
	function getParams($name = 'params', $group = '_default', $values)
	{
		if (!isset($this->_xml[$group])) {
			return false;
		}
		$results = array();
		foreach ($this->_xml[$group]->children() as $param)  {
			$results[] = $this->getParam($param, $name, $group, $values);
		}
		return $results;
	}

	function renderElement(&$xmlElement, $value, $control_name = 'params', $element)
	{
		$name	= $xmlElement->attributes('name');
		$label	= $xmlElement->attributes('label');
		$descr	= $xmlElement->attributes('description');
		//make sure we have a valid label
		$label = $label ? $label : $name;
		$result[0] = $this->fetchTooltip($label, $descr, $xmlElement, $control_name, $name);
		$result[1] = $element->fetchElement($name, $value, $xmlElement, $control_name);
		$result[2] = $descr;
		$result[3] = $label;
		$result[4] = $value;
		$result[5] = $name;

		return $result;
	}

	/**
	 * Loads a element type
	 *
	 * @access	public
	 * @param	string	elementType
	 * @return	object
	 * @since	1.5
	 */
	function &loadElement( $type, $new = false )
	{
		$false = false;
		$signature = md5($type);

		if( (isset( $this->_elements[$signature] ) && !is_a($this->_elements[$signature], '__PHP_Incomplete_Class'))  && $new === false ) {
			return	$this->_elements[$signature];
		}

		$location = JPATH_COMPONENT.DS.'utilities'.DS.'template'.DS.'elements'.DS.$type.'.php';

		if(file_exists($location)){
			include_once($location);
		}

		$elementClass	=	'JElement'.$type;
		if( !class_exists( $elementClass ) )
		{
			if( isset( $this->_elementPath ) ) {
				$dirs = $this->_elementPath;
			} else {
				$dirs = array();
			}

			$file = JFilterInput::clean(str_replace('_', DS, $type).'.php', 'path');

			jimport('joomla.filesystem.path');
			if ($elementFile = JPath::find($dirs, $file)) {
				include_once $elementFile;
			} else {
				return $false;
			}
		}

		if( !class_exists( $elementClass ) ) {
			return $false;
		}

		$this->_elements[$signature] = new $elementClass($this);

		return $this->_elements[$signature];
	}

	function fetchTooltip($label, $description, &$xmlElement, $control_name='', $name='')
	{
		$output = '<label id="'.$control_name.$name.'-lbl" for="'.$control_name.$name.'"';
		if ($description) {
			$output .= ' class="hasTip" title="'.JText::_($label).'::'.JText::_($description).'">';
		} else {
			$output .= '>';
		}
		$output .= JText::_( $label ).'</label>';

		return $output;
	}

	function updateParams(){
		$params = JRequest::getVar('params');
		$lines = "";
		$bool = true;

		foreach ($params  as $k => $v)
		{
			if($bool){
				$lines =$k.'='.$v;
				$bool = false;
			}else{
				$lines .="\r\n".$k.'='.$v;
			}

		}

		$db =& JFactory::getDBO();

		$db->setQuery("UPDATE #__m15_settings SET extra_params='$lines' WHERE id='1';");
		$db->query();

		require_once(JPATH_COMPONENT.DS.'views'.DS.'settings'.DS.'tmpl'.DS.'tplParams.php');
	}

	function resetAllAlbumHits()
	{

		$db =& JFactory::getDBO();
		$db->setQuery("UPDATE #__m15_albums SET hits = '0' WHERE is_album = '1'");
		$db->query();
	}

	function display_player()
	{
		jimport( 'joomla.environment.uri' );

		$uri =& JURI::getInstance();
		$root_url = $uri->root(); //root url
		$root_base = $uri->base(); //base url
		$root_current = $uri->current(); //current url pathj

		$player_type = JRequest::getVar( 'player_type' );

		include_once(JPATH_COMPONENT_SITE.DS.'players'.DS.'maianplayer.php');
		
		if(JRequest::getVar('save')){
		
			$this->updatePlayerParams();
		}
		
		if(is_file(JPATH_COMPONENT_SITE.DS.'players'.DS.$player_type.DS.'player.php')){
			include_once(JPATH_COMPONENT_SITE.DS.'players'.DS.$player_type.DS.'player.php');
			$player = new $player_type();
			
			echo '<div id="settings_player">'.$player->getplayer("test.mp3").'</div>';
		}

	}//end display_player

	function updatePlayerParams(){
		
		$params = JRequest::getVar('player-params');
		$lines = "";
		$bool = true;

		foreach ($params  as $k => $v)
		{
			if($bool){
				$lines =$k.'='.$v;
				$bool = false;
			}else{
				$lines .="\r\n".$k.'='.$v;
			}

		}

		$db =& JFactory::getDBO();

		$db->setQuery("UPDATE #__m15_settings SET player_params='$lines' WHERE id='1';");
		$db->query();

	}
	
	function getPlayerParams($subDir){
		$objDOM = new DOMDocument();
		$objDOM->load(JPATH_COMPONENT_SITE.DS.'players'.DS.$subdir.DS.'playerDetails.xml');
		echo $this->renderSettings($templateXMLFile, $SETTINGS->extra_params);
	}

	/**
	 * Parse an .ini string, based on phpDocumentor phpDocumentor_parse_ini_file function
	 *
	 * @access public
	 * @param mixed The INI string or array of lines
	 * @param boolean add an associative index for each section [in brackets]
	 * @return object Data Object
	 */
	function &stringToObject( $data, $process_sections = false )
	{
		static $inistocache;

		if (!isset( $inistocache )) {
			$inistocache = array();
		}

		if (is_string($data))
		{
			$lines = explode("\n", $data);
			$hash = md5($data);
		}
		else
		{
			if (is_array($data)) {
				$lines = $data;
			} else {
				$lines = array ();
			}
			$hash = md5(implode("\n",$lines));
		}

		if(array_key_exists($hash, $inistocache)) {
			return $inistocache[$hash];
		}

		$obj = new stdClass();

		$sec_name = '';
		$unparsed = 0;
		if (!$lines) {
			return $obj;
		}

		foreach ($lines as $line)
		{
			// ignore comments
			if ($line && $line{0} == ';') {
				continue;
			}

			$line = trim($line);

			if ($line == '') {
				continue;
			}

			$lineLen = strlen($line);
			if ($line && $line{0} == '[' && $line{$lineLen-1} == ']')
			{
				$sec_name = substr($line, 1, $lineLen - 2);
				if ($process_sections) {
					$obj-> $sec_name = new stdClass();
				}
			}
			else
			{
				if ($pos = strpos($line, '='))
				{
					$property = trim(substr($line, 0, $pos));

					// property is assumed to be ascii
					if ($property && $property{0} == '"')
					{
						$propLen = strlen( $property );
						if ($property{$propLen-1} == '"') {
							$property = stripcslashes(substr($property, 1, $propLen - 2));
						}
					}
					// AJE: 2006-11-06 Fixes problem where you want leading spaces
					// for some parameters, eg, class suffix
					// $value = trim(substr($line, $pos +1));
					$value = substr($line, $pos +1);

					if (strpos($value, '|') !== false && preg_match('#(?<!\\\)\|#', $value))
					{
						$newlines = explode('\n', $value);
						$values = array();
						foreach($newlines as $newlinekey=>$newline) {

							// Explode the value if it is serialized as an arry of value1|value2|value3
							$parts	= preg_split('/(?<!\\\)\|/', $newline);
							$array	= (strcmp($parts[0], $newline) === 0) ? false : true;
							$parts	= str_replace('\|', '|', $parts);

							foreach ($parts as $key => $value)
							{
								if ($value == 'false') {
									$value = false;
								}
								else if ($value == 'true') {
									$value = true;
								}
								else if ($value && $value{0} == '"')
								{
									$valueLen = strlen( $value );
									if ($value{$valueLen-1} == '"') {
										$value = stripcslashes(substr($value, 1, $valueLen - 2));
									}
								}
								if(!isset($values[$newlinekey])) $values[$newlinekey] = array();
								$values[$newlinekey][] = str_replace('\n', "\n", $value);
							}

							if (!$array) {
								$values[$newlinekey] = $values[$newlinekey][0];
							}
						}

						if ($process_sections)
						{
							if ($sec_name != '') {
								$obj->$sec_name->$property = $values[$newlinekey];
							} else {
								$obj->$property = $values[$newlinekey];
							}
						}
						else
						{
							$obj->$property = $values[$newlinekey];
						}
					}
					else
					{
						//unescape the \|
						$value = str_replace('\|', '|', $value);

						if ($value == 'false') {
							$value = false;
						}
						else if ($value == 'true') {
							$value = true;
						}
						else if ($value && $value{0} == '"')
						{
							$valueLen = strlen( $value );
							if ($value{$valueLen-1} == '"') {
								$value = stripcslashes(substr($value, 1, $valueLen - 2));
							}
						}

						if ($process_sections)
						{
							$value = str_replace('\n', "\n", $value);
							if ($sec_name != '') {
								$obj->$sec_name->$property = $value;
							} else {
								$obj->$property = $value;
							}
						}
						else
						{
							$obj->$property = str_replace('\n', "\n", $value);
						}
					}
				}
				else
				{
					if ($line && $line{0} == ';') {
						continue;
					}
					if ($process_sections)
					{
						$property = '__invalid'.$unparsed ++.'__';
						if ($process_sections)
						{
							if ($sec_name != '') {
								$obj->$sec_name->$property = trim($line);
							} else {
								$obj->$property = trim($line);
							}
						}
						else
						{
							$obj->$property = trim($line);
						}
					}
				}
			}
		}

		$inistocache[$hash] = clone($obj);
		return $obj;
	}
}