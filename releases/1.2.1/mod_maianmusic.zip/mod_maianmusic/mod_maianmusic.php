<?php
/*
* @name mod_maianmusic
* Created By Alao
* http://www.AreTimes.com
* @copyright Copyright (C) 2008  AreTimes.com / All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
*/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $mosConfig_live_site, $database, $mosConfig_absolute_path, $_VERSION;

$version = substr( $_VERSION->getShortVersion(), 0, 3 );

switch ( $version ){
	case '1.0':
    	echo '<link href="'.$mosConfig_live_site.'/modules/mod_maianmusic/mm_module.css" rel="stylesheet" type="text/css" />';
        echo '<!-- Popular Music Box from http://www.AreTimes.com -->';
        break;
    default:
        echo '<link href="'.$mosConfig_live_site.'/modules/mod_maianmusic/mod_maianmusic/mm_module.css" rel="stylesheet" type="text/css" />';
		echo '<!-- Popular Music Box from http://www.AreTimes.com -->';
        break;
}

function cleanModuleData($data) {
  return (get_magic_quotes_gpc() ? stripslashes($data) : $data);
}

$count = intval( $params->get('count', 10) );
$moduletype = intval( $params->get('moduletype', 2) );
$width_thumbcb = intval( $params->get('width_thumbcb', 25) );
$height_thumbcb = intval( $params->get('height_thumbcb', 25) );
$orientation = intval( $params->get('orientation', 1) );
$concat = intval( $params->get('concat', 10) );
$display_pic = intval( $params->get('display_pic', 0) );
$show_images = intval( $params->get('show_images', 1) );
$dots = intval( $params->get('dots', 1) );
$user = mosGetParam( $_REQUEST, 'user', 0 );
$alt_row = $params->get('alt_rows', '');

$table_top = '';
$table_bottom = '';

if($orientation == 0){
	$table_top = '<table><td>&nbsp;</td>';
	$table_bottom = '</table>';	
}

if($dots == 0){
	$entry_suffix = '-dots';
}else{
	$entry_suffix = '';
}

$style_height = ($height_thumbcb/2) + 2 ;

if($orientation == '1'){
	$styleInfo = ' style="padding: 10px 0 '.$style_height.'px; height:'.($height_thumbcb-($style_height/3)).'px;';
}else{
	$styleInfo = ' style="padding: 10px 0';
}

if(empty($alt_row) == false){
	$styleInfo = $styleInfo.'background: #'.$alt_row.';';
}

$styleInfo = $styleInfo.'"';

switch ($moduletype) {
	
	case '0':
		$database->setQuery("SELECT * FROM #__mm_albums
                               ORDER BY downloads DESC
                               LIMIT $count ");
                               
  		$q_pop_albums = $database->loadObjectList();
  		
  		if (count($q_pop_albums)>0) {  	 
  		
  			foreach($q_pop_albums as $P_ALBUMS){
  				
  				if($P_ALBUMS->image != '' && $P_ALBUMS->image != 'http://' && $display_pic == 0){
  					$list_image = '<img class="mm_image" width="'.$width_thumbcb.'" height="'.$height_thumbcb.'" src="'.$P_ALBUMS->image.'" alt="'.$P_ALBUMS->name.'" border="1" align="left"/>';
  				}else{
  					$list_image = '<img width="'.$width_thumbcb.'" height="'.$height_thumbcb.'" src="'.$mosConfig_live_site.'/components/com_maianmusic/images/bullet_static.png" alt="'.$P_ALBUMS->name.'" border="0" align="left"/>';
  				}
  				
  				if($show_images == 1){
  					$list_image = '';
  				}
  				
  				
  				if ($i % 2 == 0){
  					$alt = 'class="maian_odd'.$entry_suffix.'"'.$styleInfo;
  				}else{
  					$alt = 'class="maian_even'.$entry_suffix.'"'.$styleInfo;
  				}
  				
  				if($orientation == 1){
      				$most_pop .= '<div '.$alt.'>
      			                  '.$list_image.'<a href="'.sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$P_ALBUMS->id).'" title="'.cleanModuleData($P_ALBUMS->name).'">'.cleanModuleData($P_ALBUMS->name).'</a><br />
      			                  <span class="mm_artist">'.cleanModuleData($P_ALBUMS->artist).'</span>
      			                  </div>';
  				}else{
  					$most_pop .= '<td '.$alt.'>
      			                  '.$list_image.'<a href="'.sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$P_ALBUMS->id).'" title="'.cleanModuleData($P_ALBUMS->name).'">'.cleanModuleData($P_ALBUMS->name).'</a><br />
      			                  <span class="mm_artist">'.cleanModuleData($P_ALBUMS->artist).'</span>
      			                  </td>';
  				}
  				
    			$i = $i + 1;
  			}
  		}	
	break;
	
	case '1':
		$database->setQuery("SELECT *,#__mm_albums.id AS i_id 
                               FROM #__mm_tracks
                               LEFT JOIN #__mm_albums
                               ON #__mm_tracks.track_album = #__mm_albums.id
                               ORDER BY #__mm_tracks.downloads DESC
                               LIMIT $count
                               ");
  		$q_pop_tracks = $database->loadObjectList();
  		
  		if (count($q_pop_tracks)>0) {  	 
  		
  			foreach($q_pop_tracks as $P_TRACKS){
  				
  				if($P_TRACKS->image != '' && $P_TRACKS->image != 'http://' && $display_pic == 0){
  					$list_image = ' <img class="mm_image" width="'.$width_thumbcb.'" height="'.$height_thumbcb.'" src="'.$P_TRACKS->image.'" alt="'.$P_TRACKS->track_name.'" border="1" align="left"/>';
  				}else{
  					$list_image = ' <img width="'.$width_thumbcb.'" height="'.$height_thumbcb.'" src="'.$mosConfig_live_site.'/components/com_maianmusic/images/bullet_static.png" alt="'.$P_TRACKS->track_name.'" border="0" align="left"/>';
  				}
  				
  				if($show_images == 1){
  					$list_image = '';
  				}
  				
  				if ($i % 2 == 0){
  					$alt = 'class="maian_odd'.$entry_suffix.'"'.$styleInfo;
  				}else{
  					$alt = 'class="maian_even'.$entry_suffix.'"'.$styleInfo;
  				}
  				
  				if($orientation == 1){
      				$most_pop .= '<div '.$alt.'>
      			                  '.$list_image.'<a href="'.sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$P_TRACKS->i_id).'" title="'.cleanModuleData($P_TRACKS->track_name).'">'.cleanModuleData($P_TRACKS->track_name).'</a><br />
      			                  <span class="mm_artist">'.cleanModuleData($P_TRACKS->artist).'</span>
      			                  </div>';
  				}else{
  					$most_pop .= '<td '.$alt.'>
      			                  '.$list_image.'<a href="'.sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$P_TRACKS->i_id).'" title="'.cleanModuleData($P_TRACKS->track_name).'">'.cleanModuleData($P_TRACKS->track_name).'</a><br />
      			                  <span class="mm_artist">'.cleanModuleData($P_TRACKS->artist).'</span>
      			                  </td>';
  				}
  				
    			$i = $i + 1;
  			}
  		}	
	break;
	
}
?>
<div class="maian_wrapper">
<?php echo $table_top	?>
<?php echo $most_pop; ?>
<?php echo $table_bottom; ?>
<div style="clear:both;"></div>
</div>

   
