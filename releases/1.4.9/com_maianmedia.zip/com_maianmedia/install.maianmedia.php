<?php

/**
 * @package		Joomla
 * @subpackage	com_maianmedia
 * @copyright	Copyright (C) AreTimes & Maian Script World. All rights reserved.
 * @license		GNU/GPL
 * @author 		Arelowo Alao (aretimes.com) & David Bennet (maianscriptworld.co.uk)
 * Joomla! and Maian Music are free software. You must attribute the work in the manner
 * specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

function com_install() {

	$db =& JFactory::getDBO();
	$uri =& JURI::getInstance();

	$document = &JFactory::getDocument();
	$document->addScript($uri->current().'?option=com_maianmedia&format=raw&controller=tracks&task=uploaderjs');

	$db->setQuery( "SELECT id FROM #__components WHERE link= 'option=com_maianmedia'" );
	$id = $db->loadResult();

	if(!isset($id)){
		$db->setQuery( "SELECT id FROM #__components WHERE link= 'option=com_maian15'" );
		$id = $db->loadResult();
	}
	//get id
	$db->setQuery( "UPDATE #__menu SET componentid = '$id' WHERE link LIKE '%com_maianmedia%'" );
	$db->query();

	//update old maian15 links
	$db->setQuery( "UPDATE #__menu SET link = 'index.php?option=com_maianmedia&view=music' WHERE link LIKE 'index.php?option=com_maian15&view=music'" );
	$db->query();

	$db->setQuery( "UPDATE #__menu SET link = 'index.php?option=com_maianmedia&view=contact' WHERE link LIKE 'index.php?option=com_maian15&view=contact'" );
	$db->query();

	$db->setQuery( "UPDATE #__menu SET link = 'index.php?option=com_maianmedia&view=freebie' WHERE link LIKE 'index.php?option=com_maian15&view=freebie'" );
	$db->query();

	$db->setQuery( "UPDATE #__menu SET link = 'index.php?option=com_maianmedia&view=mostpop' WHERE link LIKE 'index.php?option=com_maian15&view=mostpop'" );
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/record.png' WHERE id = '$id'" );
	$db->query();

	//add new admin menu images

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/about.png' WHERE parent='$id' AND name = 'About'");
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/settings.png' WHERE parent='$id' AND name = 'Settings'");
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/albums.png' WHERE parent='$id' AND name = 'Manage Albums'");
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/add.png' WHERE parent='$id' AND name = 'Add New Tracks'");
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = ' 	../components/com_maianmedia/media/thumb/track.png' WHERE parent='$id' AND name = 'Manage Tracks'");
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/sales.png' WHERE parent='$id' AND name = 'Sales'");
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/search_sales.png' WHERE parent='$id' AND name = 'Search Sales'");
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/stats.png' WHERE parent='$id' AND name = 'Statistics'");
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/tools.png' WHERE parent='$id' AND name = 'Tools'");
	$db->query();


	echo '<div id="maian_content"><img src="'.$uri->root().'/administrator/components/com_maianmedia/images/are_logo.png"></img><br>';
	echo '<p>To use this system you must have a paypal bussiness account<br>';
	echo 'Log in to your Paypal account and click "Profile" from the "My Account" menu tab.<br><br>';
	echo '<b>Click "Selling Preferences --> "Instant Payment Notification Preferences"</b><br>';
	echo '<p>On the next screen, click "Edit" and check the box to enable the IPN system and in the "Notification URL" box, enter the full URL to your notification page.<br><br>';
	echo '<b>'.$uri->root().'index.php?option=com_maianmedia&amp;section=paypal&amp;view=notify</b><br><br>';
	echo 'From the "Profile" tab, select "Selling Preferences" --> "Website Payment Preferences" the URL for the auto return function is as follows:<br><br>';
	echo '<b>'.$uri->root().'index.php?option=com_maianmedia&amp;section=paypal&amp;view=thanks</b><br><br>';
	echo 'Be sure to turn on "Auto Return" and "Payment Data Transfer".  Copy your pin for use in the application</p></div>';

	$db->setQuery( "SELECT * FROM #__mm_settings" );
	$data = $db->loadObjectList();

	if(isset($data)){
		$document->addScript( 'components/com_maianmedia/js/request.js' );
		echo '<div class="button2-right">
<div class="start">
<a href="javascript:ajaxRequest(\'import\', \'index.php?option=com_maianmedia&amp;task=tools&amp;format=raw&amp;tool=run_import\', 1)"
	title="Start" onclick="">Import 1.0 Tables</a></div>
</div><br><br><div style="float:left; text-align:left;" id="import"></div>';
	}

	$db->setQuery( "SELECT * FROM #__mbak_settings" );
	$data = $db->loadObjectList();

	if(isset($data)){

		$document->addScript( 'components/com_maianmedia/js/request.js' );
		echo '<div class="button2-right">
<div class="start">
<a href="javascript:ajaxRequest(\'backup\', \'index.php?option=com_maianmedia&amp;task=tools&amp;format=raw&amp;tool=import_backup\', 1)"
	title="Start" onclick="">Import Table Backup</a></div>
</div><br><br><div style="float:left; text-align:left;" id="backup"></div>';
	}

}
?>