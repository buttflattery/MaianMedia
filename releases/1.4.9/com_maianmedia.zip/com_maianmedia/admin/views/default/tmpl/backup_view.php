<?php
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_LIBRARIES.DS.'joomla'.DS.'factory.php');
include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');

$db =& JFactory::getDBO();

$db->setQuery("SELECT * FROM #__mbak_settings");
$settings = $db->loadObject();

if($db->ErrorNo() ==1146){
	$error = $db->ErrorNo();
}
$db->setQuery("SELECT * FROM #__mbak_albums");
$albums = $db->loadObject();

if($db->ErrorNo() ==1146){
	$error= $db->ErrorNo();
}

$db->setQuery("SELECT * FROM #__mbak_tracks");
$tracks = $db->loadObject();

if($db->ErrorNo() ==1146){
	$error = $db->ErrorNo();
}

$db->setQuery("SELECT * FROM #__mbak_purchases");
$purchases = $db->loadObject();

if($db->ErrorNo() ==1146){
	$error = $db->ErrorNo();
}

$db->setQuery("SELECT * FROM #__mbak_paypal");
$paypal = $db->loadObject();

if($db->ErrorNo() ==1146){
	$error = $db->ErrorNo();
}

$db->setQuery("SELECT * FROM #__mbak_pages");
$pages = $db->loadObject();

if($db->ErrorNo() ==1146){
	$error = $db->ErrorNo();
}

jimport( 'joomla.environment.uri' );
$uri =& JURI::getInstance();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb"
	dir="ltr">
<head>
<link href="components/com_maianmedia/stylesheet.css" rel="stylesheet"
	type="text/css" />
<link rel="stylesheet" href="templates/system/css/system.css"
	type="text/css" />
<link href="templates/khepri/css/template.css" rel="stylesheet"
	type="text/css" />
 <script type="text/javascript" src="<?php echo $uri->root() ?>administrator/components/com_maianmedia/js/request.js"></script>

</head>
<body id="minwidth-body">
<form enctype="multipart/form-data" action="index.php" method="post"
	name="adminForm">
<fieldset id="maian_about">

<div class="button2-right">
<div class="start">
<a href="javascript:ajaxRequest('run_backup', 'index.php?option=com_maianmedia&amp;task=tools&amp;format=raw&amp;tool=run_backup', 1)"
	title="Start" onclick=""><?php echo JText::_(_msg_backup2); ?></a></div>
</div>
<div id="import_backup" class="button2-right">
<div class="start">
<a href="javascript:ajaxRequest('run_backup', 'index.php?option=com_maianmedia&amp;task=tools&amp;format=raw&amp;tool=import_backup', 1)"
	title="Start" onclick=""><?php echo JText::_(_setup29); ?></a></div>
</div>
<?php if(isset($settings)){?>
<blockquote id="warning"><?php echo  JText::_(_msg_backup3); ?></blockquote>
<?php } ?>

<br><br>
<table class="admintable">
	<tr>
		<td colspan=2 width="100%" id="check" class="key"><?php echo JText::_(_msg_tools); ?></td>
	</tr>
	<tr>
		<td><b><?php echo $db->getPrefix(); ?>mbak_settings</b></td>
		<td><span class="info"><b><?php echo (isset($settings) ? JText::_(_msg_tools2) : JText::_(_msg_backup4)); ?></b></span></td>
	</tr>
	<tr>
		<td><b><?php echo $db->getPrefix(); ?>mbak_albums</b></td>
		<td><span class="info"><b><?php echo (isset($albums) ? JText::_(_msg_tools2) : JText::_(_msg_backup4)); ?></b></span></td>
	</tr>
	<tr>
		<td><b><?php echo $db->getPrefix(); ?>mbak_tracks</b></td>
		<td><span class="info"><b><?php echo (isset($tracks)? JText::_(_msg_tools2) : JText::_(_msg_backup4)); ?></b></span></td>
	</tr>
	<tr>
		<td><b><?php echo $db->getPrefix(); ?>mbak_purchases</b></td>
		<td><span class="info"><b><?php echo (isset($purchases) ? JText::_(_msg_tools2) : JText::_(_msg_backup4)); ?></b></span></td>
	</tr>
	<tr>
		<td><b><?php echo $db->getPrefix(); ?>mbak_paypal</b></td>
		<td><span class="info"><b><?php echo (isset($paypal)? JText::_(_msg_tools2) : JText::_(_msg_backup4)); ?></b></span></td>
	</tr>
	<tr>
		<td><b><?php echo $db->getPrefix(); ?>mbak_pages</b></td>
		<td><span class="info"><b><?php echo (isset($pages)? JText::_(_msg_tools2) : JText::_(_msg_backup4)); ?></b></span></td>
	</tr>
</table>
<div id="run_backup"></div>
</fieldset>
</form>
</body>
</html>
