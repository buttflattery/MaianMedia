<?php
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_LIBRARIES.DS.'joomla'.DS.'factory.php');
include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');


include_once(JPATH_COMPONENT.DS.'tables'.DS.'backup.php');

$db =& JFactory::getDBO();

$db->setQuery("SELECT * FROM #__m15_settings");
$settings = $db->loadObject();

$db->setQuery("SELECT * FROM #__m15_albums");
$albums = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__m15_tracks");
$tracks = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__m15_purchases");
$purchases = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__m15_paypal");
$paypal = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__m15_pages");
$pages = $db->loadObjectList();

$db =& JFactory::getDBO();
$db->setQuery("DROP TABLE IF EXISTS  `#__mbak_albums`");
$db->query();

$db->setQuery("DROP TABLE IF EXISTS `#__mbak_paypal`");	
$db->query();

$db->setQuery("DROP TABLE IF EXISTS  `#__mbak_purchases`");
$db->query();

$db->setQuery("DROP TABLE IF EXISTS `#__mbak_settings`");
$db->query();

$db->setQuery("DROP TABLE IF EXISTS `#__mbak_tracks`");
$db->query();

$db->setQuery("DROP TABLE IF EXISTS `#__mbak_pages`");
$db->query();

$fh = fopen(JPATH_COMPONENT.DS.'install.mysql.sql', 'r'); 
$sql_file = fread($fh, filesize(JPATH_COMPONENT.DS.'install.mysql.sql')); 
fclose($fh); 

$sql_file = str_replace('#__m15','#__mbak', $sql_file);

$queries = explode(";", $sql_file);

$db->setQuery(trim($queries[0]));
$db->query();

$db->setQuery(trim($queries[2]));
$db->query();

$db->setQuery(trim($queries[3]));
$db->query();

$db->setQuery(trim($queries[4]));
$db->query();

$db->setQuery(trim($queries[5]));
$db->query();

$db->setQuery(trim($queries[6]));
$db->query();

$settingsTable =& JTable::getInstance('baksettings', 'Table');
$albumTable =& JTable::getInstance('bakalbum', 'Table');
$purchasesTable =& JTable::getInstance('bakpurchases', 'Table');
$paypalTable =& JTable::getInstance('bakpaypal', 'Table');
$tracksTable =& JTable::getInstance('baktracks', 'Table');
$pagesTable =& JTable::getInstance('bakpages', 'Table');

// Bind the form fields to the settings table
if (!$settingsTable->bind(parseObjectToArray($settings))) {
	echo JText::_(_msg_error_bind).' Settings<br>';
	$importError = 1;
}

// Make sure the settings record is valid
if (!$settingsTable->check()) {
	echo JText::_(_msg_error_check).' Settings<br>';
	$importError = 1;
}
$settingsTable->_tbl_key = 1;
// Store the web link table to the database
if (!$settingsTable->store()) {
	echo JText::_(_msg_error_store).' Settings<br>';
	$importError = 1;
}

foreach($purchases as $single){
	
	if (!$purchasesTable->bind($single)){
		echo JText::_(_msg_error_bind).' Purchases<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$purchasesTable->check()){
		echo JText::_(_msg_error_check).' Purchaces<br>';
		$importError = 1;
	}

	$purchasesTable->_tbl_key = 0;
	
	// Store the web link table to the database
	if (!$purchasesTable->store()){
		echo JText::_(_msg_error_store).' Purchaces<br>';
		$importError = 1;
	}

}


foreach($paypal as $single){

	if (!$paypalTable->bind($single)){
		echo JText::_(_msg_error_bind).' Paypal<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$paypalTable->check()){
		echo JText::_(_msg_error_check).' Paypal<br>';
		$importError = 1;
	}
	$paypalTable->_tbl_key = 0;
	// Store the web link table to the database
	if (!$paypalTable->store()){
		echo JText::_(_msg_error_store).' Paypal<br>';
		$importError = 1;
	}

}

foreach($albums as $album){

	if (!$albumTable->bind($album)){
		echo JText::_(_msg_error_bind).' Album<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$albumTable->check()){
		echo JText::_(_msg_error_check).' Album<br>';
		$importError = 1;
	}
	$albumTable->_tbl_key = 0;
	// Store the web link table to the database
	if (!$albumTable->store()){
		echo JText::_(_msg_error_store).' Album<br>';
		$importError = 1;
	}

}

foreach($tracks as $track){

	if (!$tracksTable->bind($track)){
		echo JText::_(_msg_error_bind).' Track<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$tracksTable->check()){
		echo JText::_(_msg_error_check).' Track<br>';
		$importError = 1;
	}
	
	$tracksTable->_tbl_key = 0;
	
	// Store the web link table to the database
	if (!$tracksTable->store()){

		echo JText::_(_msg_error_store).' Track<br>';
		$importError = 1;
	}

}

foreach($pages as $page){

	if (!$pagesTable->bind($page)){
		echo JText::_(_msg_error_bind).' Pages<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$pagesTable->check()){
		echo JText::_(_msg_error_check).' Pages<br>';
		$importError = 1;
	}
	
	$pagesTable->_tbl_key = 0;
	
	// Store the web link table to the database
	if (!$pagesTable->store()){

		echo JText::_(_msg_error_store).' Pages<br>';
		$importError = 1;
	}

}

	if (isset($importError)){
		echo '<font style="color:red; margin-left:150px;"><b>'.JText::_(_msg_backup5).'</b></font>';
		$importError = 1;
	}else{
		echo '<font style="color:blue; margin-left:150px;"><b>'.JText::_(_msg_backup6).'</b></font>';
	}

?>
