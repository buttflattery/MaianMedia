<?php
$db =& JFactory::getDBO();

$db->setQuery("SELECT text FROM #__m15_pages where id='1'") ;
$about = $db->loadObject();

$db->setQuery("SELECT text FROM #__m15_pages where id='2'") ;
$license = $db->loadObject();

$db->setQuery("SELECT text FROM #__m15_pages where id='3'") ;
$music = $db->loadObject();

$db->setQuery("SELECT text FROM #__m15_pages where id='4'") ;
$free = $db->loadObject();
?>
<form action="index.php" method="post" name="adminForm">
<fieldset id="mm_custom" class="adminform">
<legend><?php echo JText::_( _msg_settings23); ?></legend>
<?php
// instantiate new tab system
//$tabs = new mosTabs(1);
jimport('joomla.html.pane');
$editor =& JFactory::getEditor();
$tabs =& JPane::getInstance('tabs', array('startOffset'=>0));

// start tab pane
echo $tabs->startPane("TabPaneOne");

//First tab
echo $tabs->startPanel(_msg_public_header3,"firsttab-page");
// parameters : areaname, content, hidden field, width, height, rows, cols
echo $editor->display('about', cleanData($about->text), '550', '400', '60', '20', true);
echo $tabs->endPanel();

//Second Tab
echo $tabs->startPanel(_msg_settings43,"secondtab-page");
// parameters : areaname, content, hidden field, width, height, rows, cols
echo $editor->display('music', cleanData($music->text),  '550', '400', '60', '20', true);
echo $tabs->endPanel();

//Third Tab
echo $tabs->startPanel(_msg_public_header12,"thirdtab-page");
// parameters : areaname, content, hidden field, width, height, rows, cols
echo $editor->display('licence', cleanData($license->text),  '550', '400', '60', '20', true);
echo $tabs->endPanel();

//Fourth Tab
echo $tabs->startPanel(_msg_free_download,"fourthtab-page");
// parameters : areaname, content, hidden field, width, height, rows, cols
echo $editor->display('freeText', cleanData($free->text),  '550', '400', '60', '20', true);
echo $tabs->endPanel();
// end tab pane
echo $tabs->endPane("TabPaneOne");
echo '<br>';
?>
 </fieldset>
 <input type="hidden" name="id" value="1" />
<input type="hidden" name="option" value="com_maianmedia" />
<input type="hidden" name="task" value="tools" />
<input type="hidden" name="tool" value="custom" />
<input type="hidden" name="controller" value="settings" />
</form>