<?php
/**
 * Hello View for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewTracks extends JView
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		$albums =& $this->get('Albums');
		
		JToolBarHelper::title(   JText::_(_msg_header6), 'tracks.png' );
		//JToolBarHelper::addNewX();
		//JToolBarHelper::editListX();
		//JToolBarHelper::deleteList();

		$this->assignRef('albums', $albums);

		parent::display($tpl);
	}
}