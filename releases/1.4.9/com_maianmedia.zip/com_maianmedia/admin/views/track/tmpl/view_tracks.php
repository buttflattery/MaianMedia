<?php defined('_JEXEC') or die('Restricted access'); 

/*++++++++++++++++++++++++++++++++++++++++

Script: Maian Music v1.2
Written by: David Ian Bennett
E-Mail: support@maianscriptworld.co.uk
Website: http://www.maianscriptworld.co.uk
Intergration: http://www.aretimes.com

++++++++++++++++++++++++++++++++++++++++
*/

$db =& JFactory::getDBO();
include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');

$lim   = $mainframe->getUserStateFromRequest("$option.limit", 'limit', 5, 'int'); //I guess getUserStateFromRequest is for session or different reasons
$lim0  = JRequest::getVar('limitstart', 0, '', 'int');

$uri =& JURI::getInstance();
$root_url = $uri->root(); //root url
$root_base = $uri->base(); //base url
$root_current = $uri->current(); //current url pathj

$list = $this->tracks;

$albumId = $list[0]->track_album;

$db->setQuery("SELECT * FROM #__m15_albums WHERE id= $albumId
                        LIMIT 1");
$Album = $db->loadObject();

$document = &JFactory::getDocument();
$document->addCustomTag('<style type = "text/css">
                 ul#sortable-list{
                 list-style:none;
                 padding:0px;
                 margin:0px}
                  ul#sortable-list li{ list-style:none;
                  }
                  #output{font:bold 10px verdana}
              </style>
<script type="text/javascript">

function getInputsById(tag) {
	var elem = document.getElementsByTagName("input");
	var arr = new Array();
	for (i = 0, iarr = 0; i < elem.length; i++) {
		att = elem[i].getAttribute("id");
		if(att == tag) {
			arr[iarr] = elem[i];
			iarr++;
		}
	}
	return arr;
}

	/* when the DOM is ready */
	window.addEvent(\'domready\', function() {
	
		/* create sortables */
		var sb = new Sortables(\'sortable-list\', {
			/* set options */

			clone: true,
			opacity: \'0\',
			handles: \'.handle\',

			revert: {
	    		//accepts Fx options
				duration: 500, transition: \'elastic:out\'
			},
			/* initialization stuff here */
			initialize: function() { 
				
			},
			
			onSort: function(el) {
				//passes element you are dragging
				//el.highlight(\'#FFFFFF\');
			},
			
			/* once an item is selected */
			onStart: function(el) { 
				//passes element you are dragging
				//el.highlight(\'#FFFFFF\');
			
			},
			/* when a drag is complete */
			onComplete: function(el) {
				var arr = document.getElementsByTagName("legend");
				var singleArr = getInputsById("track_single");
				var freeArr = getInputsById("freebie");

				for (i=0; i<arr.length;i++) {
					x= i+1;
					arr[i].innerHTML="Track "+x;
					singleArr[i].setAttribute("name","track_single_"+i);
					freeArr[i].setAttribute("name","freebie_"+i);
				}//end for
				
			}
		});
	});

	</script>

<script type="text/javascript">

 function removeTrack(id)
 {
		var answer = confirm("'.JText::_(_msg_javascript21).'","'.JText::_(_msg_script2).'","'.JText::_(_msg_script3).'");
 		if (answer){
			var el = $(\'item_\'+id);
			MTFade (el, \'opacity\',0);
			ajaxRequest(\'item_\'+id, \'index.php?option=com_maianmedia&format=raw&controller=tracks&task=removeTrack&deleteThis=\'+id, 0);
			window.setTimeout(\'runChange()\', 1000);
 		}
 		
 }

 function MTFade (div,prop,val) {
			new Fx.Style(div, prop, {duration: 250} ).start(val);
 }
 
 function runChange()
 {
 	var arr = document.getElementsByTagName("legend");
	
	for (i=0; i<arr.length;i++) {
		x= i+1;
		arr[i].innerHTML="Track "+x+"<img class=\'toggle_track\' src=\''.$root_base.'components/com_maianmedia/images/expand.png\'/>";

	}//end for
	
 }

function expandAll(count){

	for (id=0; id<count;id++){
		var row = document.getElementById("albumRow_"+id);
		row.style.display = "";
	
		var row = document.getElementById("mp3Row_"+id);
		row.style.display = "";
	
		var row = document.getElementById("previewRow_"+id);
		row.style.display = "";
	
		var row = document.getElementById("otherRow_"+id);
		row.style.display = "";
	}// for

}

function collapseAll(count){

	for (id=0; id<count;id++){
		var row = document.getElementById("albumRow_"+id);
		row.style.display = \'none\';
	
		var row = document.getElementById("mp3Row_"+id);
		row.style.display = \'none\';
	
		var row = document.getElementById("previewRow_"+id);
		row.style.display = \'none\';
	
		var row = document.getElementById("otherRow_"+id);
		row.style.display = \'none\';
	}// for
}
 
function displayRow(id){

	var row = document.getElementById("albumRow_"+id);

	if (row.style.display == "") row.style.display = \'none\';

	else row.style.display = "";
	
	var row = document.getElementById("mp3Row_"+id);

	if (row.style.display == "") row.style.display = \'none\';

	else row.style.display = "";
	
	var row = document.getElementById("previewRow_"+id);

	if (row.style.display == "") row.style.display = \'none\';

	else row.style.display = "";
	
	var row = document.getElementById("otherRow_"+id);

	if (row.style.display == "") row.style.display = \'none\';

	else row.style.display = "";
}
 
</script>');



$i=0;
$html_output='';
//$html_output = '<div id="manage_top"><a class="manage_tracks" href="javascript:expandAll(\''.count($list).'\')">Expand All</a><a class="manage_tracks" href="javascript:collapseAll(\''.count($list).'\')">Collapse All</a></div>';
foreach ($list AS $TRACKS){

	$html_output.= "<li class=\"sortme\" name=\"item_$TRACKS->id\" id=\"item_$TRACKS->id\"><div name=\"table_$TRACKS->id.\" id=\"table_$TRACKS->id\">";
	$html_output.='<fieldset class="adminform"><legend id="legend_'.$TRACKS->id.'">Track '.$TRACKS->track_order.' </legend><img onclick="displayRow('.$i.')" class="toggle_track" src="'.$root_base.'components/com_maianmedia/images/expand.png"/>
		<span class="handle"><img src="'.$root_base.'components/com_maianmedia/images/move.png"/></span>
		<input type="hidden" name="id[]" value="'.$TRACKS->id.'">
		<input type="hidden" name="t_path[]" value="'.$TRACKS->mp3_path.'">
      	<input type="hidden" name="t_name[]" value="'.cleanData($TRACKS->track_name).'">
      	<input type="hidden" name="t_cost[]" value="'.$TRACKS->track_cost.'">
      	
		<table class="admintable" cellspacing="0" cellpadding="0">
        <tr>
          <td class="key" width="30%">'.JText::_(_msg_add6).'</td>
          <td align="left" width="70%"><input class="formBox" type="text" name="track_name[]" maxlength="250" size="30" value="'.cleanData($TRACKS->track_name).'"></td>
        </tr>
        <tr id="albumRow_'.$i.'">
          <td class="key">'.JText::_(_msg_add7).'</td>
          <td align="left"><select name="track_album[]">';

	$db->setQuery("SELECT * FROM #__m15_albums
                                   ORDER BY name");		
	$q_albums = $db->loadObjectList();
	foreach ($q_albums as $ALBUMS){
		$html_output.='<option value="'.$ALBUMS->id.'"'.($_GET['cid']==$ALBUMS->id ? ' selected' : '').'>'.cleanData($ALBUMS->artist).' - '.cleanData($ALBUMS->name).'</option>'."\n";
	}


	$html_output.='</select></td>
        </tr>
        <tr id="mp3Row_'.$i.'">
          <td class="key">'.JText::_(_msg_add8).'</td>
          <td align="left" ><input class="formBox" type="text" name="mp3_path[]" maxlength="250" size="30" value="'.cleanData($TRACKS->mp3_path).'"> '.toolTip(JText::_(_msg_javascript),JText::_(_msg_javascript16)).'</td>
        </tr>
        <tr id="previewRow_'.$i.'">
          <td class="key">'.JText::_(_msg_add9).'</td>
          <td align="left" ><input class="formBox" type="text" name="preview_path[]" maxlength="250" size="30" value="'.cleanData($TRACKS->preview_path).'"> '.toolTip(JText::_(_msg_javascript),JText::_(_msg_javascript17)).'</td>
        </tr>
        <tr id="keywordRow_'.$i.'">
        	<td class="key">Keywords</td>
            <td align="left"><input class="formBox" type="text" name="keywords[]" maxlength="250" size="80" value="'.cleanData($TRACKS->keywords).'"></td>
        </tr>
        <tr class="otherRow" id="otherRow_'.$i.'">
          <td colspan="2">
          <table width="100%" class="infoTable" cellspacing="0" cellpadding="0" style="border-bottom: 1px solid #E9E9E9;border-right: 1px solid #E9E9E9; background-color: #F6F6F6; color:#666;">
          <tr>
            <td align="left" width="23%">'.JText::_(_msg_add10).':</td>
            <td align="left" width="20%"><input class="formBox" type="text" name="track_length[]" maxlength="50" size="30" value="'.cleanData($TRACKS->track_length).'" style="width:70%"> '.toolTip(JText::_(_msg_javascript),JText::_(_msg_javascript18)).'</td>
            <td align="right" width="5%">'.JText::_(_msg_add11).':</td>
            <td align="left" width="15%" ><input class="formBox" type="text" name="track_cost[]" maxlength="5" size="30" value="'.cleanData($TRACKS->track_cost).'" style="width:50%"> '.toolTip(JText::_(_msg_javascript),JText::_(_msg_javascript19)).'</td>
            <td align="right" width="25%">'.JText::_(_msg_add12).':</td>
            <td align="left" width="40%" class="box_single"><input type="checkbox" id="track_single" value="1" name="track_single_'.$i.'" '.($TRACKS->track_single ? ' checked' : '').'> '.toolTip(JText::_(_msg_javascript),JText::_(_msg_javascript20)).'</td>
          	<td align="right" width="10%">'.JText::_(_msg_free_download).':</td>
            <td align="left" width="40%"><input type="checkbox" value="1" '.($TRACKS->freebie ? ' checked' : '').'" id="freebie" name="freebie_'.$i.'"/>'.toolTip(JText::_(_msg_free_download),JText::_(_msg_javascript)).'</td>
            </tr>
          </table>
          </td>      
        </tr>
        </table><a id="remove_'.$TRACKS->id.'" class="remove_track" href="javascript:removeTrack(\''.$TRACKS->id.'\')" title="'.JText::_(_msg_script8).'"><img src="'.$root_base.'components/com_maianmedia/images/remove.png"/></a></fieldset>';
	$html_output.= "</div></li>\n";
	//$html_output.= "<li id=\"item_$record->id\">$record->id<input class='formBox' type='text' name='website_name' maxlength='250' size='30'/></li>\n";
	$i= $i+1;
}

?>
<form action="index.php" method="post" name="adminForm">
<div id="album_top"><b><?php echo $Album->name; ?></b></div>
<?php echo '<div id="manage_top"><a class="manage_tracks" href="javascript:expandAll(\''.count($list).'\')">'.JText::_(_msg_expand_all).'</a><a class="manage_tracks" href="javascript:collapseAll(\''.count($list).'\')">'.JText::_(_msg_collapse_all).'</a></div>'; ?>
<ul id="sortable-list">
<?php echo $html_output; ?>
</ul>
<input type="hidden" name="limitstart" value="<?php echo $lim0; ?>" /> 
<input type="hidden" name="option" value="com_maianmedia" /> 
<input type="hidden" name="task" value="update" /> 
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller"value="tracks" /> 
<input type="hidden" name="cid"	value="<?php echo $_GET['cid']; ?>" />
	
</form>
