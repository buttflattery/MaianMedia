<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php

/*++++++++++++++++++++++++++++++++++++++++

Script: Maian Music v1.2
Written by: David Ian Bennett
E-Mail: support@maianscriptworld.co.uk
Website: http://www.maianscriptworld.co.uk
Intergration: http://www.aretimes.com

++++++++++++++++++++++++++++++++++++++++
*/

function endecrypt ($pwd, $data, $case='') {
	if ($case == 'de') {
		$data = urldecode($data);
	}

	$key[] = "";
	$box[] = "";
	$temp_swap = "";
	$pwd_length = 0;

	$pwd_length = strlen($pwd);

	for ($i = 0; $i <= 255; $i++) {
		$key[$i] = ord(substr($pwd, ($i % $pwd_length), 1));
		$box[$i] = $i;
	}

	$x = 0;

	for ($i = 0; $i <= 255; $i++) {
		$x = ($x + $box[$i] + $key[$i]) % 256;
		$temp_swap = $box[$i];

		$box[$i] = $box[$x];
		$box[$x] = $temp_swap;
	}

	$temp = "";
	$k = "";

	$cipherby = "";
	$cipher = "";

	$a = 0;
	$j = 0;

	for ($i = 0; $i < strlen($data); $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;

		$temp = $box[$a];
		$box[$a] = $box[$j];

		$box[$j] = $temp;

		$k = $box[(($box[$a] + $box[$j]) % 256)];
		$cipherby = ord(substr($data, $i, 1)) ^ $k;

		$cipher .= chr($cipherby);
	}

	if ($case == 'de') {
		$cipher = urldecode(urlencode($cipher));

	} else {
		$cipher = urlencode($cipher);
	}

	return $cipher;
}

function getLang(){
	//$lang =& JFactory::getLanguage();
	//$joomlaLang = $lang->get('tag');


	$db =& JFactory::getDBO();
	$db->setQuery("SELECT * FROM #__m15_settings Limit 1");

	$settings = $db->loadObject();

	switch ($settings->language) {
		case 'english.php':
			return 'en';
			break;
		case 'spanish.php':
			return 'es';
			break;
		case 'french.php':
			return 'fr';
			break;
		case 'german.php':
			return 'de';
			break;
		case 'swedish.php':
			return 'se';
			break;
		case 'finnish.php':
			return 'fi';
			break;
		case 'czech.php':
			return 'cs';
			break;
		case 'danish.php':
			return 'da';
			break;
		default:
			return 'en';
	}

}

$db =& JFactory::getDBO();
include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');

$dir = isset($_GET['dir']) ? ($_GET['dir']) : 'tmp';
$db->setQuery("SELECT * FROM #__m15_settings Limit 1");

$uri =& JURI::getInstance();
$SETTINGS = $db->loadObject();
$assets = str_replace('\\', '//', JPATH_COMPONENT.DS.'images'.DS.'managerAssets');

$session = & JFactory::getSession();

$user =& JFactory::getUser();
$sessionid = endecrypt(md5($user->password), $session->getId());

$sessionid = str_replace('%','-per-',$sessionid);
$sessionid = str_replace('.','-dot-',$sessionid);

$document = &JFactory::getDocument();

/*New Uploader http://og5.net*/

$headerstuff = $document->getHeadData();
$headerstuff['scripts'] = array();
$document->setHeadData($headerstuff);

$document->addCustomTag('<link rel="stylesheet" media="all" type="text/css" href="components/com_maianmedia/js/filemanager/Css/FileManager.css" />');
$document->addCustomTag('<link rel="stylesheet" media="all" type="text/css" href="components/com_maianmedia/js/filemanager/Css/Additions.css" />');

$document->addScript('components/com_maianmedia/js/filemanager/mootools-core.js');

$document->addScript('components/com_maianmedia/js/filemanager/mootools-compat-111-121.js');
$document->addScript('components/com_maianmedia/js/filemanager/mootools-more.js');

//$document->addScript(JURI::root().'maian/media/system/js/validate.js');
$document->addScript(JURI::root().'includes/js/joomla.javascript.js');
//$document->addScript(JURI::root().'media/system/js/modal.js');

$document->addScript('components/com_maianmedia/js/overlib.js');

$document->addScript('components/com_maianmedia/js/filemanager/FileManager.js');
$document->addScript('components/com_maianmedia/js/filemanager/Language/Language.'.getLang().'.js');
$document->addScript('components/com_maianmedia/js/filemanager/Additions.js');

$document->addScript('components/com_maianmedia/js/filemanager/Uploader/Fx.ProgressBar.js');
$document->addScript('components/com_maianmedia/js/filemanager/Uploader/Swiff.Uploader.js');

$uri =& JURI::getInstance();

$document->addScript($uri->current().'?option=com_maianmedia&format=raw&controller=tracks&task=uploaderjs');
$document->addScript('components/com_maianmedia/js/request.js');

$document->addCustomTag('
<script type="text/javascript">
	
	function Select_Value_Set(SelectName, Value) {
  		eval(\'SelectObject = document.\' +     SelectName + \';\');
  		for(index = 0; index < SelectObject.length; index++) {
   			if(SelectObject[index].value == Value){
     			SelectObject.selectedIndex = index;
     		}
   		}
   }

 	function setText(field_ID, myValue){	
 		eval(\'SelectObject = document.\' +field_ID + \';\'); 		
 		SelectObject.value = myValue.split(\' \').join(\'_\');
 	}
 	      
   
   function Select_Values() {

  		for(i = 0; i < document.adminForm.total.value; i++) {
  			//alert(\'adminForm.populate_\'+index+" "+document.adminForm.total.value);
   			Select_Value_Set(\'adminForm.populate_\'+i, document.adminForm.album.value);
   		}   
	}
	
</script>


');

$db->setQuery("Select * from #__m15_settings Limit 1");

$settings = $db->loadObject();

$mp3 = $settings->mp3_path;

$preview = JPATH_SITE.$settings->preview_path;

$preview = str_replace('\\', '//', $preview);

//$preview = str_replace('//', '}{', $preview);

$mp3 = str_replace('\\', '//', $mp3);

JHTML::_('behavior.formvalidation');
?>

<?php echo JText::_(_msg_add); ?>

<form action="index.php" enctype="multipart/form-data" method="post"
	name="adminForm">
<div id='props'></div>
<div></div>

<div id="mm_tracks">
<fieldset id="ajaxTracks" class="adminform"><legend><?php echo JText::_(_msg_header5); ?></legend>
<select id="total" name="total"
	onchange="ajaxRequest('tracks', 'index.php?option=com_maianmedia&format=raw&controller=tracks&task=getTracks&num='+this.value, 1,'<?php echo $mp3;?>','<?php echo $preview;?>','<?php echo $sessionid;?>',this.value,'<?php echo getLang();?>');">
	<option value="0">---</option>
	<?php
	for ($i=1; $i<30+1; $i++)
	{
		echo '<option value="'.$i.'" style="padding-left:3px">'.$i.'</option>'."\n";
	}
	?>
</select>&nbsp;<?php echo JText::_(_msg_add3); ?>
<div id="tracks"></div>
</fieldset>
</div>

<input type="hidden" name="option" value="com_maianmedia" /> <input
	type="hidden" name="task" value="" /> <input type="hidden"
	name="boxchecked" value="0" /> <input type="hidden" name="controller"
	value="tracks" /></form>
