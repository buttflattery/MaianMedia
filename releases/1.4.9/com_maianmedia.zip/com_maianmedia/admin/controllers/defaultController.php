<?php
/**
 * @package		Joomla
 * @subpackage	com_maianmedia
 * @copyright	Copyright (C) Vamba & Matthew Thomson. All rights reserved.
 * @license		GNU/GPL
 * @author 		Arelowo Alao (aretimes.com) & David Bennet (maianscriptworld.co.uk)
 * @based on  	com_ignitegallery
 * @author 		Matthew Thomson (ignitejoomlaextensions.com)
 * Joomla! and Maian Music are free software. You must attribute the work in the manner
 * specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 */
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * Hello World Component Controller
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianControllerDefault extends JController
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();
			
		// Register Extra tasks
		//$this->registerTask( 'save' );
	}

	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		// loading view for this task
		parent::display();
	}

	function about()
	{
		// loading view for this task
		jimport( 'joomla.database.database' );
		$pathvalue = JPATH_LIBRARIES.DS.'joomla'.DS.'factory.php';
		require_once( $pathvalue );
		jimport( 'joomla.application.component.view' );
		JToolBarHelper::title(   JText::_( _msg_header2), 'about.png' );
		//$db =& JFactory::getDBO();
		//$$database =& JFactory::getDBO();
		require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'tmpl'.DS.'about.php');
		//echo'test';
	}

	function tools()
	{
		// loading view for this task
		jimport( 'joomla.database.database' );
		require_once(JPATH_LIBRARIES.DS.'joomla'.DS.'factory.php');
		jimport( 'joomla.application.component.view' );

		$tool = JRequest::getVar( 'tool' );

		switch ($tool) {
			case "run_import":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'source'.DS.'run_import.php');
				break;
			case "import_view":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'tmpl'.DS.'import_view.php');
				break;
			case "run_backup":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'source'.DS.'run_backup.php');
				break;
			case "import_backup":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'source'.DS.'import_backup.php');
				break;
			case "backup_view":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'tmpl'.DS.'backup_view.php');
				break;
			case "system_view":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'tmpl'.DS.'system_view.php');
				break;
			case "update_view":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'tmpl'.DS.'update_view.php');
				break;
			case "run_download":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'source'.DS.'run_download.php');
				break;
			case "load_tree":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'source'.DS.'load_tree.php');
				break;
			case "load_root":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'source'.DS.'load_root.php');
				break;
			case "run_update":
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'source'.DS.'run_update.php');
				break;
			case "custom":

				$document = &JFactory::getDocument();
				$document->addCustomTag('<link href="components/com_maianmedia/stylesheet.css" rel="stylesheet" type="text/css" />');

				JToolBarHelper::title(   JText::_(_setup25), 'template.png' );
				JToolBarHelper::save();
				JToolBarHelper::cancel();

				require_once(JPATH_COMPONENT.DS.'views'.DS.'tools'.DS.'custom.php');
				break;
			default:
				JToolBarHelper::title(   JText::_( _msg_header3), 'tools.png' );
				require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'tmpl'.DS.'tools.php');
		}

	}

	function getDownload()
	{
		$file_path = $_GET["file"];
		$fname = basename($_GET["file"]);

		// remove some bad chars
		$asfname = str_replace(array('"',"'",'\\','/'), '', $fname);
		if ($asfname === '') $asfname = 'NoName';

		// file size in bytes
		$fsize = filesize($file_path);

		// file extension
		$fext = strtolower(substr(strrchr($fname,"."),1));

		// get mime type
		$mtype = '';
		// mime type is not set, get from server settings
		if (function_exists('mime_content_type')) {
			$mtype = mime_content_type($file_path);
		}
		else if (function_exists('finfo_file')) {
			$finfo = finfo_open(FILEINFO_MIME); // return mime type
			$mtype = finfo_file($finfo, $file_path);
			finfo_close($finfo);
		}
		if ($mtype == '') {
			$mtype = "application/force-download";
		}


		set_time_limit(0);
		// set headers
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: public");
		header("Content-Description: File Transfer");
		header("Content-Type: $mtype");
		header("Content-Disposition: attachment; filename=\"$asfname\"");
		header("Content-Transfer-Encoding: binary");
		header("Content-Length: " . $fsize);

		// download
		// @readfile($file_path);
		$file = @fopen($file_path,"rb");
		if ($file) {
			while(!feof($file)) {
				print(fread($file, 1024*8));
				flush();
				if (connection_status()!=0) {
					@fclose($file);
					die();
				}
			}
			@fclose($file);
		}
			


		fclose($fh);
	}

	function readfile_chunked() {

		$archiveName = $_GET["file"];

		// set headers
		header("Cache-Control: no-store, must-revalidate");
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		header("Content-Type: audio/mpeg");
		header('Content-Length: ' . filesize($file));

		$file = @fopen($archiveName,"rb");

		if ($file) {
			while(!feof($file)) {

				print(fread($file, 1024*8));
				flush();
				if (connection_status()!=0) {
					@fclose($file);
					die();
				}
			}

			@fclose($file);
		}

	}



	function cancel(){
		jimport( 'joomla.database.database' );
		require_once(JPATH_LIBRARIES.DS.'joomla'.DS.'factory.php');
		jimport( 'joomla.application.component.view' );

		$document = &JFactory::getDocument();
		$document->addCustomTag('<link href="components/com_maianmedia/stylesheet.css" rel="stylesheet" type="text/css" />');

		JToolBarHelper::title(   JText::_( _msg_header3), 'tools.png' );
		require_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'tmpl'.DS.'tools.php');
	}

	function getVersion(){
		require_once(JPATH_COMPONENT.DS.'functions'.DS.'Snoopy.class.php');
			
		//Get current version
		$filename=JPATH_COMPONENT.DS.'maianmedia.xml';
		$output="";
		$file = fopen($filename, "r");
		$bool = true;

		while($bool) {
			//read file line by line into variable
			$output = fgets($file, 4096);
			if(strpos($output ,'<version>')){
				$current_version = substr($output, strpos($output ,'<version>')+9, strpos($output ,'</version>') - 10);
				$bool = false;
			}

		}
		fclose ($file);

		jimport( 'joomla.environment.uri' );

		$uri =& JURI::getInstance();

		$s = new Snoopy();
		$s->read_timeout = 90;
		$s->referer = $uri->root();

		@$s->fetch('http://support.aretimes.com/versions/comprofilerversion.php?currentversion='.urlencode($current_version));
		$version_info = $s->results;
		$version_info_pos = strpos($version_info, ":");

		if ($version_info_pos === false) {
			$version = $version_info;
			$info = null;
		} else {
			$version = substr( $version_info, 0, $version_info_pos );
			$info = substr( $version_info, $version_info_pos + 1 );
		}

		if($s->error || $s->status != 200){

			echo '<font color="red">'. $s->error .' '. ($s->status == -100 ? 'Timeout' : $s->status).'</font>';
		} else if($current_version == $version){
			echo _setup32.' '.$version.'&nbsp;&nbsp;<font color="green">' ._setup31.' '. $current_version . '</font>' . $info;
		} else {
			echo _setup32.' '.$version.'&nbsp;&nbsp;<font color="red">' ._setup31.' '. $current_version . '</font>' . $info;
		}

	}

	function downloadRemoteFile($url,$dir,$file_name = NULL){
		if($file_name == NULL){ $file_name = basename($url);}
		$url_stuff = parse_url($url);
		$port = isset($url_stuff['port']) ? $url_stuff['port'] : 80;

		$fp = fsockopen($url_stuff['host'], $port);
		if(!$fp){ return false;}

		$query  = 'GET ' . $url_stuff['path'] . " HTTP/1.0\n";
		$query .= 'Host: ' . $url_stuff['host'];
		$query .= "\n\n";

		fwrite($fp, $query);
		@set_time_limit(0);
		while ($tmp = fread($fp, 8192))   {
			$buffer .= $tmp;
		}

		preg_match('/Content-Length: ([0-9]+)/', $buffer, $parts);
		$file_binary = substr($buffer, - $parts[1]);
		if($file_name == NULL){
			$temp = explode(".",$url);
			$file_name = $temp[count($temp)-1];
		}
		$file_open = fopen($dir . "/" . $file_name,'w');
		if(!$file_open){ return false;}
		fwrite($file_open,$file_binary);
		fclose($file_open);
		return $file_name;
	}

}//end MaianControllerDefault