<?php
/**
 * @package		Joomla
 * @subpackage	com_maianmedia
 * @copyright	Copyright (C) Vamba & Matthew Thomson. All rights reserved.
 * @license		GNU/GPL
 * @author 		Arelowo Alao (aretimes.com) & David Bennet (maianscriptworld.co.uk)
 * @based on  	com_ignitegallery
 * @author 		Matthew Thomson (ignitejoomlaextensions.com)
 * Joomla! and Maian Music are free software. You must attribute the work in the manner
 * specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 */
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * Hello World Component Controller
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianControllerSettings extends MaianControllerDefault
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		//$this->registerTask( 'save' );
	}

	/* save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('Settings');

		$paypal_mode = JRequest::getVar( 'paypal_mode');
		$log_errors = JRequest::getVar( 'log_errors');
		$ssl_enabled = JRequest::getVar( 'ssl_enabled');
		$smtp = JRequest::getVar( 'smtp');
		$enable_captcha = JRequest::getVar( 'enable_captcha');
		$days = JRequest::getVar( 'days');
		$minpay = JRequest::getVar( 'minpay');
		$ajax = JRequest::getVar( 'ajax');
		$search = JRequest::getVar( 'search');
		$tools = JRequest::getVar( 'tool');
		$download= JRequest::getVar('show_download');
		$nav= JRequest::getVar('show_nav');
		$reset= JRequest::getVar('reset');
		$append_url= JRequest::getVar('append_url');
		$enlargeit= JRequest::getVar('enlargeit');
		$select_lang= JRequest::getVar('select_lang');
		$hide_lightbox= JRequest::getVar('hide_lightbox');

		if(!isset($tools)){

			if($reset == '1'){
				$this->resetAllAlbumHits();
			}

			if(!isset($paypal_mode)){
				JRequest::setVar('paypal_mode', '0');
			}

			if(!isset($log_errors)){
				JRequest::setVar('log_errors', '0');
			}

			if(!isset($ssl_enabled)){
				JRequest::setVar('ssl_enabled', '0');
			}

			if(!isset($smtp)){
				JRequest::setVar('smtp', '0');
			}

			if(!isset($ajax)){
				JRequest::setVar('ajax', '0');
			}

			if(!isset($search)){
				JRequest::setVar('search', '0');
			}

			if(!isset($download)){
				JRequest::setVar('show_download', '0');
			}

			if(!isset($append_url)){
				JRequest::setVar('append_url', '0');
			}

			if(!isset($enlargeit)){
				JRequest::setVar('enlargeit', '0');
			}
				
			if(!isset($nav)){
				JRequest::setVar('show_nav', '0');
			}
				
			if(!isset($select_lang)){
				JRequest::setVar('select_lang', '0');
			}
				
			if(!isset($hide_lightbox)){
				JRequest::setVar('hide_lightbox', '0');
			}

			if(!isset($enable_captcha)){
				JRequest::setVar('enable_captcha', '0');
			}

			if($days == '0' || !isset($days)){
				JRequest::setVar('days', '14');
			}

			if($minpay == '0' || !isset($minpay)){
				JRequest::setVar('minpay', '10.00');
			}
		}

		if ($model->store($post)) {
			if(!isset($tools)){
				$msg = JText::_( 'Settings Saved!' );
			}else{
				$msg = JText::_( 'Custom Page Text Saved!' );
			}

		}else{
			$msg = JText::_( 'There was an error saving the settings' );
		}


		// Check the table in so it can be edited.... we are done with it anyway
		if(isset($tools)){
			$link = 'index.php?option=com_maianmedia&task=tools';
		}else{
			$link = 'index.php?option=com_maianmedia&controller=settings&view=settings';
		}
		$this->setRedirect($link, $msg);
	}

	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		// loading view for this task
		//$group_path = JPATH_COMPONENT.DS.'views'.DS.'default.view.php';
		//require_once($group_path);
		JRequest::setVar( 'layout', 'form'  );


		parent::display();
	}

	function resetAllAlbumHits()
	{

		$db =& JFactory::getDBO();
		$db->setQuery("UPDATE #__m15_albums SET hits = '0'");
		$db->query();
	}

	function display_player()
	{
		jimport( 'joomla.environment.uri' );

		$uri =& JURI::getInstance();
		$root_url = $uri->root(); //root url
		$root_base = $uri->base(); //base url
		$root_current = $uri->current(); //current url pathj

		include_once(JPATH_COMPONENT_SITE.DS.'players'.DS.'mp3players.php');

		$player_type = JRequest::getVar( 'player_type' );

		echo mp3players::getplayer($player_type, "test.mp3", $player_type, 1);

	}//end display_player
}