		<?php echo $tplDisplayData['MUSIC_TEXT']; ?> 
		<h2 class="title"><?php echo $tplDisplayData['MUSIC_TITLE']; ?></h2>
			<br /><?php echo $tplDisplayData['MUSIC_MESSAGE']; ?><br/><br/>
			<?php echo $tplDisplayData['MUSIC_DATA']; ?>
			<?php echo $tplDisplayData['PAGE_NUMBERS']; ?>
