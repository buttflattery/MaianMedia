<?php defined( '_JEXEC' ) or die( 'Restricted access' );
$uri =& JURI::getInstance();
$mData ="";
foreach($q_music as $MUSIC){
	$image_link = $uri->root().'components/com_maianmedia/media/icons/no_picture.png';
	$more_info_image = $uri->root().'components/com_maianmedia/media/icons/more_info.png';

	if($params['more_info'] == '0'){
		$style = 'display: none;';
	}else{
		$style = '';
	}

	$images_dimensions = '';

	if($MUSIC->image != "" && $MUSIC->image !="http://"){
		$image_link = $MUSIC->image;
		$images_dimensions = 'height=75px width=75px';
	}

	$find     = array('{url}','{more_info_image}','{label}','{dimensions}','{album_image}','{more_info}','{artist}','{album_title}','{tracks}','{style}');
	$replace  = array(JRoute::_('index.php?option=com_maianmedia&view=album&amp;album='.$MUSIC->id),$more_info_image,$MUSIC->label,$images_dimensions,
	$image_link,JText::_( _msg_music2),cleanData($MUSIC->artist),cleanData($MUSIC->name),str_replace("{count}",getTrackCount($MUSIC->id),JText::_( _msg_music3)), $style);
	$mData .= str_replace($find,$replace,
	file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'album_data.html'));
}
?>