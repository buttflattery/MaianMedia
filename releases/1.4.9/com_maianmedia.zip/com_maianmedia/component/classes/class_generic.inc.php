<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Script: Maian Music v1.2
Written by: David Ian Bennett
E-Mail: support@maianscriptworld.co.uk
Website: http://www.maianscriptworld.co.uk

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

This File: class_generic.inc.php
Description: Generic Class

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


class genericOptions {

	// Check if field data is valid..
	function field_check($num,$num2,$data) {
		if ($num2>0) {
			if ($data=="" || $data=="0" || $data=="http://" || strlen($data)<$num || strlen($data)>$num2) {
				return true;
			} else {
				return false;
			}
		} else {
			if ($data=="" || $data=="http://" || $data=="0") {
				return true;
			} else {
				return false;
			}
		}
	}


	// Check if e-mail field is valid..
	function is_email_valid($email) {
		if (!eregi("^([a-z]|[0-9]|\.|-|_)+@([a-z]|[0-9]|\.|-|_)+\.([a-z]|[0-9]){2,4}$", $email)) {
			return true;
		} else {
			return false;
		}
	}

	// Generates random alphanumeric string..
	function random_data($num) {
		$p = substr(md5(uniqid(rand(),1)), 3, $num);

		return strtoupper($p);
	}

	// Strip slashes if magic quotes are on..
	function strip_slashes($data) {
		return (get_magic_quotes_gpc() ? stripslashes($data) : $data);
	}

	// Prepares array data for safe import..
	function safe_import_callback($data) {
		return array_map('mysql_real_escape_string',$data);
	}

	// Converts certain chars to character entities
	function char_entities($data) {
		return htmlspecialchars($data);
	}

	// Prevents SQL injection..
	function add_slashes($data) {
		if (get_magic_quotes_gpc()) {
			$data = stripslashes($data);
		}
		return mysql_real_escape_string($data);
	}


	// Define the client's browser type..
	function get_browser_type() {
		$USER_BROWSER_AGENT = "";

		if (ereg('OPERA(/| )([0-9].[0-9]{1,2})', strtoupper($_SERVER["HTTP_USER_AGENT"]), $log_version)) {
			$USER_BROWSER_AGENT = 'OPERA';
		} else if (ereg('MSIE ([0-9].[0-9]{1,2})',strtoupper($_SERVER["HTTP_USER_AGENT"]), $log_version)) {
			$USER_BROWSER_AGENT = 'IE';
		} else if (ereg('OMNIWEB/([0-9].[0-9]{1,2})', strtoupper($_SERVER["HTTP_USER_AGENT"]), $log_version)) {
			$USER_BROWSER_AGENT = 'OMNIWEB';
		} else if (ereg('MOZILLA/([0-9].[0-9]{1,2})', strtoupper($_SERVER["HTTP_USER_AGENT"]), $log_version)) {
			$USER_BROWSER_AGENT = 'MOZILLA';
		} else if (ereg('KONQUEROR/([0-9].[0-9]{1,2})', strtoupper($_SERVER["HTTP_USER_AGENT"]), $log_version)) {
			$USER_BROWSER_AGENT = 'KONQUEROR';
		} else {
			$USER_BROWSER_AGENT = 'OTHER';
		}

		return $USER_BROWSER_AGENT;
	}
	/*
	 // Define MIME-TYPE according to target Browser..
	 function get_mime_type($file) {
	 $USER_BROWSER_AGENT = $this->get_browser_type();

	 $mime_type = ($USER_BROWSER_AGENT == 'IE' || $USER_BROWSER_AGENT == 'OPERA')
	 ? 'application/octetstream'
	 : 'application/octet-stream';

	 return $mime_type;
	 //	require_once(JPATH_ADMINISTRATOR.DS.'components'.'com_maianmedia'.DS.'classes'.'Assets'.DS.'getid3'.DS.'getid3.php');

	 //	$getid3 = new getID3();
	 //	$getid3->Analyze($file);


	 return $mime_type;
	 }*/

	function get_mime_type($filename){

		//if(function_exists('mime_content_type'))
		//return mime_content_type($file);

		$mime_types = array(

            'txt' => 'text/plain',
            'htm' => 'text/html',
            'html' => 'text/html',
            'php' => 'text/html',
            'css' => 'text/css',
            'js' => 'application/javascript',
            'json' => 'application/json',
            'xml' => 'application/xml',
            'swf' => 'application/x-shockwave-flash',
            'flv' => 'video/x-flv',

		// images
            'png' => 'image/png',
            'jpe' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'jpg' => 'image/jpeg',
            'gif' => 'image/gif',
            'bmp' => 'image/bmp',
            'ico' => 'image/vnd.microsoft.icon',
            'tiff' => 'image/tiff',
            'tif' => 'image/tiff',
            'svg' => 'image/svg+xml',
            'svgz' => 'image/svg+xml',

		// archives
            'zip' => 'application/zip',
            'rar' => 'application/x-rar-compressed',
            'exe' => 'application/x-msdownload',
            'msi' => 'application/x-msdownload',
            'cab' => 'application/vnd.ms-cab-compressed',

		// audio/video
            'mp3' => 'audio/mpeg',
            'qt' => 'video/quicktime',
            'mov' => 'video/quicktime',

		// adobe
            'pdf' => 'application/pdf',
            'psd' => 'image/vnd.adobe.photoshop',
            'ai' => 'application/postscript',
            'eps' => 'application/postscript',
            'ps' => 'application/postscript',

		// ms office
            'doc' => 'application/msword',
            'rtf' => 'application/rtf',
            'xls' => 'application/vnd.ms-excel',
            'ppt' => 'application/vnd.ms-powerpoint',

		// open office
            'odt' => 'application/vnd.oasis.opendocument.text',
            'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
		);

		$ext = strtolower(array_pop(explode('.',$filename)));
		if (array_key_exists($ext, $mime_types)) {
			return $mime_types[$ext];
		}
		elseif (function_exists('finfo_open')) {
			$finfo = finfo_open(FILEINFO_MIME);
			$mimetype = finfo_file($finfo, $filename);
			finfo_close($finfo);
			return $mimetype;
		}
		else {
			return 'application/octet-stream';
		}
	}

	// Define new line character based on op system..
	function define_newline() {
		$newline = "\r\n";

		if (strstr(strtolower($_SERVER["HTTP_USER_AGENT"]), 'win')) {
			$newline = "\r\n";
		} else if (strstr(strtolower($_SERVER["HTTP_USER_AGENT"]), 'mac')) {
			$newline = "\r";
		} else {
			$newline = "\n";
		}

		return $newline;
	}

}

?>
