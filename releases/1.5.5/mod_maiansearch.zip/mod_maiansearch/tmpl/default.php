<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>
<!-- Music Search from http://www.AreTimes.com -->
<div id="search_box">
<form method="get" action="index.php?option=com_maianmedia"><input
	type="hidden" name="option" value="com_maianmedia" /> <input
	type="hidden" name="task" value="search" /> <input id="textfield1"
	type="text" class="searchBox" name="keywords" value="" /> <input
	id="submit1" class="formButton" type="submit" value="Search"
	title="Search" /></form>
</div>
