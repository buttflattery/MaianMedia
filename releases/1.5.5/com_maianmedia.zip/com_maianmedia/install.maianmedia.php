<?php

/**
 * @package		Joomla
 * @subpackage	com_maianmedia
 * @copyright	Copyright (C) AreTimes & Maian Script World. All rights reserved.
 * @license		GNU/GPL
 * @author 		Arelowo Alao (aretimes.com) & David Bennet (maianscriptworld.co.uk)
 * Joomla! and Maian Music are free software. You must attribute the work in the manner
 * specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

function com_install() {

	$db =& JFactory::getDBO();
	$uri =& JURI::getInstance();

	$document = &JFactory::getDocument();
	$document->addScript($uri->current().'?option=com_maianmedia&format=raw&controller=tracks&task=uploaderjs');

	$db->setQuery( "SELECT id FROM #__components WHERE link= 'option=com_maianmedia'" );
	$id = $db->loadResult();

	if(!isset($id)){
		$db->setQuery( "SELECT id FROM #__components WHERE link= 'option=com_maian15'" );
		$id = $db->loadResult();
	}
	
	//if(!isset($id)){
		//$db->setQuery( "SELECT extension_id FROM #__extensions WHERE element='com_maianmedia'" );
		//$id = $db->loadResult();
	//}

	//get id
	$db->setQuery( "UPDATE #__menu SET componentid = '$id' WHERE link LIKE '%com_maianmedia%'" );
	$db->query();

	$db->setQuery( "Select * from #__m15_settings WHERE id = 1");
	$settings = $db->loadObject();
	if(!isset($settings->id)){
		//add info for settings
		$db->setQuery( "INSERT INTO `#__m15_settings` (`id`, `website_name`, `email_address`, `homepage_url`, `install_url`, `language`, `about`, `licence`, `music`, `enable_captcha`, `mod_rewrite`, `mp3_path`, `preview_path`, `rssfeeds`, `poplinks`, `page_expiry`, `download_expiry`, `paypal_mode`, `paypal_currency`, `paypal_email`, `page_style`, `log_errors`, `ssl_enabled`, `smtp`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `player`, `pdt`, `default_page`, `days`, `paypal_email2`, `pdt2`, `minpay`, `freeText`, `search`, `ajax`) VALUES
		(1, 'Our Music Download Store', 'example@localhost.com', '', '', 'english.php', 'Thank you for your interest in our music. Use the links above to browse  our collection of albums. You can purchase single tracks or whole albums by using the buttons provided. You can also preview mp3 files before you buy.<br /> <br /> All payments are securely handled by Paypal and you don`t need a Paypal account to<br /> <div id=\"paypal_credit\">  	<img src=\"/components/com_maianmedia/media/thumbs/credit-cards.gif\" alt=\"All Major Credit Cards\" width=\"500\" height=\"45\" /></div> 	', '', '', '1', '0', '//home//user//tracks', '//preview', 50, 5, 10, 10, '0', 'USD', 'example@localhost.com', 'test', '0', '0', '0', 'localhost', '', '', '25', 1, '', '1', 14, '', '', '10.00', '', '0', '1')" );
		$db->query();
	}

	$db->setQuery( "Select * from #__m15_pages WHERE id = 1");
	$pages = $db->loadObject();
	if(!isset($pages->id)){
		//add info for settings
		$db->setQuery("INSERT INTO `#__m15_pages` (`id`, `name`, `text`) VALUES
					(1, 'about', '<p>Thank you for your interest in our music. Use the links above to browse  our collection of albums. You can purchase single tracks or whole albums by using the buttons provided. You can also preview mp3 files before you buy.<br /> <br /> All payments are securely handled by Paypal and you don`t need a Paypal account to</p>\r\n<div id=\"paypal_credit\"><img src=\"components/com_maianmedia/media/icons/credit-cards.gif\" border=\"0\" alt=\"All Major Credit Cards\" width=\"500\" height=\"45\" /></div>');");
		$db->query();
	}

	$db->setQuery( "Select * from #__m15_pages WHERE id = 2");
	$pages = $db->loadObject();
	if(!isset($pages->id)){
		//add info for settings
		$db->setQuery("INSERT INTO `#__m15_pages` (`id`, `name`, `text`) VALUES
					(2, 'license', '<p>All information and data contained within this music store are the property of [Your Music Store]., whether or not a copyright notice appears on the screen displaying this information. Users of the [Your Music Store] may save and use information contained therein only for personal use. No other use, including reproduction, retransmission, or editing, of [Your Music Store] information may be made without prior written permission of [Your Music Store]., which may be requested by contacting [Your Music Store].</p>');");
		$db->query();
	}

	$db->setQuery( "Select * from #__m15_pages WHERE id = 3");
	$pages = $db->loadObject();
	if(!isset($pages->id)){
		//add info for settings
		$db->setQuery("INSERT INTO `#__m15_pages` (`id`, `name`, `text`) VALUES
					(3, 'music', '<p></p>');");
		$db->query();
	}










	$db->setQuery( "Select * from #__m15_pages WHERE id = 4");
	$pages = $db->loadObject();
	if(!isset($pages->id)){
		//add info for settings
		$db->setQuery("INSERT INTO `#__m15_pages` (`id`, `name`, `text`) VALUES
					(4, 'free', '<p>Below is a list of tracks available for free download</p>');");
		$db->query();
	}

	//update old maian15 links
	$db->setQuery( "UPDATE #__menu SET link = 'index.php?option=com_maianmedia&view=music' WHERE link LIKE 'index.php?option=com_maian15&view=music'" );
	$db->query();

	$db->setQuery( "UPDATE #__menu SET link = 'index.php?option=com_maianmedia&view=contact' WHERE link LIKE 'index.php?option=com_maian15&view=contact'" );
	$db->query();

	$db->setQuery( "UPDATE #__menu SET link = 'index.php?option=com_maianmedia&view=freebie' WHERE link LIKE 'index.php?option=com_maian15&view=freebie'" );
	$db->query();

	$db->setQuery( "UPDATE #__menu SET link = 'index.php?option=com_maianmedia&view=mostpop' WHERE link LIKE 'index.php?option=com_maian15&view=mostpop'" );
	$db->query();

	$db->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmedia/media/thumb/record.png' WHERE id = '$id'" );
	$db->query();

	//add new fields for upgrade
	$fh = fopen(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_maianmedia'.DS.'install.mysql.sql', 'r');
	$sql_file = fread($fh, filesize(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_maianmedia'.DS.'install.mysql.sql'));
	fclose($fh);

	$queries = explode(";", trim($sql_file));

	foreach($queries AS $query){

		if($query != ''){
			$start = strpos($query,"`" );
			$end = strpos($query, "`", $start+1);

			$table_name = substr($query, $start +1, $end - $start -1);

			$start = strpos($query,"(" );
			$end = strrpos($query, "PRIMARY KEY (`id`)");
			$input = substr($query, $start + 1, $end - $start -1);

			$lines = explode("\r\n", trim($input));
			//echo 'Scaning '.$table_name;
			foreach($lines AS $line){
				$start = strpos($line,"`" );
				$end = strpos($line, "`", $start+1);

				$field = substr($line, $start +1, $end - $start -1);

				$db->setQuery("SHOW COLUMNS FROM $table_name LIKE '$field'");
				$search = $db->loadObject();
					
				if(!isset($search)){

					$sql= 'ALTER TABLE '.$table_name.' ADD '.trim(str_replace(array("\r", "\r\n", "\n"), '', trim($line)));
					$sql= substr($sql, 0, strlen($sql) - 1).';';
					//echo 'Adding '.$field.' to '.$table_name.'<br>';
					$db->setQuery($sql);
					$db->query();
				}else{
					//echo 'Found '.$field.' in '.$table_name.'<br>';
				}
			}
		}

	}


	echo '<div id="maian_content"><img src="'.$uri->root().'/administrator/components/com_maianmedia/images/are_logo.png"></img><br>';
	echo '<p>To use this system you must have a paypal bussiness account<br>';
	echo 'Log in to your Paypal account and click "Profile" from the "My Account" menu tab.<br><br>';
	echo '<b>Click "Selling Preferences --> "Instant Payment Notification Preferences"</b><br>';
	echo '<p>On the next screen, click "Edit" and check the box to enable the IPN system and in the "Notification URL" box, enter the full URL to your notification page.<br><br>';
	echo '<b>'.$uri->root().'index.php?option=com_maianmedia&amp;section=paypal&amp;view=notify</b><br><br>';
	echo 'From the "Profile" tab, select "Selling Preferences" --> "Website Payment Preferences" the URL for the auto return function is as follows:<br><br>';
	echo '<b>'.$uri->root().'index.php?option=com_maianmedia&amp;section=paypal&amp;view=thanks</b><br><br>';
	echo 'Be sure to turn on "Auto Return" and "Payment Data Transfer".  Copy your pin for use in the application</p></div>';

	$db->setQuery( "SELECT * FROM #__mm_settings" );
	$data = $db->loadObjectList();

	if(isset($data)){
		$document->addScript( 'components/com_maianmedia/js/request.js' );
		echo '<div class="button2-right">
<div class="start">
<a href="javascript:ajaxRequest(\'import\', \'index.php?option=com_maianmedia&amp;task=tools&amp;format=raw&amp;tool=run_import\', 1)"
	title="Start" onclick="">Import 1.0 Tables</a></div>
</div><br><br><div style="float:left; text-align:left;" id="import"></div>';
	}

	$db->setQuery( "SELECT * FROM #__mbak_settings" );
	$data = $db->loadObjectList();

	if(isset($data)){

		$document->addScript( 'components/com_maianmedia/js/request.js' );
		echo '<div class="button2-right">
<div class="start">
<a href="javascript:ajaxRequest(\'backup\', \'index.php?option=com_maianmedia&amp;task=tools&amp;format=raw&amp;tool=import_backup\', 1)"
	title="Start" onclick="">Import Table Backup</a></div>
</div><br><br><div style="float:left; text-align:left;" id="backup"></div>';
	}

}
?>