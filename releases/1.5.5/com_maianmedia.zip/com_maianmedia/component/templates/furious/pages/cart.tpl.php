<?php JHTML::_( 'behavior.mootools' );?>  
      <h2 class="title"><?php  echo $tplDisplayData['CART_TEXT']; ?> </h2><br />
			<?php  echo $tplDisplayData['CART_MESSAGE']; ?><br /><br />
			<?php  echo $tplDisplayData['CART_DATA']; ?>
			<?php  echo $tplDisplayData['CART_BUTTONS']; ?>

