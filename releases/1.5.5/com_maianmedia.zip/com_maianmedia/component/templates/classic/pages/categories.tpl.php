
		<div id="mm_main">
		<?php echo $tplDisplayData['CAT_TEXT']; ?> 
		<h2 class="title"><?php echo $tplDisplayData['CAT_TITLE']; ?></h2>
			<br /><?php echo $tplDisplayData['CAT_MESSAGE']; ?><br/><br/>
			<?php echo $tplDisplayData['CAT_DATA']; ?>
			<?php echo $tplDisplayData['PAGE_NUMBERS']; ?>
		</div>
