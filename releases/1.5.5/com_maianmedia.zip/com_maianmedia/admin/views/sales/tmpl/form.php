<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php

$document = &JFactory::getDocument();
$document->addScript( 'components/com_maianmedia/js/request.js' );
$document->addCustomTag('<link href="components/com_maianmedia/stylesheet.css" rel="stylesheet" type="text/css" />');
$mainframe = &JFactory::getApplication();
$lim   = $mainframe->getUserStateFromRequest("com_maianmedia.limit", 'limit', 5, 'int'); 

$lim0  = JRequest::getVar('limitstart', 0, '', 'int');
jimport('joomla.html.pagination');
$pageNav = new JPagination(JRequest::getVar('pagnation'), $lim0, $lim );
JHTML::_('behavior.modal', 'a.modal-button');
$db =& JFactory::getDBO();

$uri =& JURI::getInstance();
$sql = JRequest::getVar('sql');
// Query database for paypal information..
 $db->setQuery("SELECT *,DATE_FORMAT(pay_date,'%e %b %Y') AS p_date 
                        FROM #__m15_paypal
                        WHERE active_cart = '1'
                        ".(isset($sql) ? $sql : '')."
                        LIMIT $lim0,$lim");
 $q_paypal = $db->loadObjectList();
 $q_paypal = $this->sales;
 $settings = $this->settings;
 
 $order = JRequest::getVar('order');
 
?>
<form id="adminForm" action="index.php" method="post" name="adminForm">
    <fieldset class="adminform">
    <p><?php echo JText::_( _msg_sales); ?></p>

		<b><?php echo JText::_( _msg_statistics2); ?></b>
       <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
       <option style="padding-left:3px" value="index.php?option=com_maianmedia&controller=sales&view=sales">---</option>
       <option style="padding-left:3px" value="index.php?option=com_maianmedia&controller=sales&view=sales&fnc=sort&amp;order=date_desc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($order)  && $order=='date_desc' ? ' selected="selected"' : ''); ?>><?php echo JText::_( _msg_sales4); ?></option>
       <option style="padding-left:3px" value="index.php?option=com_maianmedia&controller=sales&view=sales&fnc=sort&amp;order=date_asc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($order)  && $order=='date_asc' ? ' selected="selected"' : ''); ?>><?php echo JText::_( _msg_sales5); ?></option>
       <option style="padding-left:3px" value="index.php?option=com_maianmedia&controller=sales&view=sales&fnc=sort&amp;order=tracks<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($order)  && $order=='tracks' ? ' selected="selected"' : ''); ?>><?php echo JText::_( _msg_sales6); ?></option>
       <option style="padding-left:3px" value="index.php?option=com_maianmedia&controller=sales&view=sales&fnc=sort&amp;order=downloads<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($order)  && $order=='downloads' ? ' selected="selected"' : ''); ?>><?php echo JText::_( _msg_sales7); ?></option>
       <option style="padding-left:3px" value="index.php?option=com_maianmedia&controller=sales&view=sales&fnc=sort&amp;order=gross_desc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($order)  && $order=='gross_desc' ? ' selected="selected"' : ''); ?>><?php echo JText::_( _msg_sales8); ?></option>
       <option style="padding-left:3px" value="index.php?option=com_maianmedia&controller=sales&view=sales&fnc=sort&amp;order=gross_asc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($order)  && $order=='gross_asc' ? ' selected="selected"' : ''); ?>><?php echo JText::_( _msg_sales9); ?></option>
       <option style="padding-left:3px" value="index.php?option=com_maianmedia&controller=sales&view=sales&fnc=sort&amp;order=name_asc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($order)  && $order=='name_asc' ? ' selected="selected"' : ''); ?>><?php echo JText::_( _msg_sales10); ?></option>
       <option style="padding-left:3px" value="index.php?option=com_maianmedia&controller=sales&view=sales&fnc=sort&amp;order=name_desc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($order)  && $order=='name_desc' ? ' selected="selected"' : ''); ?>><?php echo JText::_( _msg_sales11); ?></option>
       </select>
       
    <table  class="adminlist">
    <thead>
    	<tr>
			<th><?php echo JText::_( _msg_sales41); ?></th>
			<th><?php echo JText::_( _msg_public_header4); ?></th>
			<th><?php echo JText::_( _msg_header7); ?></th>
			<th><?php echo JText::_( _msg_sales42); ?></th>
			<th><?php echo JText::_( _msg_sales43); ?></th>
    	</tr>
    </thead>
    <?php
    JHTML::_('behavior.modal', 'a.modal');
    if (count($q_paypal)>0)
    {		
    	$i = 0;
    foreach ($q_paypal AS $PAYPAL){
    	$i++;
    	$checked 	= JHTML::_('grid.id',   $i, $PAYPAL->id );
        $purchases = explode("||", $PAYPAL->purchases);
      ?>
      <tr>
        <td align="left" style="padding:5px" width="40%">
        <b><?php echo cleanData($PAYPAL->first_name.' '.$PAYPAL->last_name); ?></b><br>
        <?php echo $PAYPAL->p_date; ?>
        </td>
        <td align="center" style="padding:5px" width="20%">
        <?php echo JText::_( _msg_sales20.': '.($PAYPAL->total_albums>0 ? '<b>'.$PAYPAL->total_albums.'</b>' : '<b>'.$PAYPAL->total_albums.'</b>')); ?><br>
        <?php echo JText::_( _msg_sales21.': '.($PAYPAL->total_tracks>0 ? '<b>'.$PAYPAL->total_tracks.'</b>' : '<b>'.$PAYPAL->total_tracks.'</b>')); ?>
        </td>
        <td align="center" style="padding:5px;font-size:14px;font-weight:bold" width="15%"><?php echo get_cur_symbol(number_format($PAYPAL->gross-$PAYPAL->fee,2),$settings->paypal_currency); ?><br>
        <span style="font-size:10px;font-weight:normal"><?php echo get_cur_symbol(number_format($PAYPAL->gross,2),$settings->paypal_currency); ?> - <?php echo get_cur_symbol(number_format($PAYPAL->fee,2),$settings->paypal_currency); ?></span></td>
        <td align="center" style="padding:5px" width="20%">
        <span id="mm_view_sale"><a class="modal-button" href="index.php?option=com_maianmedia&controller=sales&format=raw&task=modal&amp;switch=view&id=<?php echo $PAYPAL->id; ?>" rel="{handler: 'iframe', size: {x: 570, y: 400}}" title="<?php echo JText::_( _msg_sales22); ?> - <?php echo cleanData($PAYPAL->first_name.' '.$PAYPAL->last_name); ?>"><img src="<?php echo $uri->root(); ?>/administrator/components/com_maianmedia/images/view_sale.png" alt="<?php echo JText::_( _msg_sales22); ?>" title="<?php echo JText::_( _msg_sales22); ?>" class="image_pad"></a></span> 
        <span id="mm_contact"><a class="modal-button" href="index.php?option=com_maianmedia&controller=sales&format=raw&task=modal&amp;switch=contact&id=<?php echo $PAYPAL->id; ?>" rel="{handler: 'iframe', size: {x: 570, y: 400}}" title="<?php echo JText::_( _msg_sales23); ?> - <?php echo cleanData($PAYPAL->first_name.' '.$PAYPAL->last_name); ?>"><img src="<?php echo $uri->root(); ?>/administrator/components/com_maianmedia/images/contact_buyer.png" alt="<?php echo JText::_( _msg_sales23); ?>" title="<?php echo JText::_( _msg_sales23); ?>" class="image_pad"></a></span>
        <td align="center" style="padding:5px"><?php echo $checked; ?></td>
		</tr>
     <?php
      }

    }
    else
    {
    ?><br>
    <table width="100%" cellspacing="0" cellpadding="0" style="margin-bottom:3px">
    <tr>
        <td align="center" style="padding:5px"><?php echo JText::_( _msg_sales13); ?></td>
    </tr>
    
    </table>
    <?php
    }
    
    ?>
    <tfoot>
			<tr>
				<td colspan="15">
					<?php echo $pageNav->getListFooter(); ?>
				</td>
			</tr>
			</tfoot>
    </table>
     </fieldset>
     	<input type="hidden" name="fnc" value="<?php echo JRequest::getVar('fnc'); ?>" />
     	<input type="hidden" name="order" value="<?php echo JRequest::getVar('order'); ?>" />
		<input type="hidden" name="option" value="com_maianmedia" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="controller" value="sales" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="view" value="sales" />
		<?php echo JHTML::_( 'form.token' ); ?>
		</form>