<?php
/**
 * Hello View for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewSearch extends JView
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		//$sales =& $this->get('Data');
		
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__m15_settings");
		$settings = $db->loadObjectList();
		
		JToolBarHelper::title(   JText::_(_msg_header7), 'search_sales.png' );
		$this->assignRef('settings', $settings[0]);
		//$this->assignRef('sales', $sales);

		parent::display($tpl);
	}
}