<?php defined('_JEXEC') or die('Restricted access');

$SETTINGS = &$this->get('Data');

$lines = explode("\n", trim($SETTINGS->extra_params));

for ($i=0; $i<count($lines);$i++){
	list($key,$val) = explode("=", $lines[$i]);
	$params [trim(urldecode($key))] = trim(urldecode($val));
}

// Load language files..
$lang = opendir(JPATH_COMPONENT_SITE.DS.'lang'.DS);
$langs = array();
while ($READ = readdir($lang))
{
	if ($READ != "." && $READ != ".." && $READ != "index.html" && $READ != ".svn") {
		$langs[$READ]= $READ;
		//echo '<option'.(($READ == $SETTINGS->language) ? ' selected' : '').'>'.substr($READ, 0, strpos($READ, '.')).'</option>'."\n";
	}
}

closedir($lang);

$skins = array();
$tpl = opendir(JPATH_COMPONENT_SITE.DS.'templates'.DS);

while (false !== ($file = readdir($tpl))) {
	if ($file != "." && $file != ".." && $file != ".svn") {

		if (is_dir(JPATH_COMPONENT_SITE.DS.'templates'.DS.$file)) {
			// found a directory, do something with it?
			$skins[$file]= $file;
		}
	}
}

closedir($tpl);

$popP = "";
$musicP = "";
if ($SETTINGS->default_page == 0) {
	$popP = 'checked';
}
else if ($SETTINGS->default_page == 1) {
	$musicP = 'checked';
}

$radioBox = '<checked>';
$uri =& JURI::getInstance();
JHTML::_('behavior.modal', 'a.modal');
?>

<form id="adminForm" action="index.php" method="post" name="adminForm">
<p><?php echo _msg_settings; ?></p>
<fieldset class="adminform"><legend><?php echo JText::_( _msg_settings2 ); ?></legend>
<table class="admintable">
	<tr>
		<td width="100" align="right" class="key"><label for="greeting"> <?php echo JText::_( _msg_settings41 ); ?>:
		</label></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="default_page" value="0" <?php echo $popP; ?>> <?php echo JText::_(_msg_settings42); ?>
		</input> <input type="radio" name="default_page" value="1"
		<?php echo $musicP; ?>> <?php echo JText::_(_msg_settings43); ?> </input>
		<?php echo toolTip(_msg_javascript,_msg_javascript39); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings3); ?></td>
		<td align="left" style="padding: 5px" width="70%"><input
			class="formBox" type="text" name="website_name" maxlength="250"
			size="30" value="<?php echo cleanData($SETTINGS->website_name); ?>" />
		</td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings4); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="email_address" maxlength="250" size="30"
			value="<?php echo cleanData($SETTINGS->email_address); ?>" /></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings7); ?></td>
		<td align="left" style="padding: 5px"><select name="language">
		<?php
			
		foreach ($langs AS $key => $value) {
			echo '<option'.(($key == $SETTINGS->language) ? ' selected' : '').'>'.substr($key, 0, strpos($key, '.')).'</option>'."\n";
		}

		?>
		</select></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_frontpage_lang); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="select_lang" value="1"
			<?php echo ($SETTINGS->select_lang == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="select_lang" value="0"
		<?php echo ($SETTINGS->select_lang == '0' || $SETTINGS->select_lang == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript_lang); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_('template'); ?></td>
		<td align="left" style="padding: 5px"><select
			onchange="setTpl(this.value);" name="homepage_url">
			<?php

			foreach ($skins AS $key => $value) {
				echo '<option value="'.$key.'" style="padding-left:3px"'.($SETTINGS->homepage_url==$key ? ' selected' : '').'>'.$value.'</option>'."\n";
			}

			?>
		</select><a style="padding-left: 5px" class="modal" id="tplParams"
			href="index.php?option=com_maianmedia&controller=settings&format=raw&task=tplParams&skin=<?php echo ($SETTINGS->homepage_url ? $SETTINGS->homepage_url : 'classic')?>"
			rel="{handler: 'iframe', size: {x: 570, y: 400}}"
			title="<?php echo JText::_(_msg_header3)?>"><?php echo JText::_( _msg_header3) ?></a></td>
	</tr>

	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings26); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="rssfeeds" maxlength="3" size="30"
			style="width: 10%"
			value="<?php echo cleanData($SETTINGS->rssfeeds); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript36); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings27); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="poplinks" maxlength="3" size="30"
			style="width: 10%"
			value="<?php echo cleanData($SETTINGS->poplinks); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript37); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings46); ?></td>
		<td align="left" style="padding: 5px"><input type="text" name="days"
			maxlength="3" size="30" style="width: 10%"
			value="<?php echo cleanData($SETTINGS->days); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript41); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings47); ?></td>
		<td align="left" style="padding: 5px"><input type="radio" name="ajax"
			value="1" <?php echo ($SETTINGS->ajax == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="ajax" value="0"
		<?php echo ($SETTINGS->ajax == '0' || $SETTINGS->ajax == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript40); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings8); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="enable_captcha" value="1"
			<?php echo ($SETTINGS->enable_captcha == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="enable_captcha" value="0"
		<?php echo ($SETTINGS->enable_captcha == '0' || $SETTINGS->enable_captcha == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript3); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings48); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="search" value="1"
			<?php echo ($SETTINGS->search == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="search" value="0"
		<?php echo ($SETTINGS->search == '0' || $SETTINGS->search == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript44); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings52); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="show_nav" value="1"
			<?php echo ($SETTINGS->show_nav == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="show_nav" value="0"
		<?php echo ($SETTINGS->show_nav == '0' || $SETTINGS->show_nav == '' ? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript45); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings53); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="enlargeit" value="1"
			<?php echo ($SETTINGS->enlargeit == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="enlargeit" value="0"
		<?php echo ($SETTINGS->enlargeit == '0' || $SETTINGS->enlargeit == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript46); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_continue); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="shopbutton" value="1"
			<?php echo ($SETTINGS->shopbutton == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="shopbutton" value="0"
		<?php echo ($SETTINGS->shopbutton == '0' || $SETTINGS->shopbutton == '' ? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript_continue); ?></td>
	</tr>
</table>
</fieldset>

<fieldset class="adminform"><legend><?php echo JText::_( _msg_settings38 ); ?></legend>
<table class="admintable">
	<tr>

		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings39); ?></td>

		<td align="left" style="padding: 5px"><select STYLE="width: 230px"
			id="player" name="player"
			onChange="ajaxRequest('flash_player', 'index.php?option=com_maianmedia&format=raw&&controller=settings&task=display_player&player_type='+this.value, 1);">
			<?php

			$key = 1;
			$skin = 0;

			while($key <=12) {

				if($key == 1){
					$value = 'Premium Beat + Skin 1';
					$skin = 1;
				}

				if($key == 2){
					$value = 'Premium Beat + Skin 2';
					$skin = 2;
				}

				if($key == 3){
					$value = 'Premium Beat + Skin 3';
					$skin = 3;
				}

				if($key == 4){
					$value = 'Premium Beat + Skin 4';
					$skin = 4;
				}

				if($key == 5){
					$value = 'Premium Beat + Skin 5';
					$skin = 5;
				}

				if($key == 6){
					$value = 'dewplayer + vol';
				}

				if($key == 7){
					$value = 'dewplayer standard';
				}

				if($key == 8){
					$value = 'dewplayer mini';
				}

				if($key == 9){
					$value = 'simplemp3player';
				}

				if($key == 10){
					$value = 'simplemp3player mini';
				}

				if($key == 11){
					$value = 'player_mp3';
				}

				if($key == 12){
					$value = 'mediaplayer';
				}

				echo '<option value="'.$key.'" style="padding-left:3px"'.($SETTINGS->player==$key ? ' selected' : '').'>'.$value.'</option>'."\n";

				$key= $key + 1;
			}
			echo '</select> </td><td>';
			include_once(JPATH_COMPONENT_SITE.DS.'players'.DS.'mp3players.php');
			$key = 1;

			echo '<div id="flash_player"><!-- Begin Flash Player -->'.mp3players::getplayer($SETTINGS->player, "test.mp3", $SETTINGS->player, 1).'<!-- End Flash Player --></div>';
			?></td>
	</tr>
</table>
</fieldset>

<fieldset class="adminform"><legend><?php echo JText::_( _msg_settings9 ); ?></legend>
<table class="admintable">
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings6); ?></td>
		<td align="left" style="padding: 5px" width="70%"><b><?php echo JPATH_ROOT; ?></b></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings10); ?></td>
		<td align="left" style="padding: 5px" width="70%"><input
			class="formBox" type="text" name="mp3_path" maxlength="250" size="30"
			value="<?php echo JText::_($SETTINGS->mp3_path); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript4); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings11); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" onkeypress="display_url()" name="preview_path"
			maxlength="250" size="30"
			value="<?php echo JText::_($SETTINGS->preview_path); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript5); ?>
			<?php echo JText::_(_msg_append); ?> <input type="checkbox"
			onchange="toggleLayer('site_div')" name="append_url" " value="1"
			<?php echo ($SETTINGS->append_url ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript47); ?>
		<div id="site_div"><?php echo ($SETTINGS->append_url ? substr($uri->root(), 0, strlen($uri->root())-1).$SETTINGS->preview_path : ''); ?></div>
		<input type="hidden" name="site_url"
			value="<?php echo substr($uri->root(), 0, strlen($uri->root())-1);?>">
		</td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings25); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="page_expiry" maxlength="2" size="30"
			style="width: 10%"
			value="<?php echo cleanData($SETTINGS->page_expiry); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript24); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings31); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="download_expiry" maxlength="2" size="30"
			style="width: 10%"
			value="<?php echo cleanData($SETTINGS->download_expiry); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript30); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_('Zip '._msg_sales20); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="use_zip" value="1"
			<?php echo ($SETTINGS->use_zip == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="use_zip" value="0"
		<?php echo ($SETTINGS->use_zip == '0' || $SETTINGS->use_zip == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
	
		</td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_lightbox); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="hide_lightbox" value="1"
			<?php echo ($SETTINGS->hide_lightbox == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="hide_lightbox" value="0"
		<?php echo ($SETTINGS->hide_lightbox == '0' || $SETTINGS->hide_lightbox == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_lightbox_javascript); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings51); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="show_download" value="1"
			<?php echo ($SETTINGS->show_download == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="show_download" value="0"
		<?php echo ($SETTINGS->show_download == '0' || $SETTINGS->show_download == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript_show_link); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings30); ?></td>
		<td align="left" style="padding: 5px"><input type="checkbox"
			name="reset" value="1"> <?php echo toolTip(_msg_javascript,_msg_javascript29); ?></td>
	</tr>
</table>
</fieldset>

<fieldset class="adminform"><legend><?php echo JText::_( _msg_settings14 ); ?></legend>
<table class="admintable">
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings21); ?></td>
		<td align="left" style="padding: 5px" width="70%"><select
			name="paypal_currency">
			<?php
			include(JPATH_COMPONENT.DS.'functions'.DS.'currencies.inc.php');

			foreach ($currencies AS $key => $value) {
				echo '<option value="'.$key.'" style="padding-left:3px"'.($SETTINGS->paypal_currency==$key ? ' selected' : '').'>'.$value.'</option>'."\n";
			}
			?>
		</select> <?php echo toolTip(_msg_javascript,_msg_javascript11); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings20); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="paypal_email" maxlength="250" size="30"
			value="<?php echo cleanData($SETTINGS->paypal_email); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript8); ?>
		</td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings40); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="pdt" maxlength="250" size="90"
			value="<?php echo cleanData($SETTINGS->pdt); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript38); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings49); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="paypal_email2" maxlength="250" size="30"
			value="<?php echo cleanData($SETTINGS->paypal_email2); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript42); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings40); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="pdt2" maxlength="250" size="90"
			value="<?php echo cleanData($SETTINGS->pdt2); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript38); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings19); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="page_style" maxlength="250" size="30"
			value="<?php echo cleanData($SETTINGS->page_style); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript9); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings50); ?></td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="minpay" maxlength="2" size="30" style="width: 10%"
			value="<?php echo cleanData($SETTINGS->minpay); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript43); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings16); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="paypal_mode" value="1"
			<?php echo ($SETTINGS->paypal_mode == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="paypal_mode" value="0"
		<?php echo ($SETTINGS->paypal_mode == '0' || $SETTINGS->paypal_mode == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript7); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings18); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="log_errors" value="1"
			<?php echo ($SETTINGS->log_errors == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="log_errors" value="0"
		<?php echo ($SETTINGS->log_errors == '0' || $SETTINGS->log_errors == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript10); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(_msg_settings28); ?></td>
		<td align="left" style="padding: 5px"><input type="radio"
			name="ssl_enabled" value="1"
			<?php echo ($SETTINGS->ssl_enabled == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="ssl_enabled" value="0"
		<?php echo ($SETTINGS->ssl_enabled == '0' || $SETTINGS->ssl_enabled == ''? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript35); ?></td>
	</tr>
</table>
</fieldset>

<fieldset class="adminform"><legend><?php echo JText::_( _msg_settings33); ?></legend>
<table class="admintable">
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(  _msg_settings34); ?>:</td>
		<td align="left" width="70%" style="padding: 5px"><input type="radio"
			name="smtp" value="1"
			<?php echo ($SETTINGS->smtp == '1'? ' checked' : ''); ?>> <?php echo JText::_(_msg_script2); ?>
		<input type="radio" name="smtp" value="0"
		<?php echo ($SETTINGS->smtp == '0' || $SETTINGS->smtp == '' ? ' checked' : ''); ?>><?php echo JText::_(_msg_script3); ?>
		<?php echo toolTip(_msg_javascript,_msg_javascript32); ?></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(  _msg_settings35); ?>:</td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="smtp_host" size="20"
			value="<?php echo $SETTINGS->smtp_host; ?>"></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(  _msg_settings36); ?>:</td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="smtp_user" size="20"
			value="<?php echo $SETTINGS->smtp_user; ?>"></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_( _msg_settings37); ?>:</td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="smtp_pass" size="20"
			value="<?php echo $SETTINGS->smtp_pass; ?>"></td>
	</tr>
	<tr>
		<td width="100" align="right" class="key"><?php echo JText::_(  _msg_settings29); ?>:</td>
		<td align="left" style="padding: 5px"><input class="formBox"
			type="text" name="smtp_port" size="20"
			value="<?php echo $SETTINGS->smtp_port; ?>" style="width: 10%"></td>
	</tr>
</table>
</fieldset>

<input type="hidden" name="id" value="1" /> 
<input type="hidden" name="option" value="com_maianmedia" /> 
<input type="hidden" name="task" value="" /> 
<input type="hidden" name="boxchecked" value="0" /> 
<input type="hidden" name="controller" value="settings" />

</form>
