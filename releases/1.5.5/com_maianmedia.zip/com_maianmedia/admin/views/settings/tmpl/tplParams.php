<?php

$uri =& JURI::getInstance();
$db =& JFactory::getDBO();

jimport( 'joomla.html.parameter' );

$skin = JRequest::getVar( 'skin');

$db->setQuery("SELECT * FROM #__m15_settings LIMIT 1");
$SETTINGS = $db->loadObject();

$paramsdefs = JPATH_COMPONENT_SITE.DS.'templates'.DS.$skin.DS.'templateDetails.xml';

$objDOM = new DOMDocument(); 
$objDOM->load($paramsdefs); //make sure path is correct 

$node = $objDOM->getElementsByTagName("name"); 
$name = $node->item(0)->nodeValue;

$node = $objDOM->getElementsByTagName("creationDate");
$creationDate = $node->item(0)->nodeValue;
 
$node = $objDOM->getElementsByTagName("author");
$author = $node->item(0)->nodeValue;
 
$node = $objDOM->getElementsByTagName("authorUrl");
$authorUrl = $node->item(0)->nodeValue;
 
$node = $objDOM->getElementsByTagName("copyright");
$copyright = $node->item(0)->nodeValue;
 
$node = $objDOM->getElementsByTagName("license");
$license = $node->item(0)->nodeValue;
 
$node = $objDOM->getElementsByTagName("version");
$version = $node->item(0)->nodeValue;
 
$node = $objDOM->getElementsByTagName("description");
$description = $node->item(0)->nodeValue;

$description = explode("\n", $description);

$UI = new JParameter( $SETTINGS->extra_params, $paramsdefs );

jimport( 'joomla.application.component.view' );

jimport('joomla.html.pane');

$bar =& new JToolBar( 'My Toolbar' );
$bar->appendButton( 'Standard', 'save', 'Save', 'save', false );

$form_action = JRequest::getVar('form_action');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb"
	dir="ltr">
<head>
<link href="components/com_maianmedia/stylesheet.css" rel="stylesheet"
	type="text/css" />
<link rel="stylesheet" href="templates/system/css/system.css"
	type="text/css" />
<link href="templates/khepri/css/template.css" rel="stylesheet"
	type="text/css" />
<script type="text/javascript"
	src="<?php echo $uri->root() ?>administrator/components/com_maianmedia/js/request.js"></script>
<link href="templates/khepri/css/icon.css" rel="stylesheet"
	type="text/css" />
<script type="text/javascript">
function frmSubmit() {
document.adminForm.submit();
}
</script>

</head>
<body id="minwidth-body">
<?php if (isset($form_action)){?>
<dd>
	<h2 style="color:green">Settings Saved!</h2>
</dd>	
<?php }?>
<form id="adminForm" enctype="multipart/form-data"
	action="index.php?option=com_maianmedia&controller=settings&format=raw&task=updateParams"
	method="post" name="adminForm">

<div class="m"><div class="toolbar" id="My Toolbar"> 
<table class="toolbar"><tr> 
<td class="button" id="My Toolbar-save"> 
<a href="#" onclick="javascript: frmSubmit()" class="toolbar"> 
<span class="icon-32-save" title="Save Record"> 
</span> 
Save Record
</a> 
</td> 
 
</tr></table> 
</div></div>	
<span id="madmin-top">
<b><?php echo $name; ?></b></br>
<?php echo $author; ?></br>
<a href="<?php echo $authorUrl; ?>"><?php echo $authorUrl; ?></a></br>
<?php 
foreach($description as $line){
	echo $line.'<br>
	';
}
?>
</span>

<fieldset id="mm_adminform" class="adminform"><legend><?php echo JText::_( _msg_header3); ?></legend>
<?php echo $UI->render( 'params' ); ?></fieldset>
<input type="hidden" name="form_action" value="submit"/>
<input type="hidden" name="skin" value="<?php echo $skin; ?>"/>
</form>
</body>
</html>
