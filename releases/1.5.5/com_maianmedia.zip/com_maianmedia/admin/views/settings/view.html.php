<?php
/**
 * Settings View for Maian Music 1.3 Component
 *
 * @package    Maian.Music
 * @subpackage Components
 * @link http://www.aretimes.com
 * @link http://www.maianscriptworld.com
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class MaianViewSettings extends JView
{
	var $SETTINGS;
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		$settings =& $this->get('Data');

		JToolBarHelper::title(   JText::_(_msg_header3), 'cpanel.png' );
		JToolBarHelper::save();
		JToolBarHelper::apply();
		$this->assignRef('settings', $settings);

		$document = &JFactory::getDocument();
		$document->addScript( 'components/com_maianmedia/js/swfobject.js' );
		$document->addScript( 'components/com_maianmedia/js/request.js' );
		$document->addCustomTag($this->getScript());
		$SETTINGS = $this->settings;
		parent::display($tpl);
	}

	function getScript(){
		echo '<script type="text/javascript">
		  <!--
		  function toggleLayer( whichLayer ){
			var toggle_object = document.getElementById("site_div")
		    
			if (document.adminForm.append_url.checked){
		          toggle_object.style.display = \'block\'; 
		          display_url();
		    }else{
		
		          toggle_object.style.display = \'none\';
		   }
		  
		
		}
		  	
			function getPreviewPath(){
				var url = document.adminForm.site_url.value;
		    	var preview = document.adminForm.preview_path.value;
				var txt=document.getElementById("site_div")
				
				txt.innerHTML=url+preview;
			
			}
			
			function setTpl(template){
		
				document.getElementById(\'tplParams\').href = \'index.php?option=com_maianmedia&controller=settings&format=raw&task=tplParams&skin=\'+template;
			}
			
			function display_url() {
		    	getPreviewPath();
		    	window.setTimeout("getPreviewPath()", 500);
		   }
		   
		  -->
		  </script>';
	}

}