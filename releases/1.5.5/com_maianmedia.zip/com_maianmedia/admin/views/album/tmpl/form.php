<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php

/*++++++++++++++++++++++++++++++++++++++++

Script: Maian Music v1.2
Written by: David Ian Bennett
E-Mail: support@maianscriptworld.co.uk
Website: http://www.maianscriptworld.co.uk
Intergration: http://www.aretimes.com

++++++++++++++++++++++++++++++++++++++++
*/

$db =& JFactory::getDBO();
include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');
$editor =& JFactory::getEditor();

$document = &JFactory::getDocument();
$uri =& JURI::getInstance();

$db->setQuery("SELECT * FROM #__m15_settings Limit 1");
$settings = $db->loadObject();

JHTML::_('behavior.modal', 'a.modal-button');

$document->addCustomTag('
<script type="text/javascript">
function jInsertEditorText(value, tag)
{
	
	if(tag != \'comments\'){

    	value = value.substring(value.indexOf("\"")+1,value.length);
		value = value.substring(0,value.indexOf("\""));
		var x = document.getElementById(tag);
		x.value = "'.$uri->root().'/"+value;
	}else{
		tinyMCE.execInstanceCommand(tag, \'mceInsertContent\',false,value);
	}
	
}
	
</script>
');

//$document->addScript( $uri->root().'components/com_maianmedia/ajax/request.js' );
// Are we in edit mode?

?>
<form enctype="multipart/form-data" action="index.php" method="post"
	id="adminForm" name="adminForm"><input type="hidden" name="process" value="1">
<fieldset class="adminform"><legend><?php echo (isset($EDIT) ? JText::_( _msg_albums10) : JText::_( _msg_albums2)); ?></legend>
<table class="admintable" width="100%" cellspacing="1" cellpadding="0">
	<tr>
		<td align="left">
		<table cellspacing="0" cellpadding="0">
			<tr>
				<td class="key"><?php echo JText::_( _msg_albums11); ?></td>
				<td align="left" style="padding: 5px" width="70%"><input
					class="formBox" type="text" name="artist" maxlength="250" size="30"
					value="<?php echo (isset($this->album->artist) ? cleanData($this->album->artist) : ''); ?>"></td>
			</tr>
			<tr>
				<td class="key"><?php echo JText::_(_msg_label); ?></td>
				<td align="left" style="padding: 5px" width="70%"><input
					class="formBox" type="text" name="label" maxlength="250" size="30"
					value="<?php echo (isset($this->album->label) ? cleanData($this->album->label) : ''); ?>"></td>
			</tr>
			<tr>
				<td class="key"><?php echo JText::_( _msg_albums3); ?></td>
				<td align="left" style="padding: 5px"><input class="formBox"
					type="text" name="name" maxlength="250" size="30"
					value="<?php echo (isset($this->album->name) ? cleanData($this->album->name) : ''); ?>"></td>
			</tr>
			<!-- tr>
        <td class="key"><?php echo JText::_( _msg_albums16); ?></td>
        <td align="left" style="padding:5px">
        <select name="cat">
        <option value="0"><?php echo JText::_( _msg_albums18); ?></option>
        <?php
        $db->setQuery("SELECT * FROM #__categories WHERE section = 'com_maianmedia'
                                 ORDER BY ordering");		
        $q_cat = $db->loadObjectList();
        if (count($q_cat) > 0) {
        ?>
        

        <?php        foreach ($q_cat as $CAT) {
        //while ($ALB = $db->loadObject($q_albums)) {
        ?>
        <option value="<?php echo $CAT->id; ?>"<?php echo ($this->album->cat==$CAT->id ? ' selected="selected"' : ''); ?>><?php echo cleanData($CAT->title); ?></option>
        <?php
        }
        ?>

        <?php
        }
        ?>
        </select>
        </td>
      </tr-->
			<tr>
				<td class="key"><?php echo JText::_( _msg_albums5); ?></td>
				<td class="uploadBox" align="left" style="padding: 5px"><input
					id="image" class="formBox" type="text" name="image" maxlength="250"
					size="30"
					value="<?php echo (isset($this->album->image) ? cleanData($this->album->image) : 'http://'); ?>">
				<a class="modal-button" title="Image"
					href="index.php?option=com_media&amp;view=images&amp;tmpl=component&amp;e_name=image&amp;image_target=1"
					rel="{handler: 'iframe', size: {x: 570, y: 400}}"><img
					src="<? echo $uri->root(); ?>administrator/components/com_maianmedia/images/upload.png" /></a>&nbsp;<?php echo JText::_(toolTip( _msg_javascript, _msg_javascript12)); ?>
				</td>
			</tr>
			<tr>
				<td class="key"><?php echo JText::_( _msg_albums6); ?></td>
				<td class="uploadBox" align="left" style="padding: 5px"><input
					id="artwork" class="formBox" type="text" name="artwork"
					maxlength="250" size="30"
					value="<?php echo (isset($this->album->artwork) ? cleanData($this->album->artwork) : 'http://'); ?>">
				<a class="modal-button" title="Image"
					href="index.php?option=com_media&amp;view=images&amp;tmpl=component&amp;e_name=artwork&amp;image_target=1"
					rel="{handler: 'iframe', size: {x: 570, y: 400}}"><img
					src="<? echo $uri->root(); ?>administrator/components/com_maianmedia/images/upload.png" /></a>&nbsp;<?php echo JText::_(toolTip( _msg_javascript, _msg_javascript13)); ?>
				</td>
			</tr>
			<tr>
				<td class="key"><?php echo JText::_( _msg_albums12); ?></td>
				<td align="left" style="padding: 5px"><input class="formBox"
					type="text" name="keywords" maxlength="250" size="30"
					value="<?php echo (isset($this->album->keywords) ? cleanData($this->album->keywords) : ''); ?>">
					<?php echo JText::_(toolTip( _msg_javascript, _msg_javascript22)); ?></td>
			</tr>
			<tr>
				<td class="key"><?php echo JText::_( _msg_UPC); ?></td>
				<td align="left" style="padding: 5px"><input class="formBox"
					type="text" name="upc" maxlength="250" size="30"
					value="<?php echo (isset($this->album->upc) ? cleanData($this->album->upc) : ''); ?>">
				</td>
			</tr>
			<tr>
				<td class="key"><?php echo JText::_( _msg_RM); ?></td>
				<td align="left" style="padding: 5px"><input class="formBox"
					type="text" name="RM" maxlength="250" size="30"
					value="<?php echo (isset($this->album->RM) ? cleanData($this->album->RM) : ''); ?>">
				</td>
			</tr>
			<tr>
				<td class="key"><?php echo JText::_( _msg_albums19); ?></td>
				<td align="left" style="padding: 5px"><input class="formBox"
					type="text" name="discount" size="30" style="width: 20%"
					value="<?php echo (isset($this->album->discount) ? cleanData($this->album->discount) : ''); ?>">
				<input type="radio" name="discount_type" value="0"
				<?php echo (isset($this->album->discount_type) && !$this->album->discount_type ? ' checked' : (!isset($this->album->discount_type) ? ' checked' : '')); ?>>%
				<input type="radio" name="discount_type" value="1"
				<?php echo (isset($this->album->discount_type) && $this->album->discount_type ? ' checked' : (!isset($this->album->discount_type) ? ' checked' : '')); ?>><?php echo get_cur_symbol('',$settings->paypal_currency); ?>
				<?php echo JText::_(toolTip( _msg_javascript, _msg_javascript23)); ?></td>
			</tr>
			<tr>
				<td class="key"><?php echo JText::_(_msg_physical); ?></td>
				<td align="left" style="padding: 5px"><input class="formBox"
					type="text" name="dimensions_height" maxlength="250" size="30"
					value="<?php echo (isset($this->album->dimensions_height) ? cleanData($this->album->dimensions_height) : ''); ?>">
				</td>
			</tr>
			<?php
			if (isset($this->album))
			{
				?>
			<tr>
				<td class="key"><?php echo JText::_( _msg_albums15); ?></td>
				<td align="left" style="padding: 5px"><input class="formBox"
					type="text" name="hits" size="30" style="width: 10%"
					value="<?php echo (isset($this->album->hits) ? cleanData($this->album->hits) : ''); ?>">
				</td>
			</tr>
			<?php
			}
			?>
			<tr>
				<td class="key"><?php echo JText::_( _msg_albums8); ?></td>
				<td align="left" style="padding: 5px"><?php echo JText::_( _msg_script2); ?>
				<input type="radio" name="status" value="1"
				<?php echo (isset($this->album->status) && $this->album->status ? ' checked' : (!isset($this->album->status) ? ' checked' : '')); ?>>
				<?php echo JText::_( _msg_script3); ?> <input type="radio"
					name="status" value="0"
					<?php echo (isset($this->album->status) && !$this->album->status ? ' checked' : ''); ?>>
					<?php echo JText::_(toolTip( _msg_javascript, _msg_javascript14)); ?></td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</fieldset>
<fieldset class="adminform"><legend><?php echo JText::_( _msg_albums7); ?>
&nbsp;<i>(<?php echo JText::_( _msg_script4); ?>)</i></legend> <?php echo $editor->display('comments', isset($this->album->comments)? cleanData($this->album->comments):'', '550', '400', '60', '20', true);?>
</fieldset>
<input type="hidden" name="option" value="com_maianmedia" /> 
<input type="hidden" name="task" value="" /> 
<input type="hidden" name="controller" value="albums" /> 
<input type="hidden" name="id"	value="<?php echo (isset($this->album->id) ? cleanData($this->album->id) : ''); ?>" />
</form>
