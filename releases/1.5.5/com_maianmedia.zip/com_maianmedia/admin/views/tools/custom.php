<?php
$db =& JFactory::getDBO();

$db->setQuery("SELECT * FROM #__m15_pages") ;
$pages = $db->loadObjectList();

?>
<form id="adminForm" action="index.php" method="post" name="adminForm">
<fieldset id="mm_custom" class="adminform">
<legend><?php echo JText::_( _msg_settings23); ?></legend>
<?php
// instantiate new tab system
//$tabs = new mosTabs(1);
jimport('joomla.html.pane');
$editor =& JFactory::getEditor();
$tabs =& JPane::getInstance('tabs', array('startOffset'=>0));

// start tab pane
echo $tabs->startPane("TabPaneOne");

foreach ($pages as $page){
//First tab
	$tabName = $page->name;
	$tabText = $page->name;
	if($page->name == 'free'){
		$tabName = 'freeText';
		$tabText = 'Free';
	}else if($page->name == 'about'){
		$tabText = 'Most Popular';
	}else if($page->name == 'license'){
		$tabName = 'licence';
		$tabText = 'License';
	}else if($page->name == 'music'){
		$tabText = 'Music';
	}
	
	echo $tabs->startPanel(JText::_($tabText),$tabText."-page");
// parameters : areaname, content, hidden field, width, height, rows, cols
	echo $editor->display($tabName, cleanData($page->text), '550', '400', '60', '20', true);
	echo $tabs->endPanel();
}

// end tab pane
echo $tabs->endPane("TabPaneOne");
echo '<br>';
?>
 </fieldset>
 <input type="hidden" name="id" value="1" />
<input type="hidden" name="option" value="com_maianmedia" />
<input type="hidden" name="task" value="tools" />
<input type="hidden" name="tool" value="custom" />
<input type="hidden" name="controller" value="settings" />
</form>