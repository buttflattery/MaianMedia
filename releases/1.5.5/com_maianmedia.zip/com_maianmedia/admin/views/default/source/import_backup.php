<?php
defined('_JEXEC') or die('Restricted access');
require_once(JPATH_LIBRARIES.DS.'joomla'.DS.'factory.php');
include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');

include_once(JPATH_COMPONENT.DS.'tables'.DS.'album.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'paypal.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'tracks.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'settings.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'purchases.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'backup.php');
$db =& JFactory::getDBO();

$db->setQuery("SELECT * FROM #__mbak_settings");
$settings = $db->loadObject();

$db->setQuery("SELECT * FROM #__mbak_albums");
$albums = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__mbak_tracks");
$tracks = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__mbak_purchases");
$purchases = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__mbak_paypal");
$paypal = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__mbak_pages");
$pages = $db->loadObjectList();

$settingsTable =& JTable::getInstance('settings', 'Table');
$albumTable =& JTable::getInstance('album', 'Table');
$purchasesTable =& JTable::getInstance('purchases', 'Table');
$paypalTable =& JTable::getInstance('paypal', 'Table');
$tracksTable =& JTable::getInstance('tracks', 'Table');
unset($tracksTable->tracksAdded);
$pagesTable =& JTable::getInstance('bakpages', 'Table');
$pagesTable->_tbl = '#__m15_pages';


// Bind the form fields to the settings table
if (!$settingsTable->bind(parseObjectToArray($settings))) {
	echo JText::_(_msg_error_bind).' Settings<br>';
	$importError = 1;
}

// Make sure the settings record is valid
if (!$settingsTable->check()) {
	echo JText::_(_msg_error_check).' Settings<br>';
	$importError = 1;
}

// Store the web link table to the database
if (!$settingsTable->store()) {
	echo JText::_(_msg_error_store).' Settings<br>';
	echo $settingsTable->_errorMsg;
	echo $settingsTable->_db->ErrorMsg();
	$importError = 1;
}

foreach($purchases as $single){

	if (!$purchasesTable->bind($single)){
		echo JText::_(_msg_error_bind).' Purchases<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$purchasesTable->check()){
		echo JText::_(_msg_error_check).' Purchaces<br>';
		$importError = 1;
	}

	$db->setQuery("SELECT * FROM #__m15_purchases WHERE id=".$single->id);
	$test = $db->loadObject();
	if(!isset($test)){
		$purchasesTable->_tbl_key = 0;
	}
	// Store the web link table to the database
	if (!$purchasesTable->store()){
		echo JText::_(_msg_error_store).' Purchaces<br>';
		echo $purchasesTable->_db->ErrorMsg();
		$importError = 1;
	}

}


foreach($paypal as $single){

	if (!$paypalTable->bind($single)){
		echo JText::_(_msg_error_bind).' Paypal<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$paypalTable->check()){
		echo JText::_(_msg_error_check).' Paypal<br>';
		$importError = 1;
	}

	$db->setQuery("SELECT * FROM #__m15_paypal WHERE id=".$single->id);
	$test = $db->loadObject();
	if(!isset($test)){
		$paypalTable->_tbl_key = 0;
	}

	// Store the web link table to the database
	if (!$paypalTable->store()){
		echo JText::_(_msg_error_store).' Paypal<br>';
		echo $paypalTable->_db->ErrorMsg();
		$importError = 1;
	}

}

foreach($albums as $album){

	if (!$albumTable->bind($album)){
		echo JText::_(_msg_error_bind).' Album<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$albumTable->check()){
		echo JText::_(_msg_error_check).' Album<br>';
		$importError = 1;
	}

	$db->setQuery("SELECT * FROM #__m15_albums WHERE id=".$album->id);
	$test = $db->loadObject();
	if(!isset($test)){
		$albumTable->_tbl_key = 0;
	}

	// Store the web link table to the database
	if (!$albumTable->store()){
		echo JText::_(_msg_error_store).' Album<br>';
		echo $albumTable->_db->ErrorMsg();
		$importError = 1;
	}

}

foreach($tracks as $track){

	if (!$tracksTable->bind($track)){
		echo JText::_(_msg_error_bind).' Track<br>';
		$importError = 1;
	}
	//$tracksTable->setTrackAdded(null);
	// Make sure the  record is valid
	if (!$tracksTable->check()){
		echo JText::_(_msg_error_check).' Track<br>';
		$importError = 1;
	}

	$db->setQuery("SELECT * FROM #__m15_tracks WHERE id=".$track->id);
	$test = $db->loadObject();
	if(!isset($test)){
		$tracksTable->_tbl_key = 0;
	}

	// Store the web link table to the database
	if (!$tracksTable->store()){

		echo JText::_(_msg_error_store).' Track<br>';
		echo $tracksTable->_db->ErrorMsg();
		$importError = 1;
	}

}

foreach($pages as $page){

	if (!$pagesTable->bind($page)){
		echo JText::_(_msg_error_bind).' Pages<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$pagesTable->check()){
		echo JText::_(_msg_error_check).' Pages<br>';
		$importError = 1;
	}

	$db->setQuery("SELECT * FROM #__m15_pages WHERE id=".$page->id);
	$test = $db->loadObject();
	if(!isset($test)){
		$pagesTable->_tbl_key = 0;
	}
	

	// Store the web link table to the database
	if (!$pagesTable->store()){

		echo JText::_(_msg_error_store).' Pages<br>';
		echo $pagesTable->_db->ErrorMsg();
		$importError = 1;
	}

}

if (isset($importError)){
	echo '<font style="color:red; margin-left:150px;"><b>There was a problem importing your backup tables</b></font>';
	$importError = 1;
}else{
	$db->setQuery("SELECT id FROM #__components WHERE name= 'Maian Music 1.3'");
	$com_id = $db->loadObject();

	if(isset($com_id->id)){
		$db->setQuery('UPDATE #__menu SET componentid = '.$com_id->id.' WHERE link LIKE \'%option=com_maianmedia%\' and type =\'component\'');
		$db->query();
	}

	echo '<font style="color:green; margin-left:150px;"><b>Backup tables were detected and imported successfully</b></font>';
}
?>