DROP TABLE IF EXISTS  `#__m15_albums`;	
DROP TABLE IF EXISTS `#__m15_paypal`;	
DROP TABLE IF EXISTS  `#__m15_purchases`;
DROP TABLE IF EXISTS `#__m15_settings`;
DROP TABLE IF EXISTS `#__m15_tracks`;
DROP TABLE IF EXISTS `#__m15_pages`;