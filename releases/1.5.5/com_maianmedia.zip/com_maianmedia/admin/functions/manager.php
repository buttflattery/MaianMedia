<?php

include('FileManager.php');

function endecrypt ($pwd, $data, $case='') {
	if ($case == 'de') {
		$data = urldecode($data);
	}

	$key[] = "";
	$box[] = "";
	$temp_swap = "";
	$pwd_length = 0;

	$pwd_length = strlen($pwd);

	for ($i = 0; $i <= 255; $i++) {
		$key[$i] = ord(substr($pwd, ($i % $pwd_length), 1));
		$box[$i] = $i;
	}

	$x = 0;

	for ($i = 0; $i <= 255; $i++) {
		$x = ($x + $box[$i] + $key[$i]) % 256;
		$temp_swap = $box[$i];

		$box[$i] = $box[$x];
		$box[$x] = $temp_swap;
	}

	$temp = "";
	$k = "";

	$cipherby = "";
	$cipher = "";

	$a = 0;
	$j = 0;

	for ($i = 0; $i < strlen($data); $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;

		$temp = $box[$a];
		$box[$a] = $box[$j];

		$box[$j] = $temp;

		$k = $box[(($box[$a] + $box[$j]) % 256)];
		$cipherby = ord(substr($data, $i, 1)) ^ $k;

		$cipher .= chr($cipherby);
	}

	if ($case == 'de') {
		$cipher = urldecode(urlencode($cipher));

	} else {
		$cipher = urlencode($cipher);
	}

	return $cipher;
}

function UploadIsAuthenticated($get){
	//debuging code since flash creates a new session
	/*$flashcookie=print_r($_SERVER, true);
	$getter =print_r($_GET, true);
	$postdata=print_r($_POST, true);
	$requestSession =print_r($_REQUEST, true);

	$myFile = "test.log";
	$fh = fopen($myFile, 'a') or die("can't open file");
	fwrite($fh, "---------------------------upload start-----------------------\r\n");
	fwrite($fh, '$_SERVER \r\n');
	fwrite($fh, $flashcookie);
	fwrite($fh, '$_GET \r\n');
	fwrite($fh, $getter);
	fwrite($fh, '$_POST \r\n');
	fwrite($fh, $postdata);
	fwrite($fh, '$_REQUEST \r\n');
	fwrite($fh, $requestSession);

	fwrite($fh, "---------------------------upload end------------------\r\n");	
	fclose($fh);
	*/
	
	//manpulate encrypted string
	$sessionid = $_GET['sessionid'];
	$sessionid = str_replace('-per-','%',$sessionid);
	$sessionid = trim(str_replace('-dot-','.',$sessionid));

	$auth = file_get_contents('auth.php');
	
	$md5loc = strpos($auth, '$md5=');
	$md5 = trim(substr($auth,$md5loc+6, -4));

	$key = endecrypt($md5,$sessionid,'de');
	
	if(strrpos($_SERVER['QUERY_STRING'],$key)===false){
		return false;
	}else{
		if($_SERVER['HTTP_USER_AGENT'] == 'Shockwave Flash'){
			return true;
		}else{
			return false;
		}
	}

}


//this hack sucks but flash destroys the admin session so I have to improvise
/*
$flashcookie=print_r($_SERVER, true);
$getter =print_r($_GET, true);
$postdata=print_r($_POST, true);
$requestSession =print_r($_REQUEST, true);

$myFile = "test.log";
$fh = fopen($myFile, 'a') or die("can't open file");
fwrite($fh, "---------------------------main start-----------------------\r\n");
fwrite($fh, '$_SERVER\r\n');
fwrite($fh, $flashcookie);
fwrite($fh, '$_GET\r\n');
fwrite($fh, $getter);
fwrite($fh, '$_POST\r\n');
fwrite($fh, $postdata);
fwrite($fh, '$_REQUEST\r\n');
fwrite($fh, $requestSession);
fwrite($fh, "---------------------------main end-----------------------\r\n");
fclose($fh);
*/
//manpulate encrypted string
$sessionid = $_GET['sessionid'];
$sessionid = str_replace('-per-','%',$sessionid);
$sessionid = trim(str_replace('-dot-','.',$sessionid));

$auth = file_get_contents('auth.php');

$md5loc = strpos($auth, '$md5=\'');
$md5 = trim(substr($auth,$md5loc+6, -4));

$key = endecrypt($md5,$sessionid,'de');

//prevent bastards from trying to exploit this file

if(strrpos($_SERVER['HTTP_COOKIE'],$key)===false){
	if(!isset($_POST['Upload'])){
		die();
	}
}

$browser = new FileManager(array(
	'directory' => $_GET['path'],
	'absolutePath' => $_GET['path'],
	'assetBasePath' => '../images/managerAssets',
	'upload' => true,
	'destroy' => false));

$browser->fireEvent(!empty($_GET['event']) ? $_GET['event'] : null);