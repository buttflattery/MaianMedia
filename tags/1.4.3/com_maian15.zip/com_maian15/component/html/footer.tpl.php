<div id="mm_footer_bottom">
<div id="mm_footer">
	<p>Powered by Maian Music &copy; <?php echo (date("Y")=='2007' ? '2007' : '2007-'.date("Y")); ?><br> <a href="http://www.maianscriptworld.co.uk/free-php-scripts/maian-music/free-mp3-music-store-system/index.html" title="Maian Script World">Maian Script World</a> &amp; <a href="http://www.AreTimes.com">Are Times</a>
	</p>
	<p style="display: none"><a href="http://www.aretimes.com">Free MP3 Music Store</a></p>
</div>
</div>
		
<noscript><p class="no_script"><?php echo $tplDisplayFooter['NO_SCRIPT'] ?></p></noscript>
