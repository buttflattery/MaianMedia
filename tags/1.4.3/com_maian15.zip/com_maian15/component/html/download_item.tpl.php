<link href="components/com_maian15/views/mm_stylesheet.css" rel="stylesheet" type="text/css" />
<div id="fetch">
  <p class="fetch">
    <?php echo $tplDisplayData['DATA']; ?>
  </p>
    <?php echo $tplDisplayData['LINK']; ?>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>