  
  <div id="mm_main">
    <h2 class="title"><?php echo $tplDisplayData['ABOUT_TEXT']; ?> </h2>
		<?php echo $tplDisplayData['ABOUT']'; ?>
	</div>
