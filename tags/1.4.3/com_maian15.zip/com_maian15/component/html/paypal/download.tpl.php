  
  <div id="mm_main" style="height:450px">
      <h2 class="title"><?php echo $tplDisplayData['DOWNLOAD_TEXT']; ?> &raquo;</h2>
			<?php echo $tplDisplayData['DOWNLOAD_MESSAGE']; ?><br /><br />
			<div id="purchase_heading">
			 <b><?php echo $tplDisplayData['ALBUMS']; ?></b>
			</div>
			<div class="purchases">
			  <?php echo $tplDisplayData['ALBUM_DATA']; ?>
			</div>
			<div id="purchase_heading2">
			 <b><?php echo $tplDisplayData['TRACKS']; ?></b>
			</div>
			<div class="purchases">
			  <?php echo $tplDisplayData['TRACK_DATA']; ?>
			</div>
			<p class="enjoy_music"><?php echo $tplDisplayData['ENJOY_MUSIC']; ?></p>
	</div>
