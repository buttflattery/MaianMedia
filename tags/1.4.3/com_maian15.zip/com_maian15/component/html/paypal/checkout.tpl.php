  
  <div id="mm_main" style="height:450px">
    <div id="paypal_connection">
      <?php echo $tplDisplayData['CONNECTING']; ?><br /><br />
      <img src="components/com_maian15/media/cart/connecting.gif" alt="<?php echo $tplDisplayData['CONNECTING']; ?>" title="<?php echo $tplDisplayData['CONNECTING']; ?>" />
    </div>
    <?php echo $tplDisplayData['PAYPAL_FORM_FIELDS']; ?>
	</div>
<script type="text/javascript">
setTimeout("document.paypal_form.submit()", 2000);
</script>