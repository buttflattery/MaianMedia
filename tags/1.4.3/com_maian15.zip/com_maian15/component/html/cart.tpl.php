<?php JHTML::_( 'behavior.mootools' );?>  
  <div id="mm_main" style="height:450px">
      <h2 class="title"><?php  echo $tplDisplayData['CART_TEXT']; ?> </h2>
			<?php  echo $tplDisplayData['CART_MESSAGE']; ?><br /><br />
			<?php  echo $tplDisplayData['CART_DATA']; ?>
			<?php  echo $tplDisplayData['CART_BUTTONS']; ?>
			<p><br /><br /></p>
	</div>
