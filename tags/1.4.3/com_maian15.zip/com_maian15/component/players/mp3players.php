<?php


class mp3players {

	function getplayer($mp3, $path, $skin, $id) {
		$uri =& JURI::getInstance();
		$mosConfig_live_site = $uri->root();
		//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);

		if($this->SETTINGS->append_url == '1'){
			$mp3Url = substr($mosConfig_live_site, 0, strlen($mosConfig_live_site)-1).$path;
		}else{
			$mp3Url = $path;
		}
		
		if($mp3 <= 5){
			$mp3 = 0;
		}

		switch ($mp3) {

			case 0:
				//player.swf
				//$path = $thisParams[0];

				$text = '
	<script type="text/javascript" src="'.$mosConfig_live_site .'components/com_maian15/players/swfobject.js"></script>
		      <div id="playerMini'.$id.'">
           <a href="http://www.adobe.com/go/getflashplayer" onclick="window.open(this);return false"><img src="'.$mosConfig_live_site.'components/com_maian15/media/icons/get_flash_player.gif" alt="Get Adobe Flash player" title="Get Adobe Flash player" /></a>
          </div>

          <script type="text/javascript">
            var so = new SWFObject("'.$mosConfig_live_site .'components/com_maian15/players/playerMini.swf", "mymovie", "75", "30", "7", "#FFFFFF");
            so.addVariable("autoPlay", "no");
            so.addVariable("wmode", "transparent");
            so.addVariable("overColor","#40ACC7");
            so.addVariable("soundPath", "'.$mp3Url.'");
            so.addVariable("playerSkin","'.$skin.'");
            so.write("playerMini'.$id.'");
          </script>';
				$test = JRequest::getVar('controller_');
				if(JRequest::getVar('controller_') == 'settings' || JRequest::getVar('controller') == 'settings'){
					$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/playerMini.swf?soundPath='. $mp3Url .'&playerSkin='.$skin.'&wmode=opaque" width="240" height="40" style="a:active, a:focus {outline: 0};">
		<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/playerMini.swf?soundPath='. $mp3Url .'&wmode=opaque" />
		<param name="WMode" value="transparent"></param>
		<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/playerMini.swf" allowscriptaccess="always" allowfullscreen="true"></embed>
		</object>
	';
				}

				return $text;
				break;

			case 6:
				//dewplayer.swf	+ volume
				//$path = $thisParams[0];
				//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .''. $path);
				$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/dewplayer-vol.swf?son='. $mp3Url .'" width="240" height="20" style="a:active, a:focus {outline: 0};">
	<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/dewplayer-vol.swf?son='. $mp3Url .'&wmode=opaque" />
	<param name="WMode" value="transparent"></param>
	<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/dewplayer-vol.swf?son='. $mp3Url .'" allowscriptaccess="always" allowfullscreen="true"></embed>
	</object>
	';
				return $text;
				break;

			case 7:
				//dewplayer.swf	standard
				//$path = $thisParams[0];
				//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .''. $path);
				$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/dewplayer.swf?son='. $mp3Url .'" width="200" height="20" style="a:active, a:focus {outline: 0};">
	<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/dewplayer.swf?son='. $mp3Url .'" />
	<param name="WMode" value="transparent"></param>
	<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/dewplayer.swf?son='. $mp3Url .'" allowscriptaccess="always" allowfullscreen="true"></embed>
	</object>
	';
				return $text;
				break;

			case 8:
				//dewplayer.swf	mini
				//$path = $thisParams[0];
				//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .''. $path);
				$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/dewplayer-mini.swf?son='. $mp3Url .'&wmode=opaque" width="150" height="20" style="a:active, a:focus {outline: 0};">
	<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/dewplayer-mini.swf?son='. $mp3Url .'&wmode=opaque" />
	<param name="WMode" value="transparent"></param>
	<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/dewplayer-mini.swf?son='. $mp3Url .'" allowscriptaccess="always" allowfullscreen="true"></embed>
	</object>
	';
				return $text;
				break;

			case 7:
				//FLASHPLAYER.swf
				//$path = $thisParams[0];
				//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .''. $path);
				$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=#FFE&frontColor=1a1a1a&showDownload=false&songVolume=90&wmode=opaque" width="150" height="20" style="a:active, a:focus {outline: 0};">
	<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" />
	<param name="WMode" value="transparent"></param>
	<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'" allowscriptaccess="always" allowfullscreen="true"></embed>
	</object>
	';
				return $text;
				break;

			case 8:
				//FLASHPLAYER.swf mini
				//$path = $thisParams[0];
				//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .''. $path);
				$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90&wmode=opaque" width="150" height="20" style="a:active, a:focus {outline: 0};">
	<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90&wmode=opaque" />
	<param name="WMode" value="transparent"></param>
	<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'" allowscriptaccess="always" allowfullscreen="true"></embed>
	</object>
	';
				return $text;
				break;

			case 9:
				//FLASHPLAYER.swf
				//$path = $thisParams[0];
				//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .''. $path);
				//$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" width="25" height="20" style="a:active, a:focus {outline: 0};">
				//<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" />
				//</object>
				//';
				$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90&wmode=opaque" width="120" height="20" style="a:active, a:focus {outline: 0};">
	<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&trueVolume=90&wmode=opaque" />
	<param name="WMode" value="transparent"></param>
	<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'" allowscriptaccess="always" allowfullscreen="true"></embed>
	</object>
	';
				return $text;
				break;

			case 10:
				//FLASHPLAYER.swf
				//$path = $thisParams[0];
				//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .''. $path);
				$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90&wmode=opaque" width="25" height="20" style="a:active, a:focus {outline: 0};">
	<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&trueVolume=90&wmode=opaque" />
	<param name="WMode" value="transparent"></param>
	<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/singlemp3player.swf?file='. $mp3Url .'" allowscriptaccess="always" allowfullscreen="true"></embed>
	</object>
	';
				return $text;
				break;

			case 11:
				//FLASHPLAYER2.swf
				//$path = $thisParams[0];
				//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .''. $path);
				$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/player_mp3.swf?mp3='. $mp3Url .'&amp;showstop=1" width="150" height="20" style="a:active, a:focus {outline: 0};">
	<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/player_mp3.swf?mp3='. $mp3Url .'&amp;showstop=1" />
	<param name="WMode" value="transparent"></param>
	<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/player_mp3.swf?mp3='. $mp3Url .'" allowscriptaccess="always" allowfullscreen="true"></embed>
	</object>
	';
				return $text;
				break;

			case 12:
				//player.swf
				//$path = $thisParams[0];
				//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .''. $path);
				$text = '
	<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'components/com_maian15/players/player.swf?file='. $mp3Url .'&showdownload=false" width="200" height="20" style="a:active, a:focus {outline: 0};">  	
	<param name="movie" value="'. $mosConfig_live_site .'components/com_maian15/players/player.swf?file='. $mp3Url .'&showdownload=false&wmode=transparent" />
	<param name="WMode" value="transparent"></param>
	<embed wmode="transparent" type="application/x-shockwave-flash" src="'. $mosConfig_live_site .'components/com_maian15/players/player.swf?file='. $mp3Url .'" allowscriptaccess="always" allowfullscreen="true"></embed>
	</object>
	';
				return $text;
				break;

		}
	}

}
?>