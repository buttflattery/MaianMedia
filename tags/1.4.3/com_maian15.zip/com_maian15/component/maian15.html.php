<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view');

/**
* @package Joomla
* @subpackage Maian Music 1.5
*/
class HTML_maiainFront {
	
	function show_MainPage($tplDisplayHome){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
 	  	include_once(JPATH_COMPONENT.DS.'html'.DS.'home.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_MusicPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'music.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_ContactPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'contact.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_LicencePage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'licence.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_AboutPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'about.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_SearchPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'search.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_AlbumPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'album.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_CartPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'cart.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_CheckoutPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		//include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'paypal'.DS.'checkout.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_ThanksPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'paypal'.DS.'thanks.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	
	function show_CancelPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'paypal'.DS.'cancel.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_InvalidPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'paypal'.DS.'error.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_ErrorPage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'paypal'.DS.'error.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_FreePage($tplDisplayData){
		  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'free.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_DownloadPage($tplDisplayData){
		JHTML::_('behavior.modal', 'a.modal-button');  
		include_once(JPATH_COMPONENT.DS.'inc'.DS.'header.php');
		include_once(JPATH_COMPONENT.DS.'html'.DS.'header.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'paypal'.DS.'download.tpl.php');
  		include_once(JPATH_COMPONENT.DS.'inc'.DS.'footer.php');
  		include_once(JPATH_COMPONENT.DS.'html'.DS.'footer.tpl.php');
	}
	
	function show_ItemPage($tplDisplayData){
  		
		include_once(JPATH_COMPONENT.DS.'html'.DS.'download_item.tpl.php');
	}
	
	function show_RSS($rss_feed){
  		
		echo (get_magic_quotes_gpc() ? stripslashes(trim($rss_feed)) : trim($rss_feed));
		exit;
	}
	
}
?>