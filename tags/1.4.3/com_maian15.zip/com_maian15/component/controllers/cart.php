<?php
/**
 * Cart Controller
 *
 * @package    Maian Music 1.3
 * @subpackage Controllers
 * @link http://www.aretimes.com
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class MaianControllerCart extends MaianController
{

	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */

	var $MM_PAYPAL, $cartID;

	function __construct()
	{
		parent::__construct();

		include(JPATH_COMPONENT.DS.'classes'.DS.'class_paypal.inc.php');
		$this->MM_PAYPAL  = new paypalIPN((isset($_GET) ? $_GET : ''),$this->SETTINGS);
		$this->cartID = session_id();
		// Register Extra tasks
		//$this->registerTask( 'add'  , 	'edit' );
	}

	function removeTrack(){

		if (!ctype_alnum($_GET['track'])) {
			exit;
		}
		$link = '<img onclick="updateCart(\'index.php?option=com_maian15&format=raw&section=cart&task=addToCart&track='.$_GET['track'].'\', \'\', \'box_'.$_GET['track'].'\');" src="components/com_maian15/media/cart/addToCart.png" />';
		$this->MM_CART->deleteCartItem($_GET['code']);
		echo $link;
		exit;
	}

	function updateCart(){
		$task = JRequest::getVar('update');
		$uri =& JURI::getInstance();
		//if($task == 'count'){
			$items= ($this->MM_CART->cartCount()>0 ? '<b style="font-size: large;">'.$this->MM_CART->cartCount().'</b>' : $this->MM_CART->cartCount());
			//echo $items;
		//}else if($task == 'total'){
			$total = get_cur_symbol($this->MM_CART->cartTotal(), $this->SETTINGS->paypal_currency);
			//echo ($this->MM_CART->cartCount()>0 ? '<i style="font-size: large;">'.$total.'</i>':$total);
		//}
		
			echo'<span id="for_dummies"><b>'.JText::_(_msg_cart7).'</b></span>
				<img src="'.$uri->root().'components/com_maian15/media/icons/shopping_cart.png" /> 
					'.JText::_(_msg_public_header2).'&nbsp;
					<font id="cart_count">'.$items.'</font>&nbsp;(<i id="cart_total">'.$total.'</i>)';
			exit;
	}

	function addToCart(){
		$uri =& JURI::getInstance();
		if (isset($_GET['album'])) {
			if (!ctype_digit($_GET['album'])) {
				header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
				exit;
			}
			// Add album to cart...
			$this->MM_CART->addToCart(true,$_GET['album'],0,JText::_(_msg_cart9));
			echo '<div id="album_add" style="font-weight:>'._msg_albums23.'</div>';
		}

		if (isset($_GET['track'])) {
			if (!ctype_digit($_GET['track'])) {
				header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
				exit;
			}
			// Add album to cart...
			$this->MM_CART->addToCart(false,0,$_GET['track'],JText::_(_msg_cart9));

			$link = '<img onclick="updateCart(\'index.php?option=com_maian15&format=raw&section=cart&task=removeTrack&track='.$_GET['track'].'&code='.$this->getEntryCode($_GET['track']).'\', \'\', \'box_'.$_GET['track'].'\');" src="'.$uri->root().'components/com_maian15/media/cart/removeFromCart.png" />';

			echo $link;
		}
		exit;
	}

	/*For thoses browsers that don't have ajax enabled*/
	function add_legacy()
	{
		if (isset($_GET['album'])) {
			if (!ctype_digit($_GET['album'])) {
				header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
				exit;
			}
			// Add album to cart...
			$this->MM_CART->addToCart(true,$_GET['album'],0,JText::_(_msg_cart9));
		} else {
			if (!isset($_POST)) {
				header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
				exit;
			}
			// Add selected tracks to cart..
			if (isset($_POST['process'])) {
				// If no boxes were checked, do nothing..
				if (!empty($_POST['track'])) {
					// Loop through checkboxes..
					for ($i=0; $i<count($_POST['track']); $i++) {
						// Only assign tracks that were checked..
						if (isset($_POST['track'][$i])) {
							$this->MM_CART->addToCart(false,0,$_POST['track'][$i],JText::_(_msg_cart9));
						}
					}
				}
			}
		}
		// Get album data and refresh page..
		// If invalid id var, go back to homepage..
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__m15_albums
                          WHERE id = '".(int)(isset($_POST['album']) ? $_POST['album'] : $_GET['album'])."' 
                          LIMIT 1") ;
		$q_album = $db->loadObjectList();
		$ALBUM = $db->loadObject();

		if (count($q_album)==0) {
			header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
			exit;
		} else {
			header("Location: ".JRoute::_('index.php?option=com_maian15&view=album&album='.$ALBUM->id.'&Itemid='.$this->menu_link->id)."");
			//header("Location: ".JRoute::_('mp3-download/'.$ALBUM->id.'/'.addTitleToUrl(cleanData($ALBUM->artist)).'/'.addTitleToUrl(cleanData($ALBUM->name))."");

		}
	}

	function clear_cart()
	{
		$this->MM_CART->clearCart();
		global $mainframe;

		$breadcrumbs = & $mainframe->getPathWay();
		$breadcrumbs->addItem( 'Music', JRoute::_( 'index.php?option=com_maian15&view=music' ) );
		header("Location: ".JRoute::_('index.php?option=com_maian15&section=cart&view=viewcart&Itemid='.$this->menu_link->id)."");
	}

	function delete_item()
	{

		if (!ctype_alnum($_GET['item'])) {
			header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
			exit;
		}

		$this->MM_CART->deleteCartItem($_GET['item']);
		header("Location: ".JRoute::_('index.php?option=com_maian15&section=cart&view=viewcart&Itemid='.$this->menu_link->id)."");
	}

	function ajax_remove()
	{

		if (!ctype_alnum($_GET['deleteThis'])) {
			header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
			exit;
		}

		$this->MM_CART->deleteCartItem($_GET['deleteThis']);
		//echo'';
		//exit;
	}

	function updateCartCount(){
		
		$task = JRequest::getVar('switch');
		switch($task){
			case 'count':
			$cData = '<b>'.str_replace("{count}",$this->MM_CART->cartCount(),JText::_(_msg_cart4)).'</b>';
			break;
			
			case 'total':
			$cData = JText::_(_msg_cart5).': '.get_cur_symbol($this->MM_CART->cartTotal(),$this->SETTINGS->paypal_currency);
			break;
		}
		
		echo $cData;
		exit;
	}
	
	function viewcart(){

		global $mainframe;

		$breadcrumbs = & $mainframe->getPathWay();
		$breadcrumbs->addItem( 'View Cart', JRoute::_( 'index.php?option=com_maian15&section=cart&view=viewcart' ) );
		JHTML::_('behavior.mootools');
		

		$document = &JFactory::getDocument();
		$document->setTitle($this->SETTINGS->website_name.' - '.JText::_(_msg_cart));
		$document->addScript( 'components/com_maian15/ajax/cartajax.js' );

		$document->addCustomTag('<script type="text/javascript">
			function MTFade (div,prop,val) {
				new Fx.Style(div, prop, {duration: 250} ).start(val);
 			}
		
 			function removeItem(id, hash)
 			{


				var el = $(\'item_\'+id);
				//var el = document.getElementById("item_"+id);
				
				MTFade (el, \'opacity\',0);
				ajaxRequest(\'item_\'+id, \'index.php?option=com_maian15&format=raw&section=cart&task=ajax_remove&deleteThis=\'+hash, 0);
				//window.setTimeout("refreshCart(\'total\', \'cart_total\')", 500);
				window.setTimeout("refreshCart(\'count\', \'mm_cart\')", 500);
				//window.setTimeout("ajaxRequest(\'shopping_count\', \'index.php?option=com_maian15&format=raw&section=cart&task=updateCartCount&switch=count\', 0)", 1000);
 				//window.setTimeout("ajaxRequest(\'cart_items_total\', \'index.php?option=com_maian15&format=raw&section=cart&task=updateCartCount&switch=total\', 0)", 2500);
			}
 		</script>');

		$cData     = '';
		$cButtons  = '';
		// Get cart data..
		if ($this->MM_CART->cartCount()>0) {
			// Cart header..
			$cData = str_replace('{item_name}',str_replace("{count}",$this->MM_CART->cartCount(),JText::_(_msg_cart4)),file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'cart_items_header.html'));
			// Cart data..
			for ($i=0; $i<count($_SESSION['album_name']); $i++) {

				// Assign album data if track..
				if (isset($_SESSION['track_id'][$i]) && $_SESSION['track_id'][$i]>0) {
					$ADATA = getAlbumData($_SESSION['track_id'][$i]);
				}
				// Check key exists..prevents offset errors..
				// None should exist. but good practice to check..
				if (isset($_SESSION['track_id'][$i])) {
					// If track and album id are empty, this is a deleted item, so don`t show it..
					if ($_SESSION['track_id'][$i]>0 || $_SESSION['album_id'][$i]>0) {

						if($this->SETTINGS->ajax == '0'){
							$delete_link = JRoute::_('index.php?option=com_maian15&section=cart&view=delete_item&item='.$_SESSION['entry_code'][$i]);
						}else{
							$delete_link = 'javascript:removeItem('.$i.',\''.$_SESSION['entry_code'][$i].'\');';
						}

						$cData .= str_replace(array('{id}','{item_name}','{cost}','{delete_url}','{delete_this_item}','{are_you_sure}'),
						array($i,
						cleanData(($_SESSION['album_name'][$i] ? $_SESSION['album_name'][$i] : $_SESSION['track_name'][$i])).($_SESSION['track_name'][$i] ? '<br /><span class="from_album">'.JText::_(_msg_cart8).' <a href="'.JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$ADATA->id).'" title="'.cleanData($ADATA->artist).' - '.cleanData($ADATA->name).'">'.cleanData($ADATA->artist).' - '.cleanData($ADATA->name).'</a></span>' : ''),
						get_cur_symbol(($_SESSION['track_cost'][$i] ? $_SESSION['track_cost'][$i] : $_SESSION['album_cost'][$i]),$this->SETTINGS->paypal_currency),
						$delete_link,
						JText::_(_msg_javascript26),
						JText::_(_msg_javascript26)
						),
						file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'cart_item.html')
						);
					}
				}
			}
			// Cart total..
			//$cData .= str_replace("{cart_total}",JText::_(_msg_cart5).': '.get_cur_symbol($this->MM_CART->cartTotal(),$this->SETTINGS->paypal_currency),
			//file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'cart_total.html'));
			// Cart buttons..
			$cButtons = str_replace(array('{continue_url}','{continue}','{clear_url}','{are_you_sure}','{clear}','{checkout_url}','{checkout}'),
			array(
			JRoute::_('index.php?option=com_maian15&view=music'),
			JText::_(_msg_continue),
			JRoute::_('index.php?option=com_maian15&section=cart&view=clear_cart'),
			JText::_(_msg_javascript25),
			JText::_(_msg_cart6),
			JRoute::_('index.php?option=com_maian15&section=cart&view=checkout'),
			JText::_(_msg_cart7)
			),
			file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'cart_buttons.html')
			);
		} else {
			$cData = str_replace('{text}',JText::_(_msg_cart3),file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'empty_cart.html'));
		}
		$tplDisplayData = array();

		$tplDisplayData['CART_TEXT'] = JText::_(_msg_cart);
		$tplDisplayData['CART_MESSAGE'] = JText::_(_msg_cart2);
		$tplDisplayData['CART_DATA'] = $cData;
		$tplDisplayData['CART_BUTTONS'] = $cButtons;
		HTML_maiainFront::show_CartPage($tplDisplayData);
	}
	// Checkout..
	function checkout()
	{
		global $mainframe;

		// Add paypal fields...
		$this->MM_PAYPAL->add_field('rm','2');
		$this->MM_PAYPAL->add_field('cmd','_xclick');
		$breadcrumbs = & $mainframe->getPathWay();
		$breadcrumbs->addItem( 'Checkout', JRoute::_( 'index.php?option=com_maian15&view=music' ) );


		if(isset($this->SETTINGS->paypal_email2) && $this->SETTINGS->paypal_email2 != 'example2@localhost.com'){

			if($this->MM_CART->cartTotal() > $this->SETTINGS->minpay){
				$this->MM_PAYPAL->add_field('business',$this->SETTINGS->paypal_email2);
			}else{
				$this->MM_PAYPAL->add_field('business',$this->SETTINGS->paypal_email);
			}

		}else{
			$this->MM_PAYPAL->add_field('business',$this->SETTINGS->paypal_email);
		}

		$this->MM_PAYPAL->add_field('item_name',JText::_(_msg_paypal2));
		$this->MM_PAYPAL->add_field('quantity','1');
		$this->MM_PAYPAL->add_field('notify_url','http'.($this->SETTINGS->ssl_enabled ? 's' : '').'://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?option=com_maian15&section=paypal&view=notify');
		$this->MM_PAYPAL->add_field('cancel_return','http'.($this->SETTINGS->ssl_enabled ? 's' : '').'://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?option=com_maian15&section=paypal&view=cancel');
		$this->MM_PAYPAL->add_field('return','http'.($this->SETTINGS->ssl_enabled ? 's' : '').'://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?option=com_maian15&section=paypal&view=thanks');
		// Only show page style field if one is set, otherwise paypal throws an error..
		if ($this->SETTINGS->page_style) {
			$this->MM_PAYPAL->add_field('page_style',$this->SETTINGS->page_style);
		}
		
		$inv = 'INV-'.time().'-'.rand(1111,9999);
		$this->MM_PAYPAL->add_field('invoice',$inv);
		$this->MM_PAYPAL->add_field('amount',$this->MM_CART->cartTotal());
		$this->MM_PAYPAL->add_field('currency_code',$this->SETTINGS->paypal_currency);
		$this->MM_PAYPAL->add_field('custom',$this->cartID.'-mswmusic');
		// Log data in database..
		$this->MM_CART->addCartToDatabase($this->cartID, $this->MM_CART->cartTotal(),$inv);
		// Kill session data..
		$this->MM_CART->clearCart();
		// Set var for form submission..
		$cartOnLoad = true;
		$tplDisplayData = array();
		$tplDisplayData['CONNECTING'] =  JText::_(_msg_paypal);
		$tplDisplayData['PAYPAL_FORM_FIELDS'] =  $this->MM_PAYPAL->loadHiddenFields();

		HTML_maiainFront::show_CheckoutPage($tplDisplayData);
	}

	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		// loading view for this task

		//parent::display();
	}


}