<?php
/**
 * Base Controller
 *
 * @package    Maian Music 1.3
 * @subpackage Controllers
 * @link http://www.aretimes.com
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class MaianController extends JController
{
	var $MM_MAIL, $MM_CART, $SETTINGS, $RENDER_LANG;
	var $cmd, $title, $page,$error_string,$count,$limit,$limitvalue, $menu_link;
	var $params;

	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		define ('PER_PAGE', 25);
		define ('PARENT',1);

		include(JPATH_COMPONENT.DS.'inc'.DS.'functions.php');
		include(JPATH_COMPONENT.DS.'classes'.DS.'class_generic.inc.php');
		include(JPATH_COMPONENT.DS.'classes'.DS.'PaginateIt.php');
		include(JPATH_COMPONENT.DS.'classes'.DS.'class_cart.inc.php');
		include(JPATH_COMPONENT.DS.'classes'.DS.'class_rss.inc.php');

		include(JPATH_COMPONENT.DS.'classes'.DS.'class_mail.inc.php');

		require_once(JApplicationHelper::getPath('html'));

		$db =& JFactory::getDBO();
		$uri =& JURI::getInstance();

		$this->getSiteLanguage();

		$db->setQuery("SELECT * FROM #__m15_settings LIMIT 1");
		$this->SETTINGS = $db->loadObject();

		// Initialise classes..

		$this->MM_MAIL              = new mailClass();
		$this->MM_CART              = new mm_Cart();
		//$this->MM_PAYPAL = new paypalIPN((isset($_POST) ? $_POST : ''),$this->SETTINGS);
		$this->MM_PAYPAL->prefix    = '#__mm_';
		$this->MM_CART->prefix      = '#__mm_';
		$this->MM_MAIL->smtp        = $this->SETTINGS->smtp;
		$this->MM_MAIL->smtp_host   = $this->SETTINGS->smtp_host;
		$this->MM_MAIL->smtp_user   = $this->SETTINGS->smtp_user;
		$this->MM_MAIL->smtp_pass   = $this->SETTINGS->smtp_pass;
		$this->MM_MAIL->smtp_port   = $this->SETTINGS->smtp_port;
		$this->MM_MAIL->addTag('{WEBSITE_NAME}',$this->SETTINGS->website_name);
		$this->MM_MAIL->addTag('{WEBSITE_URL}',$uri->root());
		$this->MM_MAIL->addTag('{WEBSITE_EMAIL}',$this->SETTINGS->email_address);
		// Clear data in cart older than set days thats not been used..
		clearDeadData();

		$document = &JFactory::getDocument();

		if(JRequest::getVar('format') != 'raw' && JRequest::getVar('task') != 'fetch'){
			//JDocument::setTitle(str_replace("{website}",cleanData($this->SETTINGS->website_name),JText::_( _msg_public_header)));
			$document->setTitle($this->SETTINGS->website_name);
			//$document->addCustomTag( '<script type="text/javascript" src="'.$uri->root().'administrator/components/com_maian15/js/request.js"></script>' );
			$document->addCustomTag( '<script type="text/javascript" src="'.$uri->root().'components/com_maian15/ajax/js_code.js"></script>' );

			if(genericOptions::get_browser_type() == 'IE'){
				$document->addCustomTag( '<link rel="stylesheet" type="text/css" href="'.$uri->root().'components/com_maian15/views/mm_stylesheet.css"/>' );
			}else{
				$document->addCustomTag('<link href="'.$uri->root().'components/com_maian15/views/mm_stylesheet.css" rel="stylesheet" type="text/css" />');
			}

			$document->addCustomTag('<link rel="alternate" type="application/rss+xml" title="RSS" href="index.php?option=com_maian15&format=raw&view=rss" />');
		}

		$this->mm_title         = cleanData($this->SETTINGS->website_name);
		$this->page          = (isset($_GET['page']) ? strip_tags($_GET['page']) : '1');
		$this->error_string  = array();
		$this->count         = 0;
		$this->limit         = PER_PAGE;
		$this->limitvalue    = $page * $limit - ($limit);

		parent::__construct();
			
		// Register Extra tasks
		//$this->registerTask( 'save' );
	}

	private function getSiteLanguage(){
		$db =& JFactory::getDBO();

		$db->setQuery("SELECT * FROM #__m15_settings LIMIT 1");
		$this->SETTINGS = $db->loadObject();

		if($this->SETTINGS->select_lang == '1'){

			$changeLang = JRequest::getVar('getlang');

			if(!isset($_SESSION['maian_lang'])){
				$_SESSION['maian_lang']=$this->SETTINGS->language;
			}

			if (isset($changeLang)){
				$_SESSION['maian_lang']= $changeLang.'.php';
			}

			if($_SESSION['maian_lang'] == ""){
				include(JPATH_COMPONENT_SITE.DS.'lang'.DS.'english.php');
			}else{
				include(JPATH_COMPONENT_SITE.DS.'lang'.DS.$_SESSION['maian_lang']);
			}

			$this->RENDER_LANG = $this->getLangDisplay();
		}else{
			if($this->SETTINGS->language == ""){
				include(JPATH_COMPONENT_SITE.DS.'lang'.DS.'english.php');
			}else{
				include(JPATH_COMPONENT_SITE.DS.'lang'.DS.$this->SETTINGS->language);
			}
		}

	}
	function mostpop()
	{
		global $mainframe;
		include_once(JPATH_COMPONENT.DS.'players'.DS.'mp3players.php');

		$p_tracks  = '';
		$p_albums  = '';
		$db =& JFactory::getDBO();

		$id = intval(cleanData(JRequest::getVar('Itemid')));

		$db->setQuery("SELECT params FROM #__menu WHERE id = $id") ;
		$query = $db->loadObject();
		$param = $query->params;

		if(!isset($param)){
			$db->setQuery("SELECT params FROM #__menu WHERE link like '%index.php?option=com_maian15&view=mostpop%' and type like 'component'");
			$query = $db->loadObject();
			$param = $query->params;

			if(!isset($param)){
				$param = "show_track=1
				display_track=5
				show_albums=1
				display_albums=5
				show_latest_track=1
				display_latest_track=5
				show_latest_albums=1
				display_latest_albums=5
				page_title=".JText::_(_msg_public_header3)."
				show_page_title=1
				pageclass_sfx=
				menu_image=-1
				secure=0";
			}
		}else{
			$this->menu_link = '&Itemid'.$id;
		}


		$lines = explode("\n", trim($param));

		for ($i=0; $i<count($lines);$i++){
			list($key,$val) = explode("=", $lines[$i]);
			$params [trim(urldecode($key))] = trim(urldecode($val));
		}

		$app =& JFactory::getApplication();

		$breadcrumbs = & $app->getPathWay();
		$breadcrumbs->addItem( JText::_(_msg_public_header4), JRoute::_( 'index.php?option=com_maian15&view=music'));

		$poplinks = $params['display_albums'];
		// Get most popular albums..
		$db->setQuery("SELECT * FROM #__m15_albums WHERE status='1'
		ORDER BY downloads DESC LIMIT $poplinks") ;

		$q_pop_albums = $db->loadObjectList();
		if (count($q_pop_albums)>0) {
			foreach($q_pop_albums as $P_ALBUMS){
				$link = '<div class="goto_left"><div onclick="location.href=\''.JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$P_ALBUMS->id).'\';" class="goto">
							<a title="'.cleanData($P_ALBUMS->name).'" href="'.JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$P_ALBUMS->id).'"></a>
						</div></div>
				';
				$p_albums .= str_replace(array('{url}','{name}','{artist}','{MP3}'),
				array(
				JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$P_ALBUMS->id),
				(empty($P_ALBUMS->name)) ? '&nbsp;':cleanData($P_ALBUMS->name),
				(empty($P_ALBUMS->artist)) ? '&nbsp;':cleanData($P_ALBUMS->artist),
				$link
				),
				file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'li_tag.html')
				);
			}
		}

		$poplinks = $params['display_track'];
		// Get most popular tracks..
		$db->setQuery("SELECT *,#__m15_albums.id AS i_id
		FROM #__m15_tracks
		LEFT JOIN #__m15_albums
		ON #__m15_tracks.track_album = #__m15_albums.id
		ORDER BY #__m15_tracks.downloads DESC
		LIMIT $poplinks");
		$q_pop_tracks = $db->loadObjectList();

		if (count($q_pop_tracks)>0) {
			foreach($q_pop_tracks as $P_TRACKS){
				$getflash = '<a href="http://www.adobe.com/go/getflashplayer" onclick="window.open(this);return false"><img src="media/icons/get_flash_player.gif" alt="Get Adobe Flash player" title="Get Adobe Flash player" /></a>';
				$mp3 = '<!-- Begin Flash Player -->'.mp3players::getplayer($this->SETTINGS->player, ($P_TRACKS->preview_path ? $this->SETTINGS->preview_path.'/'.$P_TRACKS->preview_path : $this->SETTINGS->mp3_path.'/'.$P_TRACKS->mp3_path), $this->SETTINGS ->player, ++$count).'<!-- End Flash Player -->';
				$p_tracks .= str_replace(array('{url}','{name}','{artist}','{MP3}'),
				array(
				JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$P_TRACKS->i_id),
				(empty($P_TRACKS->track_name)) ? '&nbsp;':cleanData($P_TRACKS->track_name),
				(empty($P_TRACKS->artist)) ? '&nbsp;':cleanData($P_TRACKS->artist),
				$mp3
				),
				file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'li_tag.html')
				);
			}
		}

		$poplinks = $params['display_latest_albums'];
		// Get most latest albums..
		$db->setQuery("SELECT * FROM #__m15_albums
                  WHERE status = '1'
                  ORDER BY id DESC
                  LIMIT $poplinks");
		$q_latest_albums = $db->loadObjectList();
		if (count($q_latest_albums)>0) {
			foreach($q_latest_albums as $P_ALBUMS){
				$link = '<div class="goto_left"><div onclick="location.href=\''.JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$P_ALBUMS->id).'\';" class="goto">
							<a title="'.cleanData($P_ALBUMS->name).'" href="'.JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$P_ALBUMS->id).'"></a>
						</div></div>
				';
				$l_albums .= str_replace(array('{url}','{name}','{artist}','{MP3}'),
				array(
				JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$P_ALBUMS->id),
				(empty($P_ALBUMS->name)) ? '&nbsp;':cleanData($P_ALBUMS->name),
				(empty($P_ALBUMS->artist)) ? '&nbsp;':cleanData($P_ALBUMS->artist),
				$link
				),
				file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'li_tag.html')
				);
			}
		}

		$poplinks = $params['display_latest_track'];
		// Get latest tracks..
		$db->setQuery("SELECT *,#__m15_albums.id AS i_id
		FROM #__m15_tracks
		LEFT JOIN #__m15_albums
		ON #__m15_tracks.track_album = #__m15_albums.id
		ORDER BY #__m15_tracks.id DESC
		LIMIT $poplinks");
		$q_latest_tracks = $db->loadObjectList();
		if (count($q_latest_tracks)>0) {
			foreach($q_latest_tracks as $P_TRACKS){
				$getflash = '<a href="http://www.adobe.com/go/getflashplayer" onclick="window.open(this);return false"><img src="media/icons/get_flash_player.gif" alt="Get Adobe Flash player" title="Get Adobe Flash player" /></a>';
				$mp3 = '<!-- Begin Flash Player -->'.mp3players::getplayer($this->SETTINGS->player, ($P_TRACKS->preview_path ? $this->SETTINGS->preview_path.'/'.$P_TRACKS->preview_path : $this->SETTINGS->mp3_path.'/'.$P_TRACKS->mp3_path), $this->SETTINGS ->player, ++$count).'<!-- End Flash Player -->';
				$l_tracks .= str_replace(array('{url}','{name}','{artist}','{MP3}'),
				array(
				JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$P_TRACKS->i_id),
				(empty($P_TRACKS->track_name)) ? '&nbsp;':cleanData($P_TRACKS->track_name),
				(empty($P_TRACKS->artist)) ? '&nbsp;':cleanData($P_TRACKS->artist),
				$mp3
				),
				file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'li_tag.html')
				);
			}
		}

		$tplDisplayHome = array();
		$tplDisplayHome['HOME_TEXT'] = cleanData($this->SETTINGS->website_name);
		$tplDisplayHome['HOME_MESSAGE'] = str_replace('\"','"',$this->SETTINGS->about);
		$tplDisplayHome['PAYPAL_MESSAGE'] = _msg_publichome2;
		$tplDisplayHome['MOST_POPULAR_TRACKS'] = $this->SETTINGS->poplinks.' '._msg_publichome3;
		$tplDisplayHome['MOST_POPULAR_ALBUMS'] = $this->SETTINGS->poplinks.' '._msg_publichome4;
		$tplDisplayHome['MOST_POPULAR_TRACKS_LIST'] = $p_tracks;
		$tplDisplayHome['MOST_POPULAR_ALBUMS_LIST'] = $p_albums;
		$tplDisplayHome['LATEST_TRACKS'] = $this->SETTINGS->poplinks.' '._msg_publichome6;
		$tplDisplayHome['LATEST_ALBUMS'] = $this->SETTINGS->poplinks.' '._msg_publichome5;
		$tplDisplayHome['LATEST_TRACKS_LIST'] = $l_tracks;
		$tplDisplayHome['LATEST_ALBUMS_LIST'] = $l_albums;
		$tplDisplayHome['PARAMS'] = $params;

		HTML_maiainFront::show_MainPage($tplDisplayHome);
	}

	function freebie()
	{
		global $mainframe, $option;
		$db =& JFactory::getDBO();
		$uri =& JURI::getInstance();
		$id = intval(cleanData(JRequest::getVar('Itemid')));
		$limitstart = intval(cleanData(JRequest::getVar('limitstart')));

		$db->setQuery("SELECT params FROM #__menu WHERE id = $id") ;
		$query = $db->loadObject();
		$param = $query->params;

		if(!isset($param)){
			$db->setQuery("SELECT params FROM #__menu WHERE link like '%index.php?option=com_maian15&view=freebie%' and type like 'component'");
			$query = $db->loadObject();
			$param = $query->params;

			if(!isset($param)){
				$param = "display_num=5
				orderBy=track-desc
				email=0
				accept_users=1
				alt_row=1
				color=#F5F5F5
				system=ccnews
				newslist=1
				page_title=
				show_page_title=1
				pageclass_sfx=
				menu_image=-1
				secure=0
				f_display=1
				p_display=1
				m_display=1
				c_display=1
				l_display=1
				";
			}
		}else{
			$this->menu_link = '&Itemid'.$id;
		}

		$lines = explode("\n", trim($param));

		$document = &JFactory::getDocument();
		$document->addScript('components/com_maian15/ajax/cartajax.js');

		for ($i=0; $i<count($lines);$i++){
			list($key,$val) = explode("=", $lines[$i]);
			$params [trim(urldecode($key))] = trim(urldecode($val));
		}
		
		$this->params = $params;
		
		$orderBy = $this->getOrder($params['orderBy']);

		$limit = $mainframe->getUserStateFromRequest( "limit", 'limit', intval($params['display_num']));

		if($limitstart > 0){
			$limitstart = $mainframe->getUserStateFromRequest( "$option.limitstart", 'limitstart', 0 );
		}

		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

		$aData = '';

		// Get album data...
		$db->setQuery("SELECT * FROM #__m15_tracks
		WHERE track_cost = '0.00' or freebie = '1'") ;
		$q_tracks= $db->loadObjectList();

		$count = count($q_tracks);

		// Get album data...
		$db->setQuery("SELECT * FROM #__m15_tracks
		WHERE track_cost = '0.00' or freebie = '1' $orderBy Limit $limitstart, $limit") ;
		$q_tracks= $db->loadObjectList();

		jimport('joomla.html.pagination');
		$pageNav = new JPagination($count, $limitstart, $limit );

		//$id = intval(cleanData(JRequest::getVar('track')));
		$find       = array('{item_id}','{required_field}','{invalid_address}','{name}','{email}', '{submit}');
		$replace    = array($id, JText::_(_msg_require_field), JText::_(_msg_invalid_email), JText::_(_msg_name), JText::_(_msg_email), JText::_(_msg_submit));
		$sData .= str_replace($find,$replace,
		file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'free_download.html'));

		foreach($q_tracks as $TRACKS) {
			$intNumber = $intNumber + 1;
			$altRow = '';

			$db->setQuery('SELECT * FROM #__m15_albums
			WHERE id = \''.$TRACKS->track_album.'\' Limit 1') ;
			$ALBUM= $db->loadObject();

			if($params['alt_row'] == '1'){
				if ($intNumber % 2 == 0 )
				{
					if($params['color'] != 'none'){
						$altRow = 'style="background-color:'.$params['color'].'"';
					}
				}
			}

			$link = '<img src="components/com_maian15/media/cart/no_single.png" alt="'.JText::_(_msg_no_download).'" title="'.JText::_(_msg_no_download).'" />';
			// Is single track purchasable?

			$link = $this->getLink($TRACKS->id);

			$find     = array('{id}','{link}');
			$replace = array($TRACKS->id, $link);
			$single = str_replace($find ,$replace,
			file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'add_to_cart.html'));

			$tracklength;
			if($TRACKS->track_length != ""){
				$tracklength = "(".$TRACKS->track_length.")";
			}

			include_once(JPATH_COMPONENT.DS.'players'.DS.'mp3players.php');

			$album_link = '<a href="'.JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$TRACKS->track_album).'">'.$ALBUM->name.'</a>';

			$find     = array('{flash_player}','{title}','{alt_row}','({duration})','{cost}','{add_to_cart}');
			$replace  = array('<!-- Begin Flash Player -->'.mp3players::getplayer($this->SETTINGS->player, ($TRACKS->preview_path ? $this->SETTINGS->preview_path.'/'.$TRACKS->preview_path : $this->SETTINGS->mp3_path.'/'.$TRACKS->mp3_path), $this->SETTINGS ->player, ++$count).'<!-- End Flash Player -->',
			cleanData($TRACKS->track_name), $altRow,
			$TRACKS->track_length,$album_link,
			$single);
			$aData .= str_replace($find,$replace,
			file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'tracks.html'));

		}

		$db->setQuery("SELECT * FROM #__m15_pages WHERE name LIKE 'free'");
		$pages = $db->loadObject();

		$tplDisplayData = array();

		$tplDisplayData['TRACK_TEXT'] = JText::_(_msg_free_download);
		$tplDisplayData['TRACK_MESSAGE'] = $pages->text;
		$tplDisplayData['TRACK_NAME'] = JText::_( _msg_publicalbum5);
		$tplDisplayData['TRACK_OPTIONS'] = JText::_( _msg_publicalbum3);
		$tplDisplayData['TRACK_ALBUM'] = JText::_( _msg_albums2);

		if($params['email'] == '1'){
			if(!$_SESSION['mm_email']){
				$tplDisplayData['GET_EMAIL'] = $sData;
			}
		}
		$tplDisplayData['TRACK_DATA'] =  $aData;
		$tplDisplayData['PREVIEW'] = JText::_( _msg_publicalbum10);
		$tplDisplayData['URL'] = JRoute::_('index.php?option=com_maian15&view=freebie');
		$tplDisplayData['PAGE_NUMBERS']= $pageNav->getPagesLinks();
		//$tplDisplayData['PAGE_NUMBERS']= (count($q_music)>0 ? page_numbers(getTableRowCount('albums','WHERE status = \'1\' AND parent   = \'1\''),$limit,$page) : '');
		HTML_maiainFront::show_FreePage($tplDisplayData);

	}

	// Music..
	function music()
	{
		global $mainframe, $option;
		$db =& JFactory::getDBO();
		$uri =& JURI::getInstance();
		$id = intval(cleanData(JRequest::getVar('Itemid')));
		$limitstart = intval(cleanData(JRequest::getVar('limitstart')));

		$db->setQuery("SELECT params FROM #__menu WHERE id = $id") ;
		$query = $db->loadObject();
		$param = $query->params;

		if(!isset($param)){
			$db->setQuery("SELECT params FROM #__menu WHERE link like '%index.php?option=com_maian15&view=music%' and type like 'component'");
			$query = $db->loadObject();
			$param = $query->params;

			if(!isset($param)){
				$param = "display_num=5
						orderBy=name-asc
						column=0
						show_page_title=1
						pageclass_sfx=
						menu_image=-1
						secure=0
						f_display=1
						p_display=1
						m_display=1
						c_display=1
						l_display=1";
			}
		}else{
			$this->menu_link = '&Itemid'.$id;
		}

		$lines = explode("\n", trim($param));

		for ($i=0; $i<count($lines);$i++){
			list($key,$val) = explode("=", $lines[$i]);
			$params [trim(urldecode($key))] = trim(urldecode($val));
		}
		$this->params = $params;
		$limit = $mainframe->getUserStateFromRequest( "limit", 'limit', intval($params['display_num']));

		if($limitstart > 0){
			$limitstart = $mainframe->getUserStateFromRequest( "$option.limitstart", 'limitstart', 0 );
		}

		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

		$mData = '';

		$orderBy = $this->getOrder($params['orderBy']);

		if($limit != '0'){

			$query = ' SELECT * '
			. ' FROM #__m15_albums
            	WHERE status = \'1\'
				'.$orderBy.'
            	LIMIT '.$limitstart.','.$limit;
		}else{
			$query = ' SELECT * '
			. ' FROM #__m15_albums
				WHERE status = \'1\'
				'.$orderBy;
		}

		// Get music/album data..
		$db->setQuery("SELECT * FROM #__m15_albums
		WHERE status = '1'") ;
		$q_music = $db->loadObjectList();
		$count = count($q_music);

		$db->setQuery($query) ;
		$q_music = $db->loadObjectList();

		foreach($q_music as $MUSIC){
			$image_link = $uri->root().'components/com_maian15/media/icons/no_picture.png';
			$more_info_image = $uri->root().'components/com_maian15/media/icons/more_info.png';

			if($params['more_info'] == '0'){
				$style = 'display: none;';
			}else{
				$style = '';
			}

			$images_dimensions = '';

			if($MUSIC->image != "" && $MUSIC->image !="http://"){
				$image_link = $MUSIC->image;
				$images_dimensions = 'height=75px width=75px';
			}

			$find     = array('{url}','{more_info_image}','{label}','{dimensions}','{album_image}','{more_info}','{artist}','{album_title}','{tracks}','{style}');
			$replace  = array(JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$MUSIC->id),$more_info_image,$MUSIC->label,$images_dimensions,
			$image_link,JText::_( _msg_music2),cleanData($MUSIC->artist),cleanData($MUSIC->name),str_replace("{count}",getTrackCount($MUSIC->id),JText::_( _msg_music3)), $style);
			$mData .= str_replace($find,$replace,
			file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'album_data.html')
			);
		}
		$title = $title.' - '.JText::_( _msg_public_header4);

		$db->setQuery("SELECT * FROM #__m15_pages WHERE name LIKE 'music'") ;
		$pages = $db->loadObject();

		$tplDisplayData = array();
		$tplDisplayData['MUSIC_TITLE']=JText::_(_msg_public_header4);
		$tplDisplayData['MUSIC_TEXT']=$pages->text;
		$tplDisplayData['MUSIC_MESSAGE']=JText::_( _msg_music);
		$tplDisplayData['MUSIC_DATA']= $mData;
		jimport('joomla.html.pagination');
		$pageNav = new JPagination($count, $limitstart, $limit );
		$tplDisplayData['PAGE_NUMBERS']= $pageNav->getPagesLinks();
		//$tplDisplayData['PAGE_NUMBERS']= (count($q_music)>0 ? page_numbers(getTableRowCount('albums','WHERE status = \'1\' AND parent   = \'1\''),$limit,$page) : '');

		HTML_maiainFront::show_MusicPage($tplDisplayData);
	}

	function create_captcha()
	{
		include(JPATH_COMPONENT.DS.'securimage'.DS.'securimage.php');
		//include(JPATH_COMPONENT.DS.'securimage'.DS.'securimage_show.php');
		//$Test = JPATH_COMPONENT.DS.'securimage'.DS.'securimage.php';
		$img = new securimage();

		$img->show(); // alternate use:  $img->show('/path/to/background.jpg');

	}

	function album()
	{

		global $mainframe;

		$db =& JFactory::getDBO();

		$db =& JFactory::getDBO();
		$uri =& JURI::getInstance();
		$id = intval(cleanData(JRequest::getVar('Itemid')));
		$limitstart = intval(cleanData(JRequest::getVar('limitstart')));

		$db->setQuery("SELECT params FROM #__menu WHERE id = $id") ;
		$query = $db->loadObject();
		$param = $query->params;

		if(!isset($param)){
			$db->setQuery("SELECT params FROM #__menu WHERE link like '%index.php?option=com_maian15&view=music%' and type like 'component'");
			$query = $db->loadObject();
			$param = $query->params;

			if(!isset($param)){
				$param = "display_num=5
						orderBy=name-asc
						column=0
						alt_row=0
						show_page_title=1
						pageclass_sfx=
						menu_image=-1
						secure=0
						f_display=1
						p_display=1
						m_display=1
						c_display=1
						l_display=1";
			}
		}else{
			$this->menu_link = '&Itemid'.$id;
		}

		$lines = explode("\n", trim($param));

		for ($i=0; $i<count($lines);$i++){
			list($key,$val) = explode("=", $lines[$i]);
			$params [trim(urldecode($key))] = trim(urldecode($val));
		}
		
		$this->params = $params;
		
		$document = &JFactory::getDocument();
		$document->addScript( 'components/com_maian15/ajax/enlargeit.js' );
		$document->addScript( 'components/com_maian15/players/swfobject.js' );
		$document->addScript( 'components/com_maian15/ajax/cartajax.js' );
		$document->addCustomTag('<script type="text/javascript">
			//window.onload(\'checkAjax()\');
			
			var browserName=navigator.appName; // Get the Browser Name

			if(browserName=="Microsoft Internet Explorer") // For IE
			{
				window.onload=checkAjax; // Call init function in IE
			}else{
				if (document.addEventListener) // For Firefox
				{
					document.addEventListener("DOMContentLoaded", checkAjax, false); // Call init function in Firefox
				}
			}//end else 
			
			
			
			function checkAjax(){
				if(!isAjaxSupported()){
					activateLegacy();
				}
			}
			
			function activateLegacy(){
				var elem = document.getElementsByTagName(\'span\');        

					for(i = 0; i < elem.length; i++) {          
 						if (elem[i].getAttribute(\'class\') == \'checkbox\') {
							
 							id=elem[i].innerHTML;
 							pos=id.search("value=")
 							id=id.substring(pos+7, id.length);
							pos=id.search(\'"\')
 							id=id.substring(0, pos);							
 							//elem[i].innerHTML = \'<input type="checkbox" name="track[]" value="\'+id+\'" />\';
						}
						
						if (elem[i].getAttribute(\'class\') == \'button_align\') {
							elem[i].style.display="block"
						}
						
					}//end for
			}
		</script>');


		$uri =& JURI::getInstance();

		if($this->SETTINGS->ajax == '0'){
			$document->addCustomTag('<script type="text/javascript">window.onload=activateLegacy;</script>');
		}

		$Itemid = intval(cleanData(JRequest::getVar('Itemid')));
		$id = intval(cleanData(JRequest::getVar('album')));

		$aData = '';
		// Assign id based on url...
		$id = (isset($_GET['album']) ? strip_tags($_GET['album']) : '');

		// Security check..
		if (!ctype_digit($id)) {
			header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
			exit;
		}
		// Get album data...
		$db->setQuery("SELECT * FROM #__m15_albums
		WHERE id = '{$id}'
		LIMIT 1") ;
		$ALBUM = $db->loadObject();
		$q_album = $db->loadObjectList();

		// Row check..
		if (count($q_album)==0) {
			header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
			exit;
		}

		$app =& JFactory::getApplication();
		$breadcrumbs = & $app->getPathWay();
		$breadcrumbs->addItem($ALBUM->name, 'index.php?option=com_maian15&view=album');

		// Get tracks..
		$db->setQuery("SELECT * FROM #__m15_tracks
		WHERE track_album = '{$ALBUM->id}'
		ORDER BY track_order") ;
		$q_tracks = $db->loadObjectList();

		foreach($q_tracks as $TRACKS) {
			$intNumber = $intNumber + 1;
			$altRow = '';
			if ($intNumber % 2 == 0 )
			{
				$altRow = 'class = "alt_row"';
			}

			if($this->SETTINGS->ajax == '0'){
				$link ='<input type="checkbox" name="track[]" value="'.$id.'" alt="'.JText::_(_msg_no_download).'" title="'.JText::_(_msg_no_download).'" DISABLED/>';
			}else{
				$link = '<img src="components/com_maian15/media/cart/no_single.png" alt="'.JText::_(_msg_no_download).'" title="'.JText::_(_msg_no_download).'" />';
			}
			// Is single track purchasable?
			if ($TRACKS->track_single || $TRACKS->freebie) {
				$link = $this->getLink($TRACKS->id);
			}

			$find     = array('{id}','{link}');
			$replace = array($TRACKS->id, $link);
			$single = str_replace($find ,$replace,
			file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'add_to_cart.html'));

			$tracklength;
			if($TRACKS->track_length != ""){
				$tracklength = "(".$TRACKS->track_length.")";
			}

			include_once(JPATH_COMPONENT.DS.'players'.DS.'mp3players.php');
			//include_once(JPATH_COMPONENT.'/components/com_maian15/players/mp3players.php');

			$find     = array('{flash_player}','{title}','{alt_row}','({duration})','{cost}','{add_to_cart}');
			$replace  = array('<!-- Begin Flash Player -->'.mp3players::getplayer($this->SETTINGS->player, ($TRACKS->preview_path ? $this->SETTINGS->preview_path.'/'.$TRACKS->preview_path : $this->SETTINGS->mp3_path.'/'.$TRACKS->mp3_path), $this->SETTINGS ->player, ++$count).'<!-- End Flash Player -->',
			cleanData($TRACKS->track_name), $altRow,
			$TRACKS->track_length,get_cur_symbol($TRACKS->track_cost, $this->SETTINGS ->paypal_currency),
			$single);
			$aData .= str_replace($find,$replace,
			file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'tracks.html'));

		}
		// Update hits..
		$db->setQuery("UPDATE #__m15_albums SET
		hits      = (hits+1)
		WHERE id  = '{$ALBUM->id}'
		LIMIT 1") ;
		$db->query();
		$title = $title.' - '.cleanData($ALBUM->artist).' - '.cleanData($ALBUM->name);
		// Children..
		// New in v1.2..
		$children = '';
		$links    = '';
		$db->setQuery("SELECT * FROM #__m15_albums
                             ".($ALBUM->parent > 0 ? '
                             WHERE parent = \'0\'
                             AND child    = \''.$ALBUM->id.'\'
                             ' : '
                             WHERE parent = \''.$ALBUM->child.'\'
                             OR child     = \''.$ALBUM->child.'\'
                             AND id       != \''.$ALBUM->id.'\'
                             ')." ORDER BY artist,name
                             ") ;  $q_children = $db->loadObjectList();

		if (count($q_children)>0) {
			foreach($q_children as $CHILDREN){
				$links .= '<span class="child"><a href="'.JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$CHILDREN->id).'" title="'.cleanData($CHILDREN->artist).' - '.cleanData($CHILDREN->name).'">'.cleanData($CHILDREN->artist).' - '.cleanData($CHILDREN->name).'</a></span>';
			}
			$find     = array('{related_albums}','{children}');
			$replace  = array(JText::_( _msg_publicalbum14),$links);
			$children = str_replace($find,$replace,

			file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'children.html'));

		}
		$document->setTitle($this->SETTINGS->website_name.' '._msg_albums2.' - '.$ALBUM->name);
		// Set keywords..
		$document =& JFactory::getDocument();
		$document->setMetaData( cleanData($ALBUM->name), cleanData($ALBUM->keywords), true );

		$meta_keys = cleanData($ALBUM->keywords);
		$tplDisplayData = array();

		$tplDisplayData['ALBUM_TEXT'] = JText::_( _msg_publicalbum);
		$tplDisplayData['ALBUM_MESSAGE'] = ($ALBUM->comments ? cleanData($ALBUM->comments) : JText::_( _msg_publicalbum2));
		$tplDisplayData['ARTIST'] = cleanData($ALBUM->artist);
		$tplDisplayData['TRACK_NAME'] = JText::_( _msg_publicalbum5);
		$tplDisplayData['TRACK_COST'] = JText::_( _msg_publicalbum6);
		$tplDisplayData['TRACK_OPTIONS'] = JText::_( _msg_publicalbum3);
		$tplDisplayData['CHILDREN'] =  $children;
		$tplDisplayData['NAME'] = cleanData($ALBUM->name);
		$tplDisplayData['ADD_ALL'] = JText::_( _msg_publicalbum8);
		$tplDisplayData['ALBUM_DATA'] =  $aData;
		$tplDisplayData['ALBUM_ADDED'] = $this->isAdded($ALBUM->id);
		$tplDisplayData['PREV_URL'] =  JRoute::_('index.php?option=com_maian15&view=preview_tracks&amp;album='.$ALBUM->id);
		$tplDisplayData['CANCEL'] = JText::_( _msg_script9);
		$tplDisplayData['PREVIEW'] = JText::_( _msg_publicalbum10);
		$tplDisplayData['ALBUM_ID'] =  $ALBUM->id;

		if($ALBUM->discount_type == '1'){
			$tplDisplayData['DISCOUNT'] =  ' <b>'.JText::_(_msg_publicalbum6).'</b> '.get_cur_symbol($ALBUM->discount,$this->SETTINGS->paypal_currency);
		}else{
			$tplDisplayData['DISCOUNT'] =  ($ALBUM->discount>0 ? ' - '.str_replace("{amount}",$ALBUM->discount,JText::_( _msg_publicalbum13)) : '');
		}

		$tplDisplayData['FORM_ACTION'] = JRoute::_('index.php?option=com_maian15&section=cart&task=add_legacy');
		$tplDisplayData['ADD_TO_CART'] = JText::_( _msg_publicalbum9);
		$tplDisplayData['URL'] = JRoute::_('index.php?option=com_maian15&view=music');
		$tplDisplayData['HITS'] = str_replace("{count}",number_format($ALBUM->hits),JText::_( _msg_publicalbum12));

		if($this->SETTINGS->enlargeit == '1'){
			$tplDisplayData['IMG_INLINE_STYLE'] =  (strlen($ALBUM->image)>7 ? '<img id="enlargeit" src="'.$ALBUM->image.'" alt="'.JText::_(_msg_enlarge).'" title="'.JText::_(_msg_enlarge).'" onclick="enlarge(this);" longdesc="'.$ALBUM->image.'" /><span class="hover">'.JText::_(_msg_enlarge).'</span>' : '');
		}else{
			$tplDisplayData['IMG_INLINE_STYLE'] =  (strlen($ALBUM->image)>7 ? '<img src="'.$ALBUM->image.'" alt="'.JText::_($ALBUM->name).'" title="'.JText::_($ALBUM->name).'" longdesc="'.$ALBUM->image.'" />' : '');
		}

		if($this->SETTINGS->ajax == '0'){
			$tplDisplayData['ADD_URL'] =  JRoute::_( $uri->root().'index.php?option=com_maian15&task=add_legacy&section=cart&amp;album='.$ALBUM->id);
		}else{
			$tplDisplayData['ADD_URL'] ='javascript:updateCart(\'index.php?option=com_maian15&format=raw&section=cart&task=addToCart&album='.$ALBUM->id.'\', \'\', \'loading\');';
		}

		$tplDisplayData['ALBUM_COST'] = $this->MM_CART->getFullAlbumCost($ALBUM->id, 0);
		HTML_maiainFront::show_AlbumPage($tplDisplayData);
			
		//echo'test';
	}



	function contact()
	{
		if (isset($_POST['process'])) {
			// Apply call back element to trim post vars..
			$_POST = array_map('trim',$_POST);
			if (isset($_POST['send'])) {
				if ($_POST['name']=='') {
					$N_ERROR = true;
					$count++;
				}
				if (!eregi("^([a-z]|[0-9]|\.|-|_)+@([a-z]|[0-9]|\.|-|_)+\.([a-z]|[0-9]){2,4}$", $_POST['email'])) {
					$E_ERROR = true;
					$count++;
				}
				if ($_POST['subject']=='') {
					$S_ERROR = true;
					$count++;
				}
				if ($_POST['comments']=='') {
					$C_ERROR = true;
					$count++;
				}
				if ($this->SETTINGS ->enable_captcha && isset($_POST['code'])) {
					include(JPATH_COMPONENT.DS.'securimage'.DS.'securimage.php');
					$img    = new Securimage();
					$valid  = $img->check($_POST['code']);
					if($valid == false) {
						$SUM_ERROR = true;
						$count++;
					}
				}
					
				if ($count==0) {
					$this->MM_MAIL->addTag('{NAME}',cleanEvilTags($_POST['name'],true));
					$this->MM_MAIL->addTag('{EMAIL}',$_POST['email']);
					$this->MM_MAIL->addTag('{COMMENTS}',cleanEvilTags($_POST['comments'],true));
					$this->MM_MAIL->addTag('{IP}',$_SERVER['REMOTE_ADDR']);
					// Send to webmaster..
					$this->MM_MAIL->sendMail($this->SETTINGS ->website_name,
					$this->SETTINGS->email_address,
					$this->SETTINGS->website_name,
					$this->SETTINGS->email_address,
                           '['.$this->SETTINGS->website_name.'] '.cleanEvilTags($_POST['subject'],true),
					$this->MM_MAIL->template(JPATH_COMPONENT.DS.'html'.DS.'email'.DS.'contact_message.txt'));
					// Send auto responder..
					$this->MM_MAIL->sendMail($_POST['name'],
					$_POST['email'],
					$this->SETTINGS->website_name,
					$this->SETTINGS->email_address,
                           '['.$this->SETTINGS->website_name.'] re:'.cleanEvilTags($_POST['subject'],true),
					$this->MM_MAIL->template(JPATH_COMPONENT.DS.'html'.DS.'email'.DS.'contact_auto.txt'));
					$SENT = true;
				}
			}
		}
		$title = $title.' - '.JText::_( _msg_contact2);
		$tplDisplayData = array();
		$tplDisplayData['CONTACT_MESSAGE'] = (isset($SENT) ? JText::_( _msg_contact8) : JText::_( _msg_contact));
		$tplDisplayData['FORM_TEXT'] = (isset($SENT) ? JText::_( _msg_contact13) : JText::_( _msg_contact2));
		$tplDisplayData['FORM_DISPLAY'] = (isset($SENT) ? ' style="display:none"' : '');
		$tplDisplayData['NAME_TEXT'] = JText::_( _msg_contact9);
		$tplDisplayData['EMAIL_TEXT'] = JText::_( _msg_contact10);
		$tplDisplayData['SUBJECT_TEXT'] = JText::_( _msg_contact3);
		$tplDisplayData['C_URL'] = JRoute::_('index.php?option=com_maian15&view=contact');
		$tplDisplayData['COMMENT_TEXT'] = JText::_( _msg_contact4);
		$tplDisplayData['NAME_VALUE'] = (isset($_POST['name']) ? cleanData($_POST['name']) : '');
		$tplDisplayData['EMAIL_VALUE'] = (isset($_POST['email']) ? cleanData($_POST['email']) : '');
		$tplDisplayData['SUBJECT_VALUE'] = (isset($_POST['subject']) ? cleanData($_POST['subject']) : '');
		$tplDisplayData['COMMENT_VALUE'] = (isset($_POST['comments']) ? cleanData($_POST['comments']) : '');

		if(!isset($SENT)){
			$tplDisplayData['CAPTCHA'] =showCaptcha(JText::_( _msg_contact11),(isset($SUM_ERROR) ? '<br /><span class="mm_error">'.JText::_( _msg_contact12).'</span>' : ''), $this->SETTINGS->enable_captcha);
		}

		$tplDisplayData['N_ERROR'] = (isset($N_ERROR) ? '<br /><span class="mm_error">'.JText::_( _msg_contact15).'</span>' : '');
		$tplDisplayData['E_ERROR'] = (isset($E_ERROR) ? '<br /><span class="mm_error">'.JText::_( _msg_contact16).'</span>' : '');
		$tplDisplayData['S_ERROR'] = (isset($S_ERROR) ? '<br /><span class="mm_error">'.JText::_( _msg_contact6).'</span>' : '');
		$tplDisplayData['C_ERROR'] = (isset($C_ERROR) ? '<br /><span class="mm_error">'.JText::_( _msg_contact7).'</span>' : '');
		$tplDisplayData['SEND_TEXT'] = JText::_( _msg_contact5);

		HTML_maiainFront::show_ContactPage($tplDisplayData);
	}

	function rss()
	{
		$db =& JFactory::getDBO();
		$rss_feed       = '';
		$build_date     = date('D, j M Y H:i:s').' GMT';
		$MM_FEED              = new rss_Feed();
		// Open channel..
		$rss_feed = $MM_FEED->open_channel();
		// Feed info..
		$rss_feed .= $MM_FEED->feed_info(str_replace("{website_name}",$this->SETTINGS->website_name,JText::_( _msg_rss),
		JRoute::_('index.php'),
		$build_date,
		str_replace("{website_name}",$this->SETTINGS->website_name,JText::_( _msg_rss2))),
		$this->SETTINGS->website_name);
			
		// Get latest posts..
		$db->setQuery("SELECT * FROM #__m15_albums
                        ORDER BY id DESC 
                        LIMIT ".$this->SETTINGS->rssfeeds."
                        ") ;
		$query = $db->loadObjectList();
		foreach($query as $RSS){
			$rss_feed .= $MM_FEED->add_item(JText::_( _msg_rss3).$RSS->artist.' - '.$RSS->name,
			JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$RSS->id),
			($RSS->rss_date ? $RSS->rss_date : $build_date),
			$RSS->comments);
		}
		// Close channel..
		$rss_feed .= $MM_FEED->close_channel();
		// Display RSS feed..
		header('Content-Type: text/xml');

		HTML_maiainFront::show_RSS($rss_feed);
	}

	function search()
	{
		global $mainframe, $option;

		$app =& JFactory::getApplication();
		$breadcrumbs = & $app->getPathWay();
		$breadcrumbs->addItem(JText::_( _msg_public_header7), 'index.php?option=com_maian15&view=search');
		$id = intval(cleanData(JRequest::getVar('Itemid')));
		$limitstart = intval(cleanData(JRequest::getVar('limitstart')));

		$db =& JFactory::getDBO();

		$db->setQuery("SELECT params FROM #__menu WHERE id = $id") ;
		$query = $db->loadObject();
		$param = $query->params;

		if(!isset($param)){
			$db->setQuery("SELECT params FROM #__menu WHERE link like '%index.php?option=com_maian15&view=music%' and type like 'component'");
			$query = $db->loadObject();
			$param = $query->params;

			if(!isset($param)){
				$param = "display_num=5
						orderBy=name-asc
						column=0
						show_page_title=1
						pageclass_sfx=
						menu_image=-1
						secure=0";
			}
		}else{
			$this->menu_link = '&Itemid'.$id;
		}

		$lines = explode("\n", trim($param));

		for ($i=0; $i<count($lines);$i++){
			list($key,$val) = explode("=", $lines[$i]);
			$params [trim(urldecode($key))] = trim(urldecode($val));
		}

		$title  = $title.' - '.JText::_( _msg_public_header7);
		$sql    = '';
		$sData  = '';
		$db =& JFactory::getDBO();
		$uri =& JURI::getInstance();
		// Search database..
		if (!isset($_GET['keywords'])) {
			header("Location: ".JRoute::_('index.php?option=com_maian15&Itemid='.$this->menu_link->id)."");
			exit;
		}
		// Split keywords and trim whitespace..
		$keys = array_map('trim',explode(" ", cleanEvilTags($_GET['keywords'])));
		// Loop through keywords...
		for ($i=0; $i<count($keys); $i++) {
			$sql .= ($i ? 'OR ' : 'WHERE ')."(artist LIKE '%".mysql_real_escape_string($keys[$i])."%' OR name LIKE '%".mysql_real_escape_string($keys[$i])."%' OR keywords LIKE '%".mysql_real_escape_string($keys[$i])."%') and status='1'";
		}

		$limit = $mainframe->getUserStateFromRequest( "limit", 'limit', intval($params['display_num']));

		if($limitstart > 0){
			$limitstart = $mainframe->getUserStateFromRequest( "$option.limitstart", 'limitstart', 0 );
		}

		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

		// Get Count.
		$db->setQuery("SELECT id FROM #__m15_albums $sql") ;

		$q_music =  $db->loadObjectList();
		$count = count($q_music);

		// Query database..
		$db->setQuery("SELECT * FROM #__m15_albums $sql
		LIMIT $limitstart,$limit") ;

		$q_music =  $db->loadObjectList();

		if($params['more_info'] == '0'){
			$style = 'display: none;';
		}else{
			$style = '';
		}

		if (count($q_music)>0 && $keys) {

			foreach($q_music as $MUSIC){
					
				$image_link = $uri->root().'components/com_maian15/media/icons/no_picture.png';
				$more_info_image = $uri->root().'components/com_maian15/media/icons/more_info.png';
				$images_dimensions = '';
					
				if($MUSIC->image != ""){
					$image_link = $MUSIC->image;
					$images_dimensions = 'height=75px width=75px';
				}
				//$find     = array('{url}','{more_info}','{artist}','{album_title}','{tracks}');
				//$replace  = array(JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$MUSIC->id),JText::_( _msg_music2,cleanData($MUSIC->artist),cleanData($MUSIC->name),str_replace("{count}",getTrackCount($MUSIC->id),JText::_( _msg_music3));
				$find     = array('{url}','{more_info_image}','{label}','{dimensions}','{album_image}','{more_info}','{artist}','{album_title}','{tracks}');
				$replace  = array(JRoute::_('index.php?option=com_maian15&view=album&amp;album='.$MUSIC->id),
				$more_info_image,$MUSIC->label,$images_dimensions, $image_link,JText::_( _msg_music2),cleanData($MUSIC->artist),cleanData($MUSIC->name),str_replace("{count}",getTrackCount($MUSIC->id),JText::_( _msg_music3)));
				$sData .= str_replace($find,$replace,

				file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'album_data.html')

				);
			}
		} else {

			$sData = str_replace("{message}",JText::_( _msg_publicsearch3),file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'message.html'));

		}
		$tplDisplayData = array();
		$tplDisplayData['SEARCH_TEXT'] =  JText::_( _msg_publicsearch);
		$tplDisplayData['SEARCH_MESSAGE'] =  str_replace("{keywords}",cleanEvilTags($_GET['keywords']),JText::_( _msg_publicsearch2));
		$tplDisplayData['SEARCH_DATA'] =  $sData;
		jimport('joomla.html.pagination');
		$pageNav = new JPagination($count, $limitstart, $limit );
		$tplDisplayData['PAGE_NUMBERS']= $pageNav->getPagesLinks();
		HTML_maiainFront::show_SearchPage($tplDisplayData);

	}

	function licence()
	{
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__m15_pages WHERE name LIKE 'license'") ;
		$pages = $db->loadObject();

		$title = $title.' - '.JText::_( _msg_public_header12);
		$tplDisplayData = array();
		$tplDisplayData['LICENCE_TEXT'] = JText::_( _msg_public_header12);
		$tplDisplayData['LICENCE'] = nl2br(cleanData($pages->text));
		HTML_maiainFront::show_LicencePage($tplDisplayData);
	}

	function about()
	{
		$db->setQuery("SELECT * FROM #__m15_pages WHERE name LIKE 'about'") ;
		$pages = $db->loadObject();

		$title = $title.' - '.JText::_( _msg_public_header6);
		$tplDisplayData = array();
		$tplDisplayData['ABOUT_TEXT'] = JText::_( _msg_public_header6);
		$tplDisplayData['ABOUT'] = nl2br(cleanData($pages->text));

		HTML_maiainFront::show_AboutPage($tplDisplayData);
	}

	function isAdded($id)
	{
		$album_array = $_SESSION['album_id'];

		if(isset($album_array)){

			if(in_array($id, $album_array)){
				return '<div id="album_add" style="font-weight: bold;">'._msg_albums23.'</div>';
			}
		}
	}

	function getLink($id)
	{
		$track_id = intval($id);
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__m15_tracks
		WHERE id = '{$track_id}'");
		$track = $db->loadObject();

		if(isset($_GET['album'])){
			$track_album = $track->track_album;
		}else{
			$track_album = '0';
		}

		if($track->track_cost !='0.00'){
			$track_array = $_SESSION['track_id'];

			if($this->SETTINGS->ajax == '0'){
				return '<input type="checkbox" name="track[]" value="'.$id.'" />';
			}

			if(isset($track_array)){
				if(in_array($track_id, $track_array)){
					$link = '<img onclick="updateCart(\'index.php?option=com_maian15&format=raw&section=cart&task=removeTrack&track='.$track_id.'&code='.$this->getEntryCode($track_id).'\', \'\', \'box_'.$track_id.'\');" src="components/com_maian15/media/cart/removeFromCart.png" />';
				}else{
					$link = '<img onclick="updateCart(\'index.php?option=com_maian15&format=raw&section=cart&task=addToCart&track='.$track_id.'\', \'\', \'box_'.$track_id.'\');" src="components/com_maian15/media/cart/addToCart.png" />';
				}
				return $link;
			}else{
				if($track->freebie =='1'){
					$link = "index.php?option=com_maian15&format=raw&section=download&task=freebie&track=$track_id&track_album=$track_album";
					$link = '<a href="'.$link.'" title="'.JText::_(_msg_free_download).'"><img src="components/com_maian15/media/cart/free_download.png" alt="'.JText::_(_msg_free_download).'" title="'.JText::_(_msg_free_download).'" /></a>';
				}else{
					$link = '<img onclick="updateCart(\'index.php?option=com_maian15&format=raw&section=cart&task=addToCart&track='.$track_id.'\', \'\', \'box_'.$track_id.'\');" src="components/com_maian15/media/cart/addToCart.png" />';
				}
				return $link;
			}
		}else{
			JHTML::_('behavior.modal', 'a.modal-button');

			$link = "index.php?option=com_maian15&format=raw&section=download&task=freebie&track=$track_id&track_album=$track_album";
			return '<a href="'.$link.'" title="'.JText::_(_msg_free_download).'"><img src="components/com_maian15/media/cart/free_download.png" alt="'.JText::_(_msg_free_download).'" title="'.JText::_(_msg_free_download).'" /></a>';
		}

	}

	function getEntryCode($id){
		$code = "";
		for ($i=0; $i<count($_SESSION['entry_code']); $i++) {
			if ($id==$_SESSION['track_id'][$i]) {
				$code = $_SESSION['entry_code'][$i];
			}
		}
		return $code;
	}

	function getOrder($param){

		$sql = "";
		switch ($param) {
			case 'name-asc'		:    $sql = " ORDER BY name, artist ASC";      break;
			case 'name-desc'	:     $sql = " ORDER BY name, artist DESC ";           break;
			case 'artist-asc'	:       $sql = " ORDER BY artist,name ASC";  break;
			case 'artist-desc'	:    $sql = " ORDER BY artist,name DESC ";  break;
			case 'date-asc'		:   $sql = " ORDER BY addDate DESC";         break;
			case 'hits'			:    $sql = " ORDER BY hits ";              break;
			case 'track-asc'	:	$sql = "ORDER BY track_name ASC"; break;
			case 'track-desc'	:	$sql = "ORDER BY track_name DESC"; break;
			case 'id'	:	$sql = "ORDER BY id DESC"; break;
		}

		return $sql;

	}

	function isValidEmail($email){
		return eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email);
	}

	function verifyEmail(){

		$name = cleanData(JRequest::getVar('mm_name_'));
		$email = trim(cleanData(JRequest::getVar('mm_email_')));

		if(empty($name)){
			echo JText::_(_msg_require_field);
			exit;
		}

		if(!$this->isValidEmail($email)){
			echo JText::_(_msg_invalid_email);
			exit;
		}

		/*$test = $this->validDomain($email);

		if(!$test){
		echo'Could not validate domain address.  Please try another email';
		exit;
		}*/

		$id = intval(cleanData(JRequest::getVar('item_id_')));

		$db =& JFactory::getDBO();
		$db->setQuery("SELECT params FROM #__menu WHERE id = $id") ;
		$query = $db->loadObject();
		$param = $query->params;

		if(!isset($param)){
			$db->setQuery("SELECT params FROM #__menu WHERE link like '%index.php?option=com_maian15&view=freebie%' and type like 'component'");
			$query = $db->loadObject();
			$param = $query->params;
		}


		$lines = explode("\n", trim($param));

		for ($i=0; $i<count($lines);$i++){
			list($key,$val) = explode("=", $lines[$i]);
			$params [trim(urldecode($key))] = trim(urldecode($val));
		}


		switch ($params['system']) {
			case 'acajoom':
				$path = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acajoom'.DS.'subscribers.acajoom.php';
				if (!file_exists($path)) {
					echo JText::_(_msg_newsletter);
					break;
				}

				include_once($path);
				include_once(JPATH_PLUGINS.DS.'acajoom'.DS.'acajoombot.php');
				include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acajoom'.DS.'classes'.DS.'class.erro.php');
				include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acajoom'.DS.'classes'.DS.'class.subscribers.php');
				include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acajoom'.DS.'classes'.DS.'class.xonfig15.php');
				include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acajoom'.DS.'classes'.DS.'class.acajoom.php');
				include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acajoom'.DS.'admin.acajoom.html.php');
				include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acajoom'.DS.'subscribers.acajoom.html.php');

				$action = 'subscribers';
				$task =  'doNew';
				$userid = '0';
				$listId =  '0';
				$cid;

				JRequest::setVar('name', $name);
				JRequest::setVar('email', $email);
				subscribers( $action, $task, $userid, $listId, $cid );
				$_SESSION['mm_email'] = $email;
				ob_clean();
				echo '<span style="font-size: larger; color: rgb(0, 153, 0); font-weight: bold;">'.JText::_(_msg_download_message2).'</span><br>';
				$this->getTrackAlbum();
				break;

			case 'ccnews':
				$path = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ccnewsletter'.DS.'models'.DS.'subscriber.php';

				if (!file_exists($path)) {
					echo JText::_(_msg_newsletter);
					break;
				}

				include_once($path);
				include_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_ccnewsletter'.DS.'tables'.DS.'subscriber.php');
				include_once(JPATH_SITE.DS.'components'.DS.'com_ccnewsletter'.DS.'models'.DS.'ccnewsletter.php');

				$Newsletter = new ccNewsletterModelccNewsletter();
				$Newsletter->addSubscriber($name, $email);
				$_SESSION['mm_email'] = $email;
				echo '<span style="font-size: larger; color: rgb(0, 153, 0); font-weight: bold;">'.JText::_(_msg_download_message2).'</span><br>';
				$this->getTrackAlbum();
				break;
		}



	}

	function getTrackAlbum()
	{
		$album = intval(cleanData(JRequest::getVar('mm_album_')));
		$track = intval(cleanData(JRequest::getVar('mm_track_')));

		if($album !='0'){
			echo '</br><input class="button" type="submit" value="'.JText::_(_msg_return_to).'" onclick="window.location=\'index.php?option=com_maian15&view=album&album='.$album.'\'"/>';
		}else{
			echo '</br><input class="button" type="submit" value="'.JText::_(_msg_return_to).'" onclick="window.location=\'index.php?option=com_maian15&view=freebie\'"/>';
		}
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__m15_tracks
		WHERE id = '$track'") ;
		$track = $db->loadObject();

		//Protect from people trying to steal other tracks!!!
		if($track->track_cost != '0.00'){
			echo '<div id="thief">'.JText::_(_msg_theif).'</div>';
			return;
		}


		$this->MM_CART->forceDownload($this->SETTINGS->mp3_path.DS.$track->mp3_path, JText::_(_msg_paypal27));

	}

	/**
	 Validate an email address.
	 Provide email address (raw input)
	 Returns true if the email address has the email
	 address format and the domain exists.
	 */
	function validDomain($email)
	{
		$isValid = true;
		$atIndex = strrpos($email, "@");
		if (is_bool($atIndex) && !$atIndex)
		{
			$isValid = false;
		}
		else
		{
			$domain = substr($email, $atIndex+1);
			$local = substr($email, 0, $atIndex);
			$localLen = strlen($local);
			$domainLen = strlen($domain);
			if ($localLen < 1 || $localLen > 64)
			{
				// local part length exceeded
				$isValid = false;
			}
			else if ($domainLen < 1 || $domainLen > 255)
			{
				// domain part length exceeded
				$isValid = false;
			}
			else if ($local[0] == '.' || $local[$localLen-1] == '.')
			{
				// local part starts or ends with '.'
				$isValid = false;
			}
			else if (preg_match('/\\.\\./', $local))
			{
				// local part has two consecutive dots
				$isValid = false;
			}
			else if (!preg_match('/^[A-Za-z0-9\\-\\.]+$/', $domain))
			{
				// character not valid in domain part
				$isValid = false;
			}
			else if (preg_match('/\\.\\./', $domain))
			{
				// domain part has two consecutive dots
				$isValid = false;
			}
			else if(!preg_match('/^(\\\\.|[A-Za-z0-9!#%&`_=\\/$\'*+?^{}|~.-])+$/',
			str_replace("\\\\","",$local)))
			{
				// character not valid in local part unless
				// local part is quoted
				if (!preg_match('/^"(\\\\"|[^"])+"$/',
				str_replace("\\\\","",$local)))
				{
					$isValid = false;
				}
			}

			if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {

				if ($isValid && !($this->checkdnsrr($domain,"MX") || $this->checkdnsrr($domain,"A")))
				{
					// domain not found in DNS
					$isValid = false;
				}
			} else {
				if ($isValid && !(checkdnsrr($domain,"MX") || checkdnsrr($domain,"A")))
				{
					// domain not found in DNS
					$isValid = false;
				}
			}


		}
		return $isValid;
	}

	/********************
	 Windows checkdnsrr 1.0
	 By Hamish Milne
	 int checkdnsrr ( string $host [, string $type ] )
	 $type can be: A, ANY, CNAME, MX, NS, PTR, SOA, SRV, etc. default is MX

	 A checkdnsrr function compatible with Windows.
	 Exactly the same as the linux version
	 See the PHP documentation for further info:
	 http://www.php.net/checkdnsrr
	 Requires:
	 nslookup - ie. Windows - with access to 4.2.2.3
	 PHP >= 4.0.3
	 shell_exec() enabled - ie. safe mode disabled
	 ********************/

	function checkdnsrr($host, $type='mx'){
		$res=explode("\n",strstr(shell_exec('nslookup -type='.$type.' '.escapeshellarg($host).' 4.2.2.3'),"\n\n"));
		if($res[2]){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	function getLangDisplay()
	{
		$data = '';

		$getstring = 'index.php?';

		foreach($_GET as $var => $value)
		{
			$getstring = $getstring.$var . '=' . $value.'&';
		}

		// Load language files..
		$langDir = opendir(JPATH_COMPONENT_SITE.DS.'lang'.DS);
		$uri =& JURI::getInstance();

		while ($READ = readdir($langDir))
		{
			if ($READ != "." && $READ != ".." && $READ != "index.html" && $READ != ".svn") {
				$lang = substr($READ, 0, strpos($READ, '.'));

				$location = $uri->root().'components/com_maian15/media/flags/'.$lang.'.png';

				$langText = ucfirst(str_replace("_", " ", $lang));

				$data .= '
				<li>
					<a title="'.$langText.'" '.($_SESSION['maian_lang'] == $READ ? 'class="activeFlag"':'').' href="'.$getstring .'getlang='.$lang.'">
						<img src="'.$location.'" alt="'.$langText.'" class="regularFlag" height="11" width="16">
					</a>
				</li>';

			}
		}

		closedir($langDir);
		return $data;
	}

	function display()
	{
		if($this->SETTINGS->default_page == '0'){
			header("Location: ".JRoute::_('index.php?option=com_maian15&view=album&album='.$this->menu_link->id)."");
		}else{
			header("Location: ".JRoute::_('index.php?option=com_maian15&view=music&Itemid='.$this->menu_link->id)."");
		}
	}

}//end MaianControllerDefault