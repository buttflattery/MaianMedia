<?php
/**
 * Download Controller
 *
 * @package    Maian Music 1.3
 * @subpackage Controllers
 * @link http://www.aretimes.com
 * @license		GNU/GPL
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class MaianControllerDownload extends MaianController
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	var $document;

	function __construct()
	{
		parent::__construct();
		$this->document = &JFactory::getDocument();
	}

	function display()
	{

		// Check code..
		if (!isset($_GET['code']) || (isset($_GET['code']) && !ctype_alnum($_GET['code']))) {

			$tplDisplayData = array();
			$tplDisplayData['ERROR_TEXT'] = JText::_(_msg_paypal9);
			$tplDisplayData['ERROR_MESSAGE'] = JText::_(_msg_paypal10);

			HTML_maiainFront::show_ErrorPage($tplDisplayData);
			return;
		}

		// Is code valid...
		if (!$this->MM_CART->getDownloadData($_GET['code'],true)) {
			$tplDisplayData = array();
			$tplDisplayData['ERROR_TEXT'] = JText::_(_msg_paypal9);
			$tplDisplayData['ERROR_MESSAGE'] = JText::_(_msg_paypal11);
			HTML_maiainFront::show_ErrorPage($tplDisplayData);

			return;
		}
		// Assign cart data array to var..
		$cartPurchase = $this->MM_CART->getDownloadData($_GET['code']);
		// Has download page expired..
		if ($this->SETTINGS->page_expiry>0 && ($this->SETTINGS->page_expiry==$cartPurchase->visits)) {

			$tplDisplayData = array();
			$tplDisplayData['ERROR_TEXT'] = JText::_(_msg_paypal12);
			$tplDisplayData['ERROR_MESSAGE'] = str_replace("{store}",cleanData($this->SETTINGS->website_name),JText::_(_msg_paypal13));
			HTML_maiainFront::show_ErrorPage($tplDisplayData);
			return;
		}
		// Update page visits..
		$this->MM_CART->updateDownloadPageVisits($cartPurchase->download_code);
		// Ok, all checks passed, now display download data on page...
		$albumData  = '';
		$trackData  = '';
		$db =& JFactory::getDBO();

		if($this->SETTINGS->hide_lightbox == '1'){
			$item_code = '55798';
			JHTML::_('behavior.mootools');
		}else{
			$item_code = '55788';
		}
		// Album data..
		if ($this->MM_CART->albumDownloads($cartPurchase->cart_code,true)) {
			// Assign album data to array..
			$db->setQuery("SELECT * FROM #__m15_purchases
			WHERE cart_code             = '{$cartPurchase->cart_code}'
			AND SUBSTRING(item_id,1,1)  = 'a'
			AND track_id                = '0'") ;	$q_album = $db->loadObjectList();
			foreach($q_album as $aD){
				$info = $this->MM_CART->getTrackOrAlbumData(substr($aD->item_id,1),'album');

				if($item_code == '55798'){
					$this->getJs($aD->download_code);
					$albumData .= str_replace(array('class="modal-button"', '{item_name}','{download_url}','{download_this_item}','{artwork}'),
					array('id="a_'.$aD->download_code.'"',
					cleanData($info->artist).' - '.cleanData($info->name),
					JRoute::_('index2.php?option=com_maian15&section=download&task=fetch&item=55788&amp;code='.$aD->download_code),
					JText::_(_msg_paypal26),
					($info->artwork && strlen($info->artwork)>7 ? '<a href="'.$info->artwork.'"><img src="media/cart/artwork.gif" alt="'.JText::_(_msg_paypal25).'" title="'.JText::_(_msg_paypal25).'" /></a>' : ''),
					),
					file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'download_item_album.html'));
						
					$albumData .='<div id="album_data_'.$aD->download_code.'"></div>';
						
				}else{

					$albumData .= str_replace(array('{item_name}','{download_url}','{download_this_item}','{artwork}'),
					array(
					cleanData($info->artist).' - '.cleanData($info->name),
					JRoute::_('index2.php?option=com_maian15&section=download&task=fetch&item=55788&amp;code='.$aD->download_code),
					JText::_(_msg_paypal26),
					($info->artwork && strlen($info->artwork)>7 ? '<a href="'.$info->artwork.'"><img src="media/cart/artwork.gif" alt="'.JText::_(_msg_paypal25).'" title="'.JText::_(_msg_paypal25).'" /></a>' : ''),
					),
					file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'download_item_album.html'));
				}
			}
		} else {
			$albumData = str_replace("{message}",JText::_(_msg_paypal21),file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'message.html'));
		}
		// Track data..
		if ($this->MM_CART->trackDownloads($cartPurchase->cart_code,true)) {
			$db =& JFactory::getDBO();
			// Assign track data to array..
			$db->setQuery("SELECT * FROM #__m15_purchases
			WHERE cart_code             = '{$cartPurchase->cart_code}'
			AND SUBSTRING(item_id,1,1)  = 't'
			AND track_id                = '0'") ;	

			$q_track = $db->loadObjectList();

			foreach($q_track as $tD){
				$info   = $this->MM_CART->getTrackOrAlbumData(substr($tD->item_id,1),'track');
				$ainfo  = $this->MM_CART->getTrackOrAlbumData($info->track_album,'album');
				$trackData .= str_replace(array('{item_name}','{download_url}','{download_this_item}','{artwork}'),
				array(cleanData($ainfo->artist).' - '.cleanData($info->track_name),
				JRoute::_('index2.php?option=com_maian15&format=raw&section=download&task=fetch&item='.$item_code.'&amp;code='.$tD->download_code),
				JText::_(_msg_paypal24),''),
				file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'download_item_track.html'));
			}
		} else {
			$trackData = str_replace("{message}",JText::_(_msg_paypal22),file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'message.html'));
		}
		// Set permissions session var..
		// If this isn`t set when the download window opens, terminate..
		// Prevents someone from sending a direct link to the download window..
		$_SESSION['download_permissions'] = '1';
		$tplDisplayData = array();
		$tplDisplayData['DOWNLOAD_TEXT'] =  JText::_(_msg_paypal14);
		$tplDisplayData['DOWNLOAD_MESSAGE'] =  str_replace("{duration}",($this->SETTINGS->download_expiry=='1' ? '<b>'.JText::_(_msg_paypal16).'</b>' : ($this->SETTINGS->download_expiry=='2' ? '<b>'.JText::_(_msg_paypal17).'</b>' : '<b>'.($this->SETTINGS->download_expiry==0 ? JText::_(_msg_script12) : $this->SETTINGS->download_expiry).'</b> '.JText::_(_msg_paypal18))),JText::_(_msg_paypal15));
		$tplDisplayData['ALBUMS'] = JText::_(_msg_paypal19);
		$tplDisplayData['TRACKS'] = JText::_(_msg_paypal20);
		$tplDisplayData['ALBUM_DATA'] = $albumData;
		$tplDisplayData['TRACK_DATA'] = $trackData;
		$tplDisplayData['ENJOY_MUSIC'] =  JText::_(_msg_paypal23);
		HTML_maiainFront::show_DownloadPage($tplDisplayData);
	}
	private function getJs($code){

		$js="
		 <script type=\"text/javascript\">
		/* <![CDATA[ */
		 
		//on dom ready...
window.addEvent('domready', function() {

	/* ajax replace element text */
	$('a_$code').addEvent('click', function(event) {
				//prevent the page from changing
				if(event.preventDefault) event.preventDefault();
				
				$('album_data_$code').innerHTML='<img src=\"components/com_maian15/ajax/ajax-loader.gif\"style=\'display:block;margin: 0 auto;\' alt=\'Updating ...\'/>';

				new Ajax(this, {
					method: 'get',
					update: $('album_data_$code')
				}).request();
				
				
				
	});
});
/* ]]> */

</script>

		";
		$this->document->addCustomTag($js);
	}
	function freebie(){

		$track_id = intval(cleanData(JRequest::getVar('track')));
		$track_album = intval(cleanData(JRequest::getVar('track_album')));

		$db =& JFactory::getDBO();

		if(!isset($query)){
			$db->setQuery("SELECT params FROM #__menu WHERE link like '%index.php?option=com_maian15&view=freebie%' and type like 'component'");
			$query = $db->loadObject();
			if(!isset($query)){
				$query =   "display_num=5
							orderBy=track-desc
							email=0
							accept_users=1
							color=#F5F5F5
							system=ccnews
							newslist=1
							page_title=
							show_page_title=1
							pageclass_sfx=
							menu_image=-1
							secure=0";
			}
		}

		$lines = explode("\n", trim($query->params));

		for ($i=0; $i<count($lines);$i++){
			list($key,$val) = explode("=", $lines[$i]);
			$params [urldecode($key)] = urldecode($val);
		}

		$db->setQuery("SELECT * FROM #__m15_tracks WHERE id = $track_id") ;
		$track = $db->loadObject();
		$cost = floatval($track->track_cost);

		//Protect from people trying to steal other tracks!!!
		if($track->track_cost != '0.00' && $track->freebie != '1'){
			if($track->freebie != '1'){
				echo '<div id="thief">'.JText::_(_msg_theif).'</div>';
				return;
			}
		}

		$user =& JFactory::getUser();

		if($params ['email'] == '1' ){
			if($params['accept_users'] == '1'){
				if(isset($_SESSION['mm_email']) && $user->guest){
					$this->MM_CART->forceDownload($this->SETTINGS->mp3_path.DS.$track->mp3_path, JText::_(_msg_paypal27));
				}else if(!$user->guest){
					$this->MM_CART->forceDownload($this->SETTINGS->mp3_path.DS.$track->mp3_path, JText::_(_msg_paypal27));
				}else{
					$document = &JFactory::getDocument();
					$document->addScript( 'components/com_maian15/ajax/cartajax.js');
					$find       = array('{item_id}','{required_field}','{invalid_address}','{name}','{email}', '{submit}');
					$replace    = array($id, JText::_(_msg_require_field), JText::_(_msg_invalid_email), JText::_(_msg_name), JText::_(_msg_email), JText::_(_msg_submit));
					$sData .= str_replace($find,$replace,
					file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'free_download.html'));
					echo '<div id="no_email">'.JText::_(_msg_must_provide).'</div>';
					echo '<input type="hidden" id="mm_album" name="mm_album" value="'.$track_album.'" />';
					echo '<input type="hidden" id="mm_track" name="mm_track" value="'.$track->id.'" />';
					echo $sData;

				}
			}
		}else{
			$this->MM_CART->forceDownload($this->SETTINGS->mp3_path.DS.$track->mp3_path, JText::_(_msg_paypal27));
		}

	}


	function fetch()
	{
		$task = JRequest::getVar('item');

		switch($task){
			case '55788':
			case '55798':
			case '55799':
				$data = '';
				$link = '';
				$size = 0;
				$file = $this->MM_CART->getDownloadFile($_GET['code']);
				// Are permissions set..
				if (!isset($_SESSION['download_permissions'])) {
					$data  = JText::_(_msg_downloaditem2);
					$link  = '';
				}
				// Has download expired..
				if ($this->SETTINGS->download_expiry>0 && ($this->SETTINGS->download_expiry==$file->downloads)) {
					$data  = JText::_(_msg_downloaditem);
					$link  = ($task=='55799' ? str_replace(array('{url}','{back_to_previous_page}'),
					array(
					JRoute::_('index.php?option=com_maian15&section=download&amp;code='.$this->MM_CART->getDownloadPageCode($_GET['code'])),
					JText::_(_msg_paypal30)
					),
					file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'back_link.html')
					)
					: '');
				}
				// Show download link..
				if ($data=='' && $task=='55788') {
					if (substr($file->item_id,0,1)=='a') {
						$info    = $this->MM_CART->getTrackOrAlbumData(substr($file->item_id,1),'album');
						$cart    = $this->MM_CART->getDownloadFile($_GET['code']);
						$name    = cleanData($info->name);
						$artist  = cleanData($info->artist);
						$size    = $this->MM_CART->downloadSize(substr($file->item_id,1),'album',$this->SETTINGS);
						$tracks  = '';
						$db =& JFactory::getDBO();
						// Get tracks..
						$db->setQuery("SELECT * FROM #__m15_purchases
						WHERE item_id  = '{$file->item_id}'
						AND cart_code  = '{$cart->cart_code}'
						AND track_id   > '0'
						ORDER BY id
                               ") ;
						$q_tracks = $db->loadObjectList();
						foreach($q_tracks as $TRACKS){
							$t        = $this->MM_CART->getTrackOrAlbumData($TRACKS->track_id,'track');
							$find     = array('{url}','{image}','{click_to_download}','{track}','{size}');
							$replace  = array(JRoute::_('index.php?option=com_maian15&section=download&task=fetch&item=55799&amp;code='.$TRACKS->download_code),
							($this->SETTINGS->download_expiry>0 && ($TRACKS->downloads==$this->SETTINGS->download_expiry) ? 'expired.gif' : 'small_download2.gif'),
							($this->SETTINGS->download_expiry>0 && ($TRACKS->downloads==$this->SETTINGS->download_expiry) ? JText::_(_msg_paypal31) : JText::_(_msg_paypal24)),
							cleanData($t->track_name),
							file_size_conversion($this->MM_CART->downloadSize($TRACKS->track_id,'track',$this->SETTINGS)));
							$tracks .= str_replace($find,$replace,
							file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.'album_tracks.html'));
						}
					} else {
						$info    = $this->MM_CART->getTrackOrAlbumData(substr($file->item_id,1),'track');
						$name    = cleanData($info->track_name);
						$size    = $this->MM_CART->downloadSize(substr($file->item_id,1),'track',$this->SETTINGS);
					}
					$data = str_replace(array('{artist}','{name}','{download_url}','{size}','{click_to_download}','{click_to_download2}','{tracks}'),
					array(
					(isset($artist) ? $artist : ''),
					$name,
					JRoute::_('index.php?option=com_maian15&section=download&task=fetch&item=55798&amp;code='.$file->download_code),
					(isset($artist) ? JText::_(_msg_paypal28).' ' : '').file_size_conversion($size),
					JText::_(_msg_paypal29),
					JText::_(_msg_paypal24),
					(isset($tracks) ? $tracks : '')
					),
					file_get_contents(JPATH_COMPONENT.DS.'html'.DS.'tpl'.DS.(substr($file->item_id,0,1)=='a' ? 'download_window_album.html' : 'download_window_track.html').'')
					);
				}

				// Download track/album..
				if ($data=='' && ($task=='55798' || $task=='55799')) {
					// Update purchase download count..
					$this->MM_CART->updateFileDownloadCount($file->id);
					// Determine track id..
					$t_id = ($task=='55798' ? substr($file->item_id,1) : $file->track_id);
					// Path to mp3 file..
					$mp3_path = $this->SETTINGS->mp3_path.'/'.$this->MM_CART->getMP3PathForZipFile($t_id,'track');
					// Download..
					$this->MM_CART->forceDownload($mp3_path,JText::_(_msg_paypal27));
					exit;
				}
				$tplDisplayData = array();
				$tplDisplayData['DATA'] =  $data;
				$tplDisplayData['LINK'] =  $link;

				HTML_maiainFront::show_ItemPage($tplDisplayData);

				break;
		}
	}

}
?>