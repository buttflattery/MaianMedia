<?php
/**
 * @package    Maian Music
 * @subpackage Components
 * @link http://www.aretimes.com
 * @license    GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Load Base Contorller Class

require_once( JPATH_COMPONENT.DS.'controllers'.DS.'defaultController.php' );
//set Globals

// Require specific controller if requested
if($controller = JRequest::getWord('controller')) {

	$path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'Controller.php';

	if (file_exists($path)) {
		require_once $path;
	}else {
		$controller = 'default';
	}

	$classname    = 'MaianController'.$controller;
	$controller   = new $classname( );

}else{
	$controller   = new MaianControllerDefault( );
}

$db = & JFactory::getDBO();
$db->setQuery("SELECT * FROM #__m15_settings");
$SETTINGS = $db->loadObject();
// Load language file..

if($SETTINGS->language == ""){
	include(JPATH_COMPONENT_SITE.DS.'lang'.DS.'english.php');
}else{
	include(JPATH_COMPONENT_SITE.DS.'lang'.DS.$SETTINGS->language);
}

if(!JRequest::getVar( 'resend' )){
	include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');
}
if((JRequest::getVar( 'view' ) || JRequest::getVar( 'limit' )) && !JRequest::getVar( 'resend' ) && JRequest::getVar( 'format' )!='raw'){
	$document = &JFactory::getDocument();
	$document->addCustomTag('<link href="components/com_maian15/stylesheet.css" rel="stylesheet" type="text/css" />');
	JHTML::_('behavior.modal', 'a.modal-button');
	$uri =& JURI::getInstance();
	$document->addScript( 'components/com_maian15/js/overlib.js' );
	$document->addScript( 'components/com_maian15/js/swfobject.js' );
	$document->addScript( 'components/com_maian15/js/request.js' );

}
// Create the controller

// Perform the Request task
$controller->execute( JRequest::getVar( 'task' ) );

// Redirect if set by the controller
$controller->redirect();
?>