<?php
/**
 * Hello View for Hello World Component
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );

/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewTrack extends JView
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{

		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__m15_settings Limit 1");
		$settings = $db->loadObject();

		if(JRequest::getVar('task') == 'edit'){
			JToolBarHelper::save('update_tracks'  , 	'save' );
		}else{
			JToolBarHelper::save();
		}

		if(JRequest::getVar('task') == 'add'){
			JToolBarHelper::title(   JText::_(_msg_header5), 'add.png' );
		}else{
			JToolBarHelper::title(   JText::_(_msg_header6), 'tracks.png' );
			//JToolBarHelper::deleteList(JText::_(_msg_javascript15), "remove", "Delete");
		}

		JToolBarHelper::cancel();

		if(JRequest::getVar('cid')) {
			$id = JRequest::getVar('cid');
				
			// Query database for paypal information..
			$db->setQuery("SELECT * FROM #__m15_tracks
                             WHERE track_album = '".$id."'
                             ORDER BY track_order");

			$tracks = $db->loadObjectList();
			$this->assignRef('tracks', $tracks);
			$this->assignRef('settings', $settings);
		}

		jimport('joomla.filesystem.file');
		$authFile = JPATH_COMPONENT.DS.'functions'.DS.'auth.php';
		$data = JFile::read($authFile);

		JPath::setPermissions($authFile, '0755');

		if($data === false){
			JError::raiseNotice( 100, 'Warning: '.JPATH_COMPONENT.DS.'functions'.DS.'auth.php must be readable for the uploader to work' );
		}else{
			$ret = file_put_contents($authFile, $data);
				
			if($ret === false){
				JError::raiseNotice( 100, 'Warning: '.JPATH_COMPONENT.DS.'functions'.DS.'auth.php must be writable for the uploader to work' );
			}
		}

		if(!JFolder::exists($settings->mp3_path)){
			JError::raiseNotice( 100, 'Warning: '.str_replace  ('{PATH}',$settings->mp3_path,_msg_tracks11));
		}

		if(!JFolder::exists(JPATH_SITE.$settings->preview_path)){
			JError::raiseNotice( 100, 'Warning: '.str_replace  ('{PATH}',JPATH_SITE.$settings->preview_path,_msg_tracks11));
		}

		if($settings->mp3_path == ''){
			JError::raiseNotice( 100, 'Warning: '.str_replace  ('{PATH}',JPATH_SITE.$settings->mp3_path,_msg_tracks11));
		}
		if($settings->preview_path == ''){
			JError::raiseNotice( 100, 'Warning: '.str_replace  ('{PATH}',JPATH_SITE.$settings->preview_path,_msg_tracks11));
		}

		parent::display($tpl);
	}
}