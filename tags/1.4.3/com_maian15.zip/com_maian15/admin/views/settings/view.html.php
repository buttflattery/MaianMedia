<?php
/**
 * Settings View for Maian Music 1.3 Component
 * 
 * @package    Maian.Music
 * @subpackage Components
 * @link http://www.aretimes.com
 * @link http://www.maianscriptworld.com
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class MaianViewSettings extends JView
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		$settings =& $this->get('Data');
				
		JToolBarHelper::title(   JText::_(_msg_header3), 'cpanel.png' );
		JToolBarHelper::save();
		$this->assignRef('settings', $settings);

		parent::display($tpl);
	}
	
	
}