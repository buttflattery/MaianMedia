<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php

$document = &JFactory::getDocument();
$document->addScript( 'components/com_maian15/js/swfobject.js' );
$document->addScript( 'components/com_maian15/js/request.js' );
$document->addCustomTag('<script type="text/javascript">
  <!--
  function toggleLayer( whichLayer ){
	var toggle_object = document.getElementById("site_div")
    
	if (document.adminForm.append_url.checked){
          toggle_object.style.display = \'block\'; 
          display_url();
    }else{

          toggle_object.style.display = \'none\';
   }
  

}
  	
	function getPreviewPath(){
		var url = document.adminForm.site_url.value;
    	var preview = document.adminForm.preview_path.value;
		var txt=document.getElementById("site_div")
		
		txt.innerHTML=url+preview;
	
	}
	
	function display_url() {
    	getPreviewPath();
    	window.setTimeout("getPreviewPath()", 500);
   }
   
  -->
  </script>');

?>

<form action="index.php" method="post" name="adminForm">
<?php
$SETTINGS = $this->settings;

if ($SETTINGS->default_page == 0) {
        $popP = 'checked';
}
else if ($SETTINGS->default_page == 1) {
        $musicP = 'checked';
}

$radioBox = '<checked>';
$uri =& JURI::getInstance();
?>





<p><?php echo _msg_settings; ?></p>
<fieldset class="adminform">
        <legend><?php echo JText::_( _msg_settings2 ); ?></legend>
    <table class="admintable">
      <tr>
        <td width="100" align="right" class="key">
                <label for="greeting">
                                        <?php echo JText::_( _msg_settings41 ); ?>:
                        </label>    
                </td>
        <td align="left" style="padding:5px">
                <input type="radio" name="default_page" value="0" <?php echo $popP; ?>><?php echo JText::_(_msg_settings42); ?>
                <input type="radio" name="default_page" value="1"<?php echo $musicP; ?>><?php echo JText::_(_msg_settings43); ?>
                <?php echo toolTip(_msg_javascript,_msg_javascript39); ?>
        </td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings3); ?></td>
        <td align="left" style="padding:5px" width="70%"><input class="formBox" type="text" name="website_name" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->website_name); ?>"></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings4); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="email_address" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->email_address); ?>"></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings7); ?></td>
        <td align="left" style="padding:5px"><select name="language">
        <?php

        // Load language files..
        $lang = opendir(JPATH_COMPONENT_SITE.DS.'lang'.DS);

        while ($READ = readdir($lang))
        {
              if ($READ != "." && $READ != ".." && $READ != "index.html" && $READ != ".svn") {
                  echo '<option'.(($READ == $SETTINGS->language) ? ' selected' : '').'>'.substr($READ, 0, strpos($READ, '.')).'</option>'."\n";
          }
        }

        closedir($lang);
       
        ?>
        </select></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_frontpage_lang); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="select_lang" value="1"<?php echo ($SETTINGS->select_lang? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript_lang); ?></td>
    </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings26); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="rssfeeds" maxlength="3" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->rssfeeds); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript36); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings27); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="poplinks" maxlength="3" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->poplinks); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript37); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings46); ?></td>
        <td align="left" style="padding:5px"><input type="text" name="days" maxlength="3" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->days); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript41); ?></td>
    </tr>
    <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings47); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="ajax" value="1"<?php echo ($SETTINGS->ajax ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript40); ?></td>
    </tr>
    <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings8); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="enable_captcha" value="1"<?php echo ($SETTINGS->enable_captcha ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript3); ?></td>
    </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings48); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="search" value="1"<?php echo ($SETTINGS->search ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript44); ?></td>
    </tr>
    <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings52); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="show_nav" value="1"<?php echo ($SETTINGS->show_nav ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript45); ?></td>
    </tr>
    <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings53); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="enlargeit" value="1"<?php echo ($SETTINGS->enlargeit? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript46); ?></td>
    </tr>
    </table>
</fieldset>    
   
<fieldset class="adminform">  
        <legend><?php echo JText::_( _msg_settings38 ); ?></legend>
        <table class="admintable">
    <tr>

        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings39); ?></td>
               
        <td align="left" style="padding:5px">
        <select STYLE="width: 230px" id="player" name="player" onChange="ajaxRequest('flash_player', 'index.php?option=com_maian15&format=raw&&controller=settings&task=display_player&player_type='+this.value, 1);">
                <?php
       
                $key = 1;
                $skin = 0;
               
                while($key <=12) {
                       
                        if($key == 1){
                        $value = 'Premium Beat + Skin 1';
                        $skin = 1;
                }
               
                        if($key == 2){
                        $value = 'Premium Beat + Skin 2';
                        $skin = 2;
                }
               
                        if($key == 3){
                        $value = 'Premium Beat + Skin 3';
                        $skin = 3;
                }
               
                        if($key == 4){
                        $value = 'Premium Beat + Skin 4';
                        $skin = 4;
                }

                        if($key == 5){
                        $value = 'Premium Beat + Skin 5';
                        $skin = 5;
                }
               
                        if($key == 6){
                        $value = 'dewplayer + vol';
                }
               
                if($key == 7){
                        $value = 'dewplayer standard';
                }
               
                if($key == 8){
                        $value = 'dewplayer mini';
                }
               
                if($key == 9){
                        $value = 'simplemp3player';
                }
               
                if($key == 10){
                        $value = 'simplemp3player mini';
                }
               
                        if($key == 11){
                        $value = 'player_mp3';
                }
               
                        if($key == 12){
                        $value = 'mediaplayer';
                }
               
                echo '<option value="'.$key.'" style="padding-left:3px"'.($SETTINGS->player==$key ? ' selected' : '').'>'.$value.'</option>'."\n";
                       
                $key= $key + 1;
        }
        echo '</select> </td><td>';
        include_once(JPATH_COMPONENT_SITE.DS.'players'.DS.'mp3players.php');
        $key = 1;
        	echo '<div id="flash_player"><!-- Begin Flash Player -->'.mp3players::getplayer($SETTINGS->player, "test.mp3", $SETTINGS->player, 1).'<!-- End Flash Player --></div>';
        ?>        
       
        </td>
      </tr>
    </table>
</fieldset>

<fieldset class="adminform">
<legend><?php echo JText::_( _msg_settings9 ); ?></legend>  
      <table class="admintable">
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings6); ?></td>
        <td align="left" style="padding:5px" width="70%"><b><?php echo JPATH_ROOT; ?></b></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings10); ?></td>
        <td align="left" style="padding:5px" width="70%"><input class="formBox" type="text" name="mp3_path" maxlength="250" size="30" value="<?php echo JText::_($SETTINGS->mp3_path); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript4); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings11); ?></td>
        <td align="left" style="padding:5px">
        	<input class="formBox" type="text" onkeypress="display_url()" name="preview_path" maxlength="250" size="30" value="<?php echo JText::_($SETTINGS->preview_path); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript5); ?>
        	<?php echo JText::_(_msg_append); ?>
        	<input type="checkbox" onchange="toggleLayer('site_div')" name="append_url" " value="1"<?php echo ($SETTINGS->append_url ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript47); ?><div id="site_div"><?php echo ($SETTINGS->append_url ? substr($uri->root(), 0, strlen($uri->root())-1).$SETTINGS->preview_path : ''); ?></div>
        	<input type="hidden" name="site_url" value="<?php echo substr($uri->root(), 0, strlen($uri->root())-1);?>">
        </td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings25); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="page_expiry" maxlength="2" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->page_expiry); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript24); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings31); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="download_expiry" maxlength="2" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->download_expiry); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript30); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_lightbox); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="hide_lightbox" value="1" <?php echo ($SETTINGS->hide_lightbox ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_lightbox_javascript); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings51); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="show_download" value="1" <?php echo ($SETTINGS->show_download ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_download_javascript); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings30); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="reset" value="1"> <?php echo toolTip(_msg_javascript,_msg_javascript29); ?></td>
      </tr>
      </table>
</fieldset>

<fieldset class="adminform">
<legend><?php echo JText::_( _msg_settings14 ); ?></legend>
      <table class="admintable">
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings21); ?></td>
        <td align="left" style="padding:5px" width="70%"><select name="paypal_currency">
        <?php
        include(JPATH_COMPONENT.DS.'functions'.DS.'currencies.inc.php');
       
        foreach ($currencies AS $key => $value) {
          echo '<option value="'.$key.'" style="padding-left:3px"'.($SETTINGS->paypal_currency==$key ? ' selected' : '').'>'.$value.'</option>'."\n";
        }
        ?>
        </select> <?php echo toolTip(_msg_javascript,_msg_javascript11); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings20); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="paypal_email" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->paypal_email); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript8); ?> </td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings40); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="pdt" maxlength="250" size="90" value="<?php echo cleanData($SETTINGS->pdt); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript38); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings49); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="paypal_email2" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->paypal_email2); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript42); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings40); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="pdt2" maxlength="250" size="90" value="<?php echo cleanData($SETTINGS->pdt2); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript38); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings19); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="page_style" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->page_style); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript9); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings50); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="minpay" maxlength="2" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->minpay); ?>"> <?php echo toolTip(_msg_javascript,_msg_javascript43); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings16); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="paypal_mode" value="1"<?php echo ($SETTINGS->paypal_mode ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript7); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings18); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="log_errors" value="1"<?php echo ($SETTINGS->log_errors ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript10); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(_msg_settings28); ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="ssl_enabled" value="1"<?php echo ($SETTINGS->ssl_enabled ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript35); ?></td>
      </tr>
      </table>
</fieldset>


<fieldset class="adminform">
<legend><?php echo JText::_( _msg_settings33); ?></legend>
    <table class="admintable">
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(  _msg_settings34); ?>:</td>
        <td align="left" width="70%" style="padding:5px"><input type="checkbox" name="smtp" value="1"<?php echo ($SETTINGS->smtp ? ' checked' : ''); ?>> <?php echo toolTip(_msg_javascript,_msg_javascript32); ?></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(  _msg_settings35); ?>:</td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="smtp_host" size="20" value="<?php echo $SETTINGS->smtp_host; ?>"></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(  _msg_settings36); ?>:</td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="smtp_user" size="20" value="<?php echo $SETTINGS->smtp_user; ?>"></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_( _msg_settings37); ?>:</td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="smtp_pass" size="20" value="<?php echo $SETTINGS->smtp_pass; ?>"></td>
      </tr>
      <tr>
        <td width="100" align="right" class="key"><?php echo JText::_(  _msg_settings29); ?>:</td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="smtp_port" size="20" value="<?php echo $SETTINGS->smtp_port; ?>" style="width:10%"></td>
      </tr>
      </table>
</fieldset>

<input type="hidden" name="id" value="1" />
<input type="hidden" name="option" value="com_maian15" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="settings" />
 
</form>
