<?php
/**
 * Hello View for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewCategory extends JView
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		$categories =& $this->get('Data');
		
		if(JRequest::getVar('task') == 'edit'){
			$id= JRequest::getVar('cid');
			$db =& JFactory::getDBO();
        	$db->setQuery('SELECT * FROM #__categories where section = \'com_maian15\' and id=\''.$id[0].'\'');
			
			$categories = $db->loadObject();
		}
		
		
		
		if(JRequest::getVar('task') != 'edit' && JRequest::getVar('task') != 'add'){
			JToolBarHelper::title(JText::_(_msg_header10), 'cat.png' );
			JToolBarHelper::addNewX();
			JToolBarHelper::editListX();
			JToolBarHelper::deleteList();
		}
		$this->assignRef('categories', $categories);

		parent::display($tpl);
	}
}