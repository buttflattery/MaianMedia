<?php
/**
 * Hello View for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewMaian extends JView
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{
		//get the data
		//$settings =& $this->get('Data');
		
		JToolBarHelper::title(JText::_(_msg_public_header6), 'about.png');
		//JToolBarHelper::save();
		//JToolBarHelper::apply();
		
		// for existing items the button is renamed `close`
		//JToolBarHelper::cancel( 'cancel', 'Close' );

		//$this->assignRef('settings', $settings);
		include_once(JPATH_COMPONENT.DS.'views'.DS.'default'.DS.'tmpl'.DS.'about.php');
		//parent::display($tpl);
	}
}