<?php
defined('_JEXEC') or die('Restricted access');
require_once(JPATH_LIBRARIES.DS.'joomla'.DS.'factory.php');
include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');

include_once(JPATH_COMPONENT.DS.'tables'.DS.'album.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'paypal.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'tracks.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'settings.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'category.php');
include_once(JPATH_COMPONENT.DS.'tables'.DS.'purchases.php');

$db =& JFactory::getDBO();

$db->setQuery("SELECT * FROM #__mbak_settings");
$settings = $db->loadObject();

$db->setQuery("SELECT * FROM #__mbak_albums");
$albums = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__mbak_tracks");
$tracks = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__mbak_purchases");
$purchases = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__mbak_paypal");
$paypal = $db->loadObjectList();


$settingsTable =& JTable::getInstance('settings', 'Table');
$albumTable =& JTable::getInstance('album', 'Table');
$purchasesTable =& JTable::getInstance('purchases', 'Table');
$paypalTable =& JTable::getInstance('paypal', 'Table');
$tracksTable =& JTable::getInstance('tracks', 'Table');

$db->setQuery( "UPDATE #__m15_pages SET text = '".$settings->about."' WHERE id = '1'" );
$db->query();
	
$db->setQuery( "UPDATE #__m15_pages SET text = '".$settings->licence."' WHERE id = '2'" );
$db->query();
	
$db->setQuery( "UPDATE #__m15_pages SET text = '".$settings->music."' WHERE id = '3'" );
$db->query();
	
$db->setQuery( "UPDATE #__m15_pages SET text = '".$settings->freeText."' WHERE id = '4'" );
$db->query();


// Bind the form fields to the settings table
if (!$settingsTable->bind(parseObjectToArray($settings))) {
	echo JText::_(_msg_error_bind).' Settings<br>';
	$importError = 1;
}

// Make sure the settings record is valid
if (!$settingsTable->check()) {
	echo JText::_(_msg_error_check).' Settings<br>';
	$importError = 1;
}

// Store the web link table to the database
if (!$settingsTable->store()) {
	echo JText::_(_msg_error_store).' Settings<br>';
	$importError = 1;
}

foreach($purchases as $single){

	if (!$purchasesTable->bind($single)){
		echo JText::_(_msg_error_bind).' Purchases<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$purchasesTable->check()){
		echo JText::_(_msg_error_check).' Purchaces<br>';
		$importError = 1;
	}

	$purchasesTable->_tbl_key = 0;

	// Store the web link table to the database
	if (!$purchasesTable->store()){
		echo JText::_(_msg_error_store).' Purchaces<br>';
		$importError = 1;
	}

}


foreach($paypal as $single){

	if (!$paypalTable->bind($single)){
		echo JText::_(_msg_error_bind).' Paypal<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$paypalTable->check()){
		echo JText::_(_msg_error_check).' Paypal<br>';
		$importError = 1;
	}
	$paypalTable->_tbl_key = 0;
	// Store the web link table to the database
	if (!$paypalTable->store()){
		echo JText::_(_msg_error_store).' Paypal<br>';
		$importError = 1;
	}

}

foreach($albums as $album){

	if (!$albumTable->bind($album)){
		echo JText::_(_msg_error_bind).' Album<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$albumTable->check()){
		echo JText::_(_msg_error_check).' Album<br>';
		$importError = 1;
	}
	$albumTable->_tbl_key = 0;
	// Store the web link table to the database
	if (!$albumTable->store()){
		echo JText::_(_msg_error_store).' Album<br>';
		$importError = 1;
	}

}

foreach($tracks as $track){

	if (!$tracksTable->bind($track)){
		echo JText::_(_msg_error_bind).' Track<br>';
		$importError = 1;
	}
	$tracksTable->setTrackAdded(null);
	// Make sure the  record is valid
	if (!$tracksTable->check()){
		echo JText::_(_msg_error_check).' Track<br>';
		$importError = 1;
	}

	$tracksTable->_tbl_key = 0;

	// Store the web link table to the database
	if (!$tracksTable->store()){

		echo JText::_(_msg_error_store).' Track<br>';
		$importError = 1;
	}

}

if (isset($importError)){
	echo '<font style="color:red; margin-left:150px;"><b>There was a problem importing your backup tables</b></font>';
	$importError = 1;
}else{
	$db->setQuery("SELECT id FROM #__components WHERE name= 'Maian Music 1.3'");
	$com_id = $db->loadObject();
		
	$db->setQuery('UPDATE #__menu SET componentid = '.$com_id->id.' WHERE link LIKE \'%option=com_maian15%\' and type =\'component\'');
	$db->query();
		
	echo '<font style="color:green; margin-left:150px;"><b>Backup tables were detected and imported successfully</b></font>';
}
?>