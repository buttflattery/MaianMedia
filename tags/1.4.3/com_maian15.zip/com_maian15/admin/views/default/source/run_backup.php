<?php
defined('_JEXEC') or die('Restricted access');

require_once(JPATH_LIBRARIES.DS.'joomla'.DS.'factory.php');
include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');


include_once(JPATH_COMPONENT.DS.'tables'.DS.'backup.php');

$db =& JFactory::getDBO();

$db->setQuery("SELECT * FROM #__m15_settings");
$settings = $db->loadObject();

$db->setQuery("SELECT * FROM #__m15_albums");
$albums = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__m15_tracks");
$tracks = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__m15_purchases");
$purchases = $db->loadObjectList();

$db->setQuery("SELECT * FROM #__m15_paypal");
$paypal = $db->loadObjectList();


$db =& JFactory::getDBO();
$db->setQuery("DROP TABLE IF EXISTS  `#__mbak_albums`");
$db->query();

$db->setQuery("DROP TABLE IF EXISTS `#__mbak_paypal`");	
$db->query();

$db->setQuery("DROP TABLE IF EXISTS  `#__mbak_purchases`");
$db->query();

$db->setQuery("DROP TABLE IF EXISTS `#__mbak_settings`");
$db->query();

$db->setQuery("DROP TABLE IF EXISTS `#__mbak_tracks`");
$db->query();

$db->setQuery("
CREATE TABLE IF NOT EXISTS `#__mbak_settings` (
  `id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `website_name` varchar(250) NOT NULL DEFAULT '',
  `email_address` varchar(250) NOT NULL DEFAULT '',
  `homepage_url` varchar(250) NOT NULL DEFAULT '',
  `install_url` varchar(250) NOT NULL DEFAULT '',
  `language` varchar(250) NOT NULL DEFAULT '',
  `about` mediumtext NOT NULL,
  `licence` mediumtext NOT NULL,
  `music` mediumtext NOT NULL,
  `enable_captcha` enum('0','1') NOT NULL DEFAULT '0',
  `mod_rewrite` enum('0','1') NOT NULL DEFAULT '0',
  `mp3_path` varchar(250) NOT NULL DEFAULT '',
  `preview_path` varchar(250) NOT NULL DEFAULT '',
  `rssfeeds` int(3) NOT NULL DEFAULT '0',
  `poplinks` int(3) NOT NULL DEFAULT '10',
  `page_expiry` tinyint(2) NOT NULL DEFAULT '0',
  `download_expiry` tinyint(2) NOT NULL DEFAULT '0',
  `paypal_mode` enum('0','1') NOT NULL DEFAULT '0',
  `paypal_currency` char(3) NOT NULL DEFAULT 'GBP',
  `paypal_email` varchar(250) NOT NULL DEFAULT '',
  `page_style` varchar(250) NOT NULL DEFAULT '',
  `log_errors` enum('0','1') NOT NULL DEFAULT '0',
  `ssl_enabled` enum('0','1') NOT NULL DEFAULT '0',
  `smtp` enum('0','1') NOT NULL DEFAULT '0',
  `smtp_host` varchar(100) NOT NULL DEFAULT 'localhost',
  `smtp_user` varchar(100) NOT NULL DEFAULT '',
  `smtp_pass` varchar(100) NOT NULL DEFAULT '',
  `smtp_port` varchar(100) NOT NULL DEFAULT '25',
  `player` int(11) NOT NULL DEFAULT '1',
  `pdt` varchar(250) NOT NULL,
  `default_page` enum('0','1') NOT NULL DEFAULT '0',
  `days` int(3) NOT NULL DEFAULT '14',
  `paypal_email2` varchar(250) NOT NULL,
  `pdt2` varchar(250) NOT NULL,
  `minpay` varchar(250) NOT NULL,
  `freeText` mediumtext NOT NULL,
  `search` enum('0','1') NOT NULL DEFAULT '0',
  `ajax` enum('0','1') NOT NULL DEFAULT '0',
  `show_download` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8");
$db->query();

$db->setQuery("
CREATE TABLE IF NOT EXISTS `#__mbak_albums` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `artist` varchar(250) NOT NULL DEFAULT '',
  `name` varchar(250) NOT NULL DEFAULT '',
  `image` varchar(250) NOT NULL DEFAULT '',
  `dimensions_height` varchar(250) NOT NULL,
  `dimensions_width` varchar(250) NOT NULL,
  `artwork` varchar(250) NOT NULL DEFAULT '',
  `comments` mediumtext NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `addDate` date NOT NULL DEFAULT '0000-00-00',
  `keywords` mediumtext NOT NULL,
  `downloads` int(9) NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `rss_date` varchar(35) NOT NULL DEFAULT '',
  `child` int(5) NOT NULL DEFAULT '0',
  `parent` enum('0','1') NOT NULL DEFAULT '1',
  `discount` varchar(20) NOT NULL DEFAULT '0',
  `upc` varchar(250) NOT NULL,
  `RM` varchar(250) NOT NULL,
  `cat` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
$db->query();

$db->setQuery("
CREATE TABLE IF NOT EXISTS `#__mbak_paypal` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) NOT NULL DEFAULT '',
  `last_name` varchar(64) NOT NULL DEFAULT '',
  `pay_date` date NOT NULL DEFAULT '0000-00-00',
  `address` text NOT NULL,
  `email` varchar(127) NOT NULL DEFAULT '',
  `memo` text NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT '',
  `pending_reason` varchar(20) NOT NULL DEFAULT '',
  `total` varchar(10) NOT NULL DEFAULT '',
  `gross` varchar(10) NOT NULL DEFAULT '',
  `fee` varchar(10) NOT NULL DEFAULT '',
  `txn_id` varchar(17) NOT NULL DEFAULT '',
  `invoice` varchar(64) NOT NULL DEFAULT '',
  `visits` int(5) NOT NULL DEFAULT '0',
  `download_code` char(50) NOT NULL DEFAULT '',
  `cart_code` char(32) NOT NULL DEFAULT '',
  `purchases` text NOT NULL,
  `active_cart` enum('0','1') NOT NULL DEFAULT '0',
  `total_tracks` int(5) NOT NULL DEFAULT '0',
  `total_albums` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8");
$db->query();

$db->setQuery("
CREATE TABLE IF NOT EXISTS `#__mbak_purchases` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `cart_code` char(32) NOT NULL DEFAULT '',
  `item_id` varchar(50) NOT NULL DEFAULT '',
  `download_code` char(50) NOT NULL DEFAULT '',
  `downloads` int(5) NOT NULL DEFAULT '0',
  `track_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8");

$db->query();

$db->setQuery("
CREATE TABLE IF NOT EXISTS `#__mbak_tracks` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `track_name` varchar(250) NOT NULL DEFAULT '',
  `track_album` int(7) NOT NULL DEFAULT '0',
  `mp3_path` varchar(250) NOT NULL DEFAULT '',
  `preview_path` varchar(250) NOT NULL DEFAULT '',
  `track_length` varchar(50) NOT NULL DEFAULT '',
  `track_cost` varchar(5) NOT NULL DEFAULT '',
  `track_single` enum('0','1') NOT NULL DEFAULT '0',
  `addDate` date NOT NULL DEFAULT '0000-00-00',
  `track_order` int(9) NOT NULL DEFAULT '0',
  `downloads` int(9) NOT NULL DEFAULT '0',
  `free_downloads` int(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8");
$db->query();

$settingsTable =& JTable::getInstance('baksettings', 'Table');
$albumTable =& JTable::getInstance('bakalbum', 'Table');
$purchasesTable =& JTable::getInstance('bakpurchases', 'Table');
$paypalTable =& JTable::getInstance('bakpaypal', 'Table');
$tracksTable =& JTable::getInstance('baktracks', 'Table');

// Bind the form fields to the settings table
if (!$settingsTable->bind(parseObjectToArray($settings))) {
	echo JText::_(_msg_error_bind).' Settings<br>';
	$importError = 1;
}

// Make sure the settings record is valid
if (!$settingsTable->check()) {
	echo JText::_(_msg_error_check).' Settings<br>';
	$importError = 1;
}
$settingsTable->_tbl_key = 1;
// Store the web link table to the database
if (!$settingsTable->store()) {
	echo JText::_(_msg_error_store).' Settings<br>';
	$importError = 1;
}

foreach($purchases as $single){
	
	if (!$purchasesTable->bind($single)){
		echo JText::_(_msg_error_bind).' Purchases<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$purchasesTable->check()){
		echo JText::_(_msg_error_check).' Purchaces<br>';
		$importError = 1;
	}

	$purchasesTable->_tbl_key = 0;
	
	// Store the web link table to the database
	if (!$purchasesTable->store()){
		echo JText::_(_msg_error_store).' Purchaces<br>';
		$importError = 1;
	}

}


foreach($paypal as $single){

	if (!$paypalTable->bind($single)){
		echo JText::_(_msg_error_bind).' Paypal<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$paypalTable->check()){
		echo JText::_(_msg_error_check).' Paypal<br>';
		$importError = 1;
	}
	$paypalTable->_tbl_key = 0;
	// Store the web link table to the database
	if (!$paypalTable->store()){
		echo JText::_(_msg_error_store).' Paypal<br>';
		$importError = 1;
	}

}

foreach($albums as $album){

	if (!$albumTable->bind($album)){
		echo JText::_(_msg_error_bind).' Album<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$albumTable->check()){
		echo JText::_(_msg_error_check).' Album<br>';
		$importError = 1;
	}
	$albumTable->_tbl_key = 0;
	// Store the web link table to the database
	if (!$albumTable->store()){
		echo JText::_(_msg_error_store).' Album<br>';
		$importError = 1;
	}

}

foreach($tracks as $track){

	if (!$tracksTable->bind($track)){
		echo JText::_(_msg_error_bind).' Track<br>';
		$importError = 1;
	}

	// Make sure the  record is valid
	if (!$tracksTable->check()){
		echo JText::_(_msg_error_check).' Track<br>';
		$importError = 1;
	}
	
	$tracksTable->_tbl_key = 0;
	
	// Store the web link table to the database
	if (!$tracksTable->store()){

		echo JText::_(_msg_error_store).' Track<br>';
		$importError = 1;
	}

}

	if (isset($importError)){
		echo '<font style="color:red; margin-left:150px;"><b>'.JText::_(_msg_backup5).'</b></font>';
		$importError = 1;
	}else{
		echo '<font style="color:blue; margin-left:150px;"><b>'.JText::_(_msg_backup6).'</b></font>';
	}

?>
