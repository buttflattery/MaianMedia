<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

//Import filesystem libraries. Perhaps not necessary, but does not hurt
jimport('joomla.filesystem.file');

include_once(JPATH_COMPONENT.DS.'functions'.DS.'common.php');
//get temp path
$config =& JFactory::getConfig();
$config_tmp_path = rtrim($config->getValue('config.tmp_path'), '/');

//Set up destination of the extract
$dest = JPATH_COMPONENT_ADMINISTRATOR;
$adminDest = str_replace("\\","//",$dest);

$dest = JPATH_COMPONENT_SITE;
$siteDest = str_replace("\\","//",$dest);

$selected_files = JRequest::getVar('selected_files');

$fileArray = array();
$testArray = array();

foreach ($selected_files as $node){
	$temp_path = $config_tmp_path.DS.trim($node);
	$temp_path = str_replace("\\","//",$temp_path);
	if(is_dir($temp_path)){
		$fileArray = $fileArray+ process_dir($temp_path,true);
	}else{
		array_push($fileArray, array('dirpath' => $temp_path));
	}

}

foreach ($fileArray as $file) {
	//if (is_resource($file['handle'])) {
		$src = $file['dirpath'];
		
		$src = str_replace("\\","/",$src);
		$src = str_replace("//","/",$src);
		$src = $src.'/'.$file['filename'];
		if(!is_bool(strrpos($src,'admin'))){
			$search = str_replace("\\","/",$config_tmp_path.DS.'com_maian15'.DS.'admin'); 
			$search = str_replace("//","/",$search);
			$dest = str_replace($search, $adminDest, $src);
		}else if(!is_bool(strrpos($src,'component'))){
			$search = str_replace("\\","/",$config_tmp_path.DS.'com_maian15'.DS.'component');
			$search = str_replace("//","/",$search);
			$dest = str_replace($search, $siteDest, $src);
		}else{
			$search = str_replace("\\","//",$config_tmp_path.DS.'com_maian15'); 
			$search = str_replace("//","/",$search);
			$dest = str_replace($search, $adminDest, $src);
		}
		
		JFile::copy($src, $dest);
		JFile::delete($src);
		//$testArray = $testArray+array($src => $dest);
		
}



echo 'Update Complete.  Please close the window and refresh the page.';

?>