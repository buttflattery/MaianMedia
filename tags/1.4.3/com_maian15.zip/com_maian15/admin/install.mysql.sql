CREATE TABLE IF NOT EXISTS `#__m15_settings` (
  `id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `website_name` varchar(250) NOT NULL DEFAULT '',
  `email_address` varchar(250) NOT NULL DEFAULT '',
  `homepage_url` varchar(250) NOT NULL DEFAULT '',
  `install_url` varchar(250) NOT NULL DEFAULT '',
  `language` varchar(250) NOT NULL DEFAULT '',
  `about` mediumtext NOT NULL,
  `licence` mediumtext NOT NULL,
  `music` mediumtext NOT NULL,
  `enable_captcha` enum('0','1') NOT NULL DEFAULT '0',
  `mod_rewrite` enum('0','1') NOT NULL DEFAULT '0',
  `mp3_path` varchar(250) NOT NULL DEFAULT '',
  `preview_path` varchar(250) NOT NULL DEFAULT '',
  `rssfeeds` int(3) NOT NULL DEFAULT '0',
  `poplinks` int(3) NOT NULL DEFAULT '10',
  `page_expiry` tinyint(2) NOT NULL DEFAULT '0',
  `download_expiry` tinyint(2) NOT NULL DEFAULT '0',
  `paypal_mode` enum('0','1') NOT NULL DEFAULT '0',
  `paypal_currency` char(3) NOT NULL DEFAULT 'GBP',
  `paypal_email` varchar(250) NOT NULL DEFAULT '',
  `page_style` varchar(250) NOT NULL DEFAULT '',
  `log_errors` enum('0','1') NOT NULL DEFAULT '0',
  `ssl_enabled` enum('0','1') NOT NULL DEFAULT '0',
  `smtp` enum('0','1') NOT NULL DEFAULT '0',
  `smtp_host` varchar(100) NOT NULL DEFAULT 'localhost',
  `smtp_user` varchar(100) NOT NULL DEFAULT '',
  `smtp_pass` varchar(100) NOT NULL DEFAULT '',
  `smtp_port` varchar(100) NOT NULL DEFAULT '25',
  `player` int(11) NOT NULL DEFAULT '1',
  `pdt` varchar(250) NOT NULL,
  `default_page` enum('0','1') NOT NULL DEFAULT '0',
  `days` int(3) NOT NULL DEFAULT '14',
  `paypal_email2` varchar(250) NOT NULL,
  `pdt2` varchar(250) NOT NULL,
  `minpay` varchar(250) NOT NULL,
  `freeText` mediumtext NOT NULL,
  `search` enum('0','1') NOT NULL DEFAULT '0',
  `ajax` enum('0','1') NOT NULL DEFAULT '0',
  `append_url` enum('0','1') NOT NULL DEFAULT '0',
  `show_download` enum('0','1') NOT NULL DEFAULT '0',
  `show_nav` enum('0','1') NOT NULL DEFAULT '0',
  `enlargeit` enum('0','1') NOT NULL DEFAULT '0',
  `select_lang` enum('0','1') NOT NULL,
  `hide_lightbox` enum('0','1') NOT NULL,
  `master_count` int(11) NOT NULL,
  `extra_params` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


INSERT INTO `#__m15_settings` (`id`, `website_name`, `email_address`, `homepage_url`, `install_url`, `language`, `about`, `licence`, `music`, `enable_captcha`, `mod_rewrite`, `mp3_path`, `preview_path`, `rssfeeds`, `poplinks`, `page_expiry`, `download_expiry`, `paypal_mode`, `paypal_currency`, `paypal_email`, `page_style`, `log_errors`, `ssl_enabled`, `smtp`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `player`, `pdt`, `default_page`, `days`, `paypal_email2`, `pdt2`, `minpay`, `freeText`, `search`, `ajax`) VALUES
(1, 'Our Music Download Store', 'example@localhost.com', '', '', 'english.php', 'Thank you for your interest in our music. Use the links above to browse  our collection of albums. You can purchase single tracks or whole albums by using the buttons provided. You can also preview mp3 files before you buy.<br /> <br /> All payments are securely handled by Paypal and you don`t need a Paypal account to<br /> <div id="paypal_credit">  	<img src="/components/com_maian15/media/icons/credit-cards.gif" alt="All Major Credit Cards" width="500" height="45" /></div> 	', '', '', '1', '0', '//home//user//tracks', '//preview', 50, 5, 10, 10, '0', 'USD', 'example@localhost.com', 'test', '0', '0', '0', 'localhost', '', '', '25', 1, '', '1', 14, '', '', '10.00', '', '0', '1');


CREATE TABLE IF NOT EXISTS `#__m15_albums` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `artist` varchar(250) NOT NULL DEFAULT '',
  `label` varchar(250) NOT NULL DEFAULT '',
  `name` varchar(250) NOT NULL DEFAULT '',
  `image` varchar(250) NOT NULL DEFAULT '',
  `dimensions_height` varchar(250) NOT NULL,
  `dimensions_width` varchar(250) NOT NULL,
  `artwork` varchar(250) NOT NULL DEFAULT '',
  `comments` mediumtext NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `addDate` date NOT NULL DEFAULT '0000-00-00',
  `keywords` mediumtext NOT NULL,
  `downloads` int(9) NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `rss_date` varchar(35) NOT NULL DEFAULT '',
  `child` int(11) NOT NULL DEFAULT '0',
  `parent` enum('0','1') NOT NULL DEFAULT '1',
  `discount` varchar(20) NOT NULL DEFAULT '0',
  `upc` varchar(250) NOT NULL,
  `RM` varchar(250) NOT NULL,
  `cat` int(11) NOT NULL,
  `discount_type` enum('0','1') NOT NULL,
  `zip` varchar(250) NOT NULL,
  `params` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__m15_paypal` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `jos_id` int(11) NOT NULL,
  `first_name` varchar(64) NOT NULL DEFAULT '',
  `last_name` varchar(64) NOT NULL DEFAULT '',
  `pay_date` date NOT NULL DEFAULT '0000-00-00',
  `address` text NOT NULL,
  `email` varchar(127) NOT NULL DEFAULT '',
  `memo` text NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT '',
  `pending_reason` varchar(20) NOT NULL DEFAULT '',
  `total` varchar(10) NOT NULL DEFAULT '',
  `gross` varchar(10) NOT NULL DEFAULT '',
  `fee` varchar(10) NOT NULL DEFAULT '',
  `txn_id` varchar(17) NOT NULL DEFAULT '',
  `invoice` varchar(64) NOT NULL DEFAULT '',
  `visits` int(5) NOT NULL DEFAULT '0',
  `download_code` char(50) NOT NULL DEFAULT '',
  `cart_code` char(32) NOT NULL DEFAULT '',
  `purchases` text NOT NULL,
  `active_cart` enum('0','1') NOT NULL DEFAULT '0',
  `total_tracks` int(5) NOT NULL DEFAULT '0',
  `total_albums` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__m15_purchases` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `cart_code` char(32) NOT NULL DEFAULT '',
  `item_id` varchar(50) NOT NULL DEFAULT '',
  `download_code` char(50) NOT NULL DEFAULT '',
  `downloads` int(5) NOT NULL DEFAULT '0',
  `track_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__m15_tracks` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `track_name` varchar(250) NOT NULL DEFAULT '',
  `track_album` int(7) NOT NULL DEFAULT '0',
  `mp3_path` varchar(250) NOT NULL DEFAULT '',
  `preview_path` varchar(250) NOT NULL DEFAULT '',
  `track_length` varchar(50) NOT NULL DEFAULT '',
  `track_cost` varchar(5) NOT NULL DEFAULT '',
  `track_single` enum('0','1') NOT NULL DEFAULT '0',
  `addDate` date NOT NULL DEFAULT '0000-00-00',
  `track_order` int(9) NOT NULL DEFAULT '0',
  `downloads` int(9) NOT NULL DEFAULT '0',
  `free_downloads` int(9) NOT NULL,
  `freebie` enum('0','1') NOT NULL,
  `keywords` varchar(250) NOT NULL,
  `avatar` varchar(250) NOT NULL,
  `count` int(11) NOT NULL,
  `params` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__m15_pages` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `text` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jos_m15_pages`
--

INSERT INTO `#__m15_pages` (`id`, `name`, `text`) VALUES
(1, 'about', '<p>Thank you for your interest in our music. Use the links above to browse  our collection of albums. You can purchase single tracks or whole albums by using the buttons provided. You can also preview mp3 files before you buy.<br /> <br /> All payments are securely handled by Paypal and you don`t need a Paypal account to</p>\r\n<div id="paypal_credit"><img src="components/com_maian15/media/icons/credit-cards.gif" border="0" alt="All Major Credit Cards" width="500" height="45" /></div>'),
(2, 'license', '<p>All information and data contained within this music store are the property of [Your Music Store]., whether or not a copyright notice appears on the screen displaying this information. Users of the [Your Music Store] may save and use information contained therein only for personal use. No other use, including reproduction, retransmission, or editing, of [Your Music Store] information may be made without prior written permission of [Your Music Store]., which may be requested by contacting [Your Music Store].</p>'),
(3, 'music', '<p></p>'),
(4, 'free', '<p>Below is a list of tracks available for free download</p>');