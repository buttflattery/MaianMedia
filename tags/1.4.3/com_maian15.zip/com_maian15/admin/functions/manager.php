<?php

include('FileManager.php');

function endecrypt ($pwd, $data, $case='') {
	if ($case == 'de') {
		$data = urldecode($data);
	}

	$key[] = "";
	$box[] = "";
	$temp_swap = "";
	$pwd_length = 0;

	$pwd_length = strlen($pwd);

	for ($i = 0; $i <= 255; $i++) {
		$key[$i] = ord(substr($pwd, ($i % $pwd_length), 1));
		$box[$i] = $i;
	}

	$x = 0;

	for ($i = 0; $i <= 255; $i++) {
		$x = ($x + $box[$i] + $key[$i]) % 256;
		$temp_swap = $box[$i];

		$box[$i] = $box[$x];
		$box[$x] = $temp_swap;
	}

	$temp = "";
	$k = "";

	$cipherby = "";
	$cipher = "";

	$a = 0;
	$j = 0;

	for ($i = 0; $i < strlen($data); $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;

		$temp = $box[$a];
		$box[$a] = $box[$j];

		$box[$j] = $temp;

		$k = $box[(($box[$a] + $box[$j]) % 256)];
		$cipherby = ord(substr($data, $i, 1)) ^ $k;

		$cipher .= chr($cipherby);
	}

	if ($case == 'de') {
		$cipher = urldecode(urlencode($cipher));

	} else {
		$cipher = urlencode($cipher);
	}

	return $cipher;
}

function UploadIsAuthenticated($get){
	/*//debuging code since flash creates a new session
	foreach($_POST as $var => $value)
	{
		$postdata = $postdata.$var . ':' . $value.'<>';
	}

	foreach($_SERVER as $var => $value)
	{
		$flashcookie = $flashcookie.$var . ':' . $value.'<>';
	}

	foreach($_REQUEST as $var => $value)
	{
		$requestSession = $cookieSession.$var . ':' . $value.'<>';
	}*/

	foreach($_GET as $var => $value)
	{
		$getstring = $getstring.$var . ':' . $value.'<>';
	}

	$session = $_GET['sessionid'];
	$md5 = $_COOKIE[$sessionid];
	
	/*$myFile = "test.log";
	$fh = fopen($myFile, 'a') or die("can't open file");
	fwrite($fh, "---------------------------upload-----------------------\r\n");
	$stringData = "<event session id = ".$_GET['sessionid'].">\r\n";
	fwrite($fh, $stringData);
	$stringData = "<event session = ".$_GET['session'].">\r\n";
	fwrite($fh, $stringData);
	$stringData = "<event post = ".$postdata.">\r\n";
	fwrite($fh, $stringData);
	$stringData = "<event ".$_GET['event'].">: cookie<".$flashcookie.">\r\n";
	fwrite($fh, $stringData);
	$stringData = "<event ".$_GET['event'].">: request<".$requestSession.">\r\n";
	fwrite($fh, $stringData);
	$stringData = "<event post = ".$postdata.">\r\n";
	fwrite($fh, $stringData);
	$stringData = "<event ".$_GET['event'].">: get<".$getstring.">\r\n";
	fwrite($fh, $stringData);
	$stringData = "<event session= >: get<".$_SERVER['HTTP_COOKIE'].">\r\n";
	fwrite($fh, $stringData);
	fwrite($fh, "---------------------------upload------------------\r\n");
	fclose($fh);*/
	
	//manpulate encrypted string
	$sessionid = $_GET['sessionid'];
	$sessionid = str_replace('-per-','%',$sessionid);
	$sessionid = trim(str_replace('-dot-','.',$sessionid));

	$auth = file_get_contents('auth.php');

	$md5loc = strpos($auth, '$md5=');
	$md5 = trim(substr($auth,$md5loc+6, -2));

	$key = endecrypt($md5,$sessionid,'de');
	
	if(strrpos($getstring,$key)===false){
		return false;
	}else{
		if($_SERVER['HTTP_USER_AGENT'] == 'Shockwave Flash'){
			return true;
		}else{
			return false;
		}
	}

}

/*
//this hack sucks but flash destroys the admin session so I have to improvise
foreach($_POST as $var => $value)
{
	$postdata = $postdata.$var . ':' . $value.'<>';
}
foreach($_COOKIE as $var => $value)
{
	$flashcookie = $flashcookie.$var . ':' . $value.'<>';
}

foreach($_REQUEST as $var => $value)
{
	$requestSession = $cookieSession.$var . ':' . $value.'<>';
}

foreach($_GET as $var => $value)
{
	$getstring = $getstring.$var . ':' . $value.'<>';
}

$myFile = "test.log";
$fh = fopen($myFile, 'a') or die("can't open file");
fwrite($fh, "---------------------------main-----------------------\r\n");
$stringData = "<event ".$_GET['event'].">: cookie<".$flashcookie.">\r\n";
fwrite($fh, $stringData);
$stringData = "<event ".$_GET['event'].">: request<".$requestSession.">\r\n";
fwrite($fh, $stringData);
$stringData = "<event post = ".$postdata.">\r\n";
fwrite($fh, $stringData);
$stringData = "<event ".$_GET['event'].">: get<".$getstring.">\r\n";
fwrite($fh, $stringData);
$stringData = "<event session= >: get<".$_SERVER['HTTP_COOKIE'].">\r\n";
fwrite($fh, $stringData);
fwrite($fh, "---------------------------main-----------------------\r\n");
fclose($fh);*/

//manpulate encrypted string
$sessionid = $_GET['sessionid'];
$sessionid = str_replace('-per-','%',$sessionid);
$sessionid = trim(str_replace('-dot-','.',$sessionid));

$auth = file_get_contents('auth.php');

$md5loc = strpos($auth, '$md5=');
$md5 = trim(substr($auth,$md5loc+6, -2));

$key = endecrypt($md5,$sessionid,'de');

//prevent bastards from trying to exploit this file

if(strrpos($_SERVER['HTTP_COOKIE'],$key)===false){
	if(!isset($_POST['Upload'])){
		die();
	}
}


$browser = new FileManager(array(
	'directory' => $_GET['path'],
	'absolutePath' => $_GET['path'],
	'assetBasePath' => '../images/managerAssets',
	'upload' => true,
	'destroy' => false));

$browser->fireEvent(!empty($_GET['event']) ? $_GET['event'] : null);