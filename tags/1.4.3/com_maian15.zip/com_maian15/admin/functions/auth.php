<?php defined( '_JEXEC' ) or die( 'Restricted access' );
$md5='5860b80461a03ae011e5c9e867bf765b';