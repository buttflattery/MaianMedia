<?

/**
* @package		Joomla
* @subpackage	com_morfeoshow
* @copyright	Copyright (C) Vamba & Matthew Thomson. All rights reserved.
* @license		GNU/GPL.
* @author 		Vamba (.joomlaitalia.com) & Matthew Thomson (ignitejoomlaextensions.com)
* @based on  	com_ignitiongallery
* @author 		Matthew Thomson (ignitejoomlaextensions.com)
* Joomla! and com_morfeoshow are free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed they include or
* are derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

function com_uninstall() {

	echo '<p>Thank you for trying Maian Music for Joomla</p>';
	echo '<p>If you uninstalled this componet becuase of issues that you could not resolve <a src="http://www.aretimes.com/index.php?option=com_fireboard&Itemid=33">please contact</a> us so we can try and make it better in the future .</p>';
}

?>