<?php
/**
 * Hello World! Module Entry Point
 * 
 * @package    Joomla.Tutorials
 * @subpackage Modules
 * @link http://dev.joomla.org/component/option,com_jd-wiki/Itemid,31/id,tutorials:modules/
 * @license        GNU/GPL, see LICENSE.php
 * mod_helloworld is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$HOMEPAGE = JText::_(_msg_public_header3);
$ARTISTS = JText::_(_msg_public_header4);
$CONTACT = JText::_(_msg_public_header5);
$ABOUT = JText::_(_msg_public_header6);
$SEARCH =JText::_(_msg_public_header7);
$LICENCE = JText::_(_msg_public_header12);
$FREE = JText::_(_msg_free_download);

$H_URL = JRoute::_('index.php?option=com_maianmedia&view=mostpop&Itemid=0');
$A_URL = JRoute::_('index.php?option=com_maianmedia&view=music&Itemid=0');
$C_URL = JRoute::_('index.php?option=com_maianmedia&view=contact&Itemid=0');
$P_URL = JRoute::_('index.php?option=com_maianmedia&view=about&Itemid=0');
$L_URL = JRoute::_('index.php?option=com_maianmedia&view=licence&Itemid=0');
$F_URL = JRoute::_('index.php?option=com_maianmedia&view=freebie&Itemid=0');

// Include the syndicate functions only once
require( JModuleHelper::getLayoutPath( 'mod_maiansearch' ) );
?>
