<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); 
?>

<a id="mm_cart"	href="<?php echo JRoute::_('index.php?option=com_maianmedia&section=cart&view=viewcart')?>">
<img src="components/com_maianmedia/media/icons/shopping_cart.png" /> 
<?php echo JText::_(_msg_public_header2) ?>&nbsp;
<font id="cart_count"><?php echo $CART_COUNT ?></font>&nbsp;(<i id="cart_total"><?php echo $CART_TOTAL ?></i>)
</a>