<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: class_cart.inc.php
  Description: Shopping Cart Class

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

class mm_Cart extends genericOptions {

var $prefix;

// Adds items to cart..
function addToCart($full_album=false,$album,$track_id,$lang) {global $database;
  if ($full_album) {
    $database->setQuery("SELECT * FROM #__mm_albums 
                            WHERE id = '{$album}' 
                            LIMIT 1
                            ");
    $database->loadObject($ALBUM);
  } else {
    $database->setQuery("SELECT * FROM #__mm_tracks 
                            WHERE id = '{$track_id}' 
                            LIMIT 1
                            ");
    $database->loadObject($TRACK);
  }
  
  // Assign session vars if cart is empty..
  if (!isset($_SESSION['cart_count']) || (isset($_SESSION['cart_count']) && $_SESSION['cart_count']==0)) {
    // Clear vars if present..
    if (isset($_SESSION['cart_count'])) {
      $this->clearCart();
    }
    
    $_SESSION['cart_count']  = '0';
    $_SESSION['album_name']  = array();
    $_SESSION['album_id']    = array();
    $_SESSION['album_cost']  = array();
    $_SESSION['track_name']  = array();
    $_SESSION['track_id']    = array();
    $_SESSION['track_cost']  = array();
    $_SESSION['track_code']  = array();
  }
  
  // Add data to session vars..
  $_SESSION['cart_count']    = $_SESSION['cart_count']+1;
  $_SESSION['album_name'][]  = ($full_album ? $this->strip_slashes($ALBUM->artist.' - '.$ALBUM->name).($ALBUM->discount>0 ? ' (<b>'.str_replace("{discount}",$ALBUM->discount,$lang).'</b>)' : '') : '');
  $_SESSION['album_id'][]    = ($full_album ? $ALBUM->id : '0');
  $_SESSION['album_cost'][]  = ($full_album ? $this->getFullAlbumCost($ALBUM->id,$ALBUM->discount) : '0');
  $_SESSION['track_name'][]  = ($full_album ? '' : $this->strip_slashes($TRACK->track_name));
  $_SESSION['track_id'][]    = ($full_album ? '0' : $TRACK->id);
  $_SESSION['track_cost'][]  = ($full_album ? '0' : number_format($TRACK->track_cost,2));
  $_SESSION['entry_code'][]  = $this->random_data(50);
}

// Delete cart item..
function deleteCartItem($item) {	global $database;
  // Loop through cart...
  for ($i=0; $i<count($_SESSION['entry_code']); $i++) {
    if ($item==$_SESSION['entry_code'][$i]) {
      $_SESSION['album_name'][$i]  = '0';
      $_SESSION['album_id'][$i]    = '0';
      $_SESSION['album_cost'][$i]  = '0';
      $_SESSION['track_name'][$i]  = '0';
      $_SESSION['track_id'][$i]    = '0';
      $_SESSION['track_cost'][$i]  = '0';
      $_SESSION['entry_code'][$i]  = '0';
      
      $_SESSION['cart_count']      = $_SESSION['cart_count']-1;
    }
  }
  
  // If cart is now empty, clear vars..
  if ($_SESSION['cart_count']==0) {
    $this->clearCart();
  }
}

// Clears all cart items..
function clearCart() {	global $database;
  unset($_SESSION['cart_count']);
  unset($_SESSION['album_name']);
  unset($_SESSION['album_id']);
  unset($_SESSION['album_cost']);
  unset($_SESSION['track_name']);
  unset($_SESSION['track_id']);
  unset($_SESSION['track_cost']);
  unset($_SESSION['track_code']);
  unset($_SESSION['entry_code']);
  unset($_SESSION);
  session_unset();
  session_destroy();
}

// Gets cost of cart...
function cartTotal() {	global $database;
  $cost = '0.00';
  
  if (isset($_SESSION['cart_count']) && $_SESSION['cart_count']>0) {
    for ($i=0; $i<count($_SESSION['album_cost']); $i++) {
      if ($_SESSION['album_cost'][$i]>0 || $_SESSION['track_cost'][$i]>0) {
        $item = ($_SESSION['album_cost'][$i]>0 ? $_SESSION['album_cost'][$i] : $_SESSION['track_cost'][$i]);
        $cost = $cost+$item;
      }  
    }
  }
  
  return number_format($cost,2);
}

// Gets count of items in cart..
function cartCount() {	global $database;
  return (isset($_SESSION['cart_count']) ? $_SESSION['cart_count'] : '0');
}

// Get full album cost...totals up all tracks for an album..
function getFullAlbumCost($id,$discount) {	global $database;
  $database->setQuery("SELECT SUM(track_cost) AS t_cost 
                        FROM #__mm_tracks 
                        WHERE track_album = '{$id}' 
                        ");
  $database->loadObject($SUM); 
  
  if ($discount>0) {
    $discount_price = $SUM->t_cost * $discount / 100;
  }
                                              
  return ($discount>0 ? number_format($SUM->t_cost-$discount_price,2) : number_format($SUM->t_cost,2));                      
}

// Get cart data..
function getCartData($code) {	

  global $database;
  $database->setQuery("SELECT * FROM #__mm_paypal
                        WHERE cart_code = '{$code}'
                        ORDER BY id DESC 
                        LIMIT 1
                        ");
  $database->loadObject($query);
  
  return $query;                    
}

// Get track or album data..
function getTrackOrAlbumData($id,$type) {	global $database;
  $database->setQuery("SELECT * FROM ".$this->prefix.($type=='album' ? 'albums' : 'tracks')."
                        WHERE id = '{$id}'
                        LIMIT 1
                        ");
    $database->loadObject($query);                    
  return $query;                    
}

// Get download file..
function getDownloadFile($code) {	global $database;
  $database->setQuery("SELECT * FROM #__mm_purchases
                        WHERE download_code = '{$code}'
                        LIMIT 1
                        ");
  $database->loadObject($query);                    	 
  return $query;                    
}

// Get page download code for track..
function getDownloadPageCode($code) {	global $database;
  $query = $database->setQuery("SELECT * FROM #__mm_purchases
                        WHERE download_code = '{$code}'
                        LIMIT 1
                        ");
                        	$database->loadObject($code);   
   $database->setQuery("SELECT * FROM #__mm_purchases
                         WHERE item_id  = '{$code->item_id}'
                         AND cart_code  = '{$code->cart_code}'
                         AND track_id   = '0'
                         LIMIT 1
                         ");	 $database->loadObject($row); 
  
  return $row->download_code;
}

// Update file download count..
function updateFileDownloadCount($id,$type='') {	global $database;
  if ($type=='') {
    $database->setQuery("UPDATE #__mm_purchases SET
                 downloads  = (downloads+1)
                 WHERE id   = '{$id}'
                 LIMIT 1
                 ");	$database->query();
  } else {
    $database->setQuery("UPDATE #__mm_".($type=='album' ? 'albums' : 'tracks')." SET
                 downloads  = (downloads+1)
                 WHERE id   = '{$id}'
                 LIMIT 1
                 ");                                                 	$database->query();
  }
}

// Get download data..
function getDownloadData($code,$check=false) {	global $database;
  $database->setQuery("SELECT * FROM #__mm_paypal
                        WHERE download_code  = '{$code}'
                        AND active_cart      = '1'
                        LIMIT 1
                        ");
   $database->loadObject($query);                    
  if ($check) {
    return (count($query)>0 ? true : false);
  } else {
    return $query; 
  }                  
}

// Album downloads..
function albumDownloads($code,$check=false) {	global $database;
    $database->setQuery("SELECT * FROM #__mm_purchases
                        WHERE cart_code            = '{$code}'
                        AND SUBSTRING(item_id,1,1) = 'a'
                        ");
   $query = $database->loadObjectList();                     
  if ($check) {
    return (count($query)>0 ? true : false);
  } else {	$database->loadObject($single);
    return $single;  
  }                  
}

// Track downloads..
function trackDownloads($code,$check=false) {	global $database;
    $database->setQuery("SELECT * FROM #__mm_purchases
                        WHERE cart_code            = '{$code}'
                        AND SUBSTRING(item_id,1,1) = 't'
                        ");
    $query = $database->loadObjectList();                    
  if ($check) {
    return (count($query)>0 ? true : false);
  } else {	$database->loadObject($single);
    return $single;  
  }                  
}

// Fetch mp3 paths for zip file..
function getMP3PathForZipFile($id,$type,$array=false) {
  $album = array();	global $database;
  
  switch ($type) {
    case 'album':
    
    $database->setQuery("SELECT * FROM #__mm_tracks
                            WHERE track_album = '{$id}'
                            ORDER BY track_order
                            ");
    $q_album = $database->loadObjectList();
    	foreach($q_album as $ALBUM){
      $album[] = $ALBUM->mp3_path;
    }
    return $album;
    break;
    case 'track':
    $q_track = $database->setQuery("SELECT * FROM #__mm_tracks
                            WHERE id = '{$id}'
                            LIMIT 1
                            ");	$database->loadObject($TRACK); 
    return $TRACK->mp3_path;
    break;
  }
}

// Add cart data to database..
function addCartToDatabase($id, $total) {

global $database;
  
  if($total !='0.00'){
  $database->setQuery("INSERT INTO #__mm_paypal (
               pay_date,
               total,
               visits,
               download_code,
               cart_code,
               purchases,
               total_tracks,
               total_albums
               ) VALUES (
               '".date("Y-m-d")."',
               '".$total."',
               '0',
               '".$this->random_data(50)."',
               '{$id}',
               '".(!empty($_SESSION['album_id']) ? implode(",",$_SESSION['album_id']) : '0')."||".(!empty($_SESSION['track_id']) ? implode(",",$_SESSION['track_id']) : '0')."',
               '".$this->returnArrayCount($_SESSION['track_id'])."',
               '".$this->returnArrayCount($_SESSION['album_id'])."'
               )");
               	$database->query();
   }//end if
}

// Returns count of items in each array that are greater than 0..
// ie: 0,1,2,0 = 2
function returnArrayCount($array) {
  $count = 0;
  for ($i=0; $i<count($array); $i++) {
    if ($array[$i]>0) {
      $count++;
    }
  }
  return $count;
}

// Generate cart purchases for download..
// We only need do this if the transation was valid..
function generatePurchasesForDownload($cart) {	
global $database;
  // Database information for purchases..
  $data = $this->getCartData($cart);
  // Explode purchases field..then explode again for album and track data..
  $field   = explode("||", $data->purchases);
  $albums  = explode(",", $field[0]);
  $tracks  = explode(",", $field[1]);
  // Add album data..
  for ($i=0; $i<count($albums); $i++) {
    if ($albums[$i]!='0') {
      $random = $this->random_data(50);
      $database->setQuery("INSERT INTO #__mm_purchases (
                   cart_code,
                   item_id,
                   download_code,
                   downloads,
                   track_id
                   ) VALUES (
                   '{$cart}',
                   'a".$albums[$i]."',
                   '{$random}',
                   '0',
                   '0'
                   )");
      $database->query();  
      // Update download/purchase count for album..
      $this->updateFileDownloadCount($album[$i],'albums');                   
      // Add download information for each track in album..
     $database->setQuery("SELECT * FROM #__mm_tracks
                               WHERE track_album = '{$albums[$i]}'
                               ORDER BY track_order
                               ");	  $q_tracks = $database->loadObjectList();
      		foreach($q_tracks as $TRACKS){
        $database->setQuery("INSERT INTO #__mm_purchases (
                     cart_code,
                     item_id,
                     download_code,
                     downloads,
                     track_id
                     ) VALUES (
                     '{$cart}',
                     'a".$albums[$i]."',
                     '".$this->random_data(50)."',
                     '0',
                     '{$TRACKS->id}'
                     )");	$database->query();
                     
        // Update download/purchase count for track..
        $this->updateFileDownloadCount($TRACKS->id,'tracks');              
      }             
    }
  }
  
  // Add track data..
  for ($i=0; $i<count($tracks); $i++) {
    if ($tracks[$i]!='0') {
      $database->setQuery("INSERT INTO #__mm_purchases (
                   cart_code,
                   item_id,
                   download_code,
                   downloads,
                   track_id
                   ) VALUES (
                   '{$cart}',
                   't".$tracks[$i]."',
                   '".$this->random_data(50)."',
                   '0',
                   '0'
                   )");
    $database->query();               
      // Update download/purchase count for track..
      $this->updateFileDownloadCount($tracks[$i],'tracks');              
    }
  }
}

// Update download page visits..
function updateDownloadPageVisits($code) {	global $database;
  $database->setQuery("UPDATE #__mm_paypal SET 
               visits               = (visits+1) 
               WHERE download_code  = '{$code}'
               LIMIT 1
               ");
}

// Update item downloads..
function updateItemDownloadCount($code) {	global $database;
  $database->setQuery("UPDATE #__mm_purchases SET 
               downloads            = (downloads+1) 
               WHERE download_code  = '{$code}'
               LIMIT 1
               ");	$database->query();
}

// Get purchased albums/tracks and return as string for e-mail..
function purchasedItems($type,$code,$lang) {	global $database;
  $string = '';
  $count  = 0;
  
  $database->setQuery("SELECT * FROM #__mm_purchases 
                        WHERE cart_code            = '{$code}'
                        AND SUBSTRING(item_id,1,1) = '".($type=='albums' ? 'a' : 't')."'
                        ".($type=='albums' ? 'AND track_id = \'0\'' : '')."
                        ");
  $query =  $database->loadObjectList();
  switch($type) {
    case 'albums':
    if (count($query)>0) {
      foreach($query as $DATA ) {
        $database->setQuery("SELECT * FROM #__mm_albums 
                                WHERE id = '".substr($DATA->item_id,1)."'
                                LIMIT 1");
        $database->loadObject($ALBUM);
        $string .= '['.++$count.'] '.$this->strip_slashes($ALBUM->name).' - '.$this->strip_slashes($ALBUM->artist).$this->define_newline();
      }
    } else {
      $string = 'N/A';
    }
    
    break;
    
    case 'tracks':
    
    if (count($query)>0) {		foreach($query as $DATA){
        $q_track = $database->setQuery("SELECT * FROM #__mm_tracks 
                                WHERE id = '".substr($DATA->item_id,1)."'
                                LIMIT 1");
        $database->loadObject($TRACK);
        $q_album = $database->setQuery("SELECT * FROM #__mm_albums 
                                WHERE id = '{$TRACK->track_album}'
                                LIMIT 1");
        $database->loadObject($ALBUM);
        
        $string .= '['.++$count.'] '.$this->strip_slashes($TRACK->track_name).$this->define_newline();
        $string .= $lang.' '.$this->strip_slashes($ALBUM->name).' - '.$this->strip_slashes($ALBUM->artist).$this->define_newline().$this->define_newline();
      }
    } else {
      $string = 'N/A';
    }
    
    break;
  }
  
  return trim($string);
}

// Update database after valid paypal response..
function updateCartDatabase($cart,$DATA, $code) {	
global $database;
  // Prepare data for safe import..
  $DATA     = $this->safe_import_callback($DATA);
  $address  = '';
  // Address data..
  if ($DATA['address_street']) {
    $address = $DATA['address_street'].$this->define_newline().$DATA['address_city'].$this->define_newline().$DATA['address_state'].$this->define_newline().$DATA['address_zip'].$this->define_newline().$DATA['address_country'];
  }
  // Update..
  $database->setQuery("UPDATE #__mm_paypal SET
               first_name       = '{$DATA['first_name']}',
               last_name        = '{$DATA['last_name']}',
               address          = '{$address}',
               email            = '{$DATA['payer_email']}',
               memo             = '".(isset($DATA['memo']) ? $DATA['memo'] : '')."',
               payment_status   = '{$DATA['payment_status']}',
               pending_reason   = '".(isset($DATA['pending_reason']) ? $DATA['pending_reason'] : '')."',
               gross            = '{$DATA['mc_gross']}',
               fee              = '{$DATA['mc_fee']}',
               txn_id           = '{$DATA['txn_id']}',
               invoice          = '{$DATA['invoice']}',
               active_cart      = '1'
               WHERE cart_code  = '{$cart}' and download_code = '{$code}'
               LIMIT 1
               ");	
               $database->query();
}

// Get download size of album or track...
function downloadSize($id,$type,$settings=array()) {	global $database;
  $bytes = 0;
  
  switch ($type) {
    case 'track':
    $database->setQuery("SELECT * FROM #__mm_tracks 
                            WHERE id = '{$id}'
                            LIMIT 1");
    $database->loadObject($TRACK);
    if (file_exists($settings->mp3_path.'/'.$TRACK->mp3_path)) {
      $bytes = filesize($settings->mp3_path.'/'.$TRACK->mp3_path);
    }
    
    break;
    
    case 'album':
    
    $database->setQuery("SELECT * FROM #__mm_tracks 
                            WHERE track_album = '{$id}'
                            ");
    $q_track = $database->loadObjectList();	foreach($q_track as $TRACK){
      if (file_exists($settings->mp3_path.'/'.$TRACK->mp3_path)) {
        $bytes = $bytes+filesize($settings->mp3_path.'/'.$TRACK->mp3_path);
      }
    }
    
    break;
  }
  
  return $bytes;
}

// Reset downloads..
function resetCartDownloads($code) {	global $database;
  	$database->setQuery("UPDATE #__mm_purchases SET 
               downloads        = '0' 
               WHERE cart_code  = '{$code}'
               ") ;	
    $database->query();           
  	$database->setQuery("UPDATE #__mm_paypal SET 
               visits           = '0' 
               WHERE cart_code  = '{$code}'
               ");
    $database->query();              
}
function checkForDuplicates($code, $download){
	global $database;
	
	$database->setQuery("Select * from #__mm_paypal WHERE cart_code  = '{$code}' AND download_code = '{$download}'");
	$results = $database->loadObjectList();
	
	if(count($result) != 0){
		$bool = false;
	}else{
		$bool = true;
	}
	
	return $bool;
	
}
// Force download of mp3 file..
function forceDownload($archiveName,$msg) {
  // This can apparently fix some IE problems..
  if(ini_get('zlib.output_compression')) {
    ini_set('zlib.output_compression', 'Off');
  }
  
  if (!file_exists($archiveName)) {
    echo $msg;
    exit;
  }

  header("Pragma: public");
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Cache-Control: private",false);
	header("Content-Type: ".$this->get_mime_type());
	header("Content-Disposition: attachment; filename=".basename($archiveName).";" );
	header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".filesize($archiveName));
	readfile($archiveName);
}

}

?>