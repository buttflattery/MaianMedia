<?php



// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

/**
* @package Joomla
* @subpackage Maian Music
*/
class HTML_maiainFront {
	
	function show_MainPage($tplDisplayHome){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
 	  	include_once(FOLDER_PATH.'templates/home.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_MusicPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/music.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_ContactPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/contact.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_LicencePage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/licence.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_AboutPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/about.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_SearchPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/search.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_AlbumPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/album.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_CartPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/cart.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_CheckoutPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/paypal/checkout.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_ThanksPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/paypal/thanks.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	
	function show_CancelPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/paypal/cancel.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_InvalidPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/paypal/error.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_ErrorPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/paypal/error.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_DownloadPage($tplDisplayData){
		  
		include_once(FOLDER_PATH.'inc/header.php');
		include_once(FOLDER_PATH.'templates/header.tpl.php');
  		include_once(FOLDER_PATH.'templates/paypal/download.tpl.php');
  		include_once(FOLDER_PATH.'inc/footer.php');
  		include_once(FOLDER_PATH.'templates/footer.tpl.php');
	}
	
	function show_ItemPage($tplDisplayData){
  		
		include_once(FOLDER_PATH.'templates/download_item.tpl.php');
	}
	
	function show_RSS($rss_feed){
  		
		echo (get_magic_quotes_gpc() ? stripslashes(trim($rss_feed)) : trim($rss_feed));
		exit;
	}
	
}
?>