<?php

// -----------------------------------------------
// Cryptographp v1.4
// (c) 2006-2007 Sylvain BRISON 
//
// http://www.captcha.fr
// cryptographp@alphpa.com 
//
// Licence CeCILL modifi�e
// => Voir fichier Licence_CeCILL_V2-fr.txt)
//
// Modified by David Ian Bennett for Maian Music
// -----------------------------------------------

 if(session_id() == "") session_start();
 
 $_SESSION['cryptdir']= dirname($cryptinstall);
 
 
 function dsp_crypt($cfg=0,$reload=1) {	global $mosConfig_live_site;
   $string = "<a title='".($reload==1 ? '' : $reload)."' style=\"cursor:pointer\" onclick=\"javascript:document.images.cryptogram.src='".$mosConfig_live_site."/components/com_maianmusic/".$_SESSION['cryptdir']."/cryptographp.php?cfg=".$cfg."&amp;".SID."&amp;'+Math.round(Math.random(0)*1000)+1\"><img class='captcha_border' id='cryptogram' src='".$mosConfig_live_site."/components/com_maianmusic/".$_SESSION['cryptdir']."/cryptographp.php?cfg=".$cfg."&amp;".SID."' alt='' title='' /></a>";
   return $string;
 }


 function chk_crypt($code) {
 // V�rifie si le code est correct
 if (isset($_SESSION['configfile']) && file_exists($_SESSION['configfile'])) {
   include ($_SESSION['configfile']);
 }
 $code = addslashes ($code);
 $code = str_replace(' ','',$code);  // supprime les espaces saisis par erreur.
 $code = (isset($difuplow) ? $code : strtoupper($code));
 $code = md5($code);
 if ($_SESSION['cryptcode'] and ($_SESSION['cryptcode'] == $code))
    {
    unset($_SESSION['cryptreload']);
    if ($cryptoneuse) unset($_SESSION['cryptcode']);    
    return true;
    }
    else {
         $_SESSION['cryptreload']= true;
         return false;
         }
 }

?>
