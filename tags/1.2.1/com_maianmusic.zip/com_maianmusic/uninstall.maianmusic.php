<?

// no direct access

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

function com_uninstall() {

	echo '<p>Thank you for trying Maian Music for Joomla</p>';
	echo '<p>If you uninstalled this componet becuase of issues that you could not resolve <a src="http://www.aretimes.com/index.php?option=com_fireboard&Itemid=33">please contact</a> us so we can try and make it better in the future .</p>';
}

?>