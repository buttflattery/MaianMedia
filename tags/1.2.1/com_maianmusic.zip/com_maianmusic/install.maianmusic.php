<?php

// no direct access

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

function com_install() {
	global $mosConfig_live_site, $mosConfig_absolute_path, $mosConfig_lang, $database;

	$database->setQuery( "SELECT id FROM #__components WHERE name= 'Maian Music'" );
	$id = $database->loadResult();
	
	//remove admin menu images

	$database->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmusic/images/aremaian.png' WHERE id = '$id'" );
	$database->query();
	
	//add new admin menu images

	$database->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmusic/images/controlpanel.png' WHERE parent='$id' AND name = 'Settings'");
	$database->query();

	$database->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmusic/images/media.png' WHERE parent='$id' AND name = 'Manage Albums'");
	$database->query();

	$database->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmusic/images/add_section.png' WHERE parent='$id' AND name = 'Add New Tracks'");
	$database->query();

	$database->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmusic/images/edit.png' WHERE parent='$id' AND name = 'Manage Tracks'");
	$database->query();
	
	$database->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmusic/images/license.png' WHERE parent='$id' AND name = 'Sales'");
	$database->query();

	$database->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmusic/images/search_text.png' WHERE parent='$id' AND name = 'Search Sales'");
	$database->query();

	$database->setQuery( "UPDATE #__components SET admin_menu_img = '../components/com_maianmusic/images/statistics.png' WHERE parent='$id' AND name = 'Statistics'");
	$database->query();
	
	//Load Basic Settings
	
	$database->setQuery("INSERT INTO #__mm_settings (id, website_name, email_address, homepage_url, install_url, language, about, licence, music, enable_captcha, mod_rewrite, mp3_path, preview_path, rssfeeds, poplinks, page_expiry, download_expiry, paypal_mode, paypal_currency, paypal_email, page_style, log_errors, ssl_enabled, smtp, smtp_host, smtp_user, smtp_pass, smtp_port, player, pdt, default_page) VALUES
		(1, '', '', '', '', 'english.php', 'Thank you for your interest in our music. Use the music link in the left hand menu to browse  our collection of albums. You can purchase single tracks or whole albums by using the buttons provided. You can also preview mp3 files before you buy.<br /> <br /> All payments are securely handled by Paypal and you don`t need a Paypal account to  <div id=\"paypal_credit\">  	<img src=\"components/com_maianmusic/images/credit-cards.gif\" alt=\"All Major Credit Cards Accepted via Paypal\" title=\"All Major Credit Cards Accepted via Paypal\" /><br />     All Major Credit Cards Accepted via Paypal</div>', '', '<h2 class=\"title\">Music </h2> 			Please click the links to view more information about an album and to preview/purchase tracks. Thank you.', '1', '0', '', '', 50, 10, 10, 10, '0', 'USD', '', '', '0', '0', '0', 'localhost', '', '', '25', 1, '', '0')");
	$database->query();
	
	echo '<div id="maian_content"><img src="components/com_maianmusic/admin_images/logo.gif"></img><br>';
	echo '<p>To use this system you muct have a paypal bussiness account<br>';
	echo 'Log in to your Paypal account and click "Profile" from the "My Account" menu tab.<br><br>';
	echo '<b>Click "Selling Preferences --> "Instant Payment Notification Preferences"</b><br>';
	echo '<p>On the next screen, click "Edit" and check the box to enable the IPN system and in the "Notification URL" box, enter the full URL to your notification page.<br><br>';
	echo '<b>'.$mosConfig_live_site.'/index.php?option=com_maianmusic&section=notify</b><br><br>';
	echo 'From the "Profile" tab, select "Selling Preferences" --> "Website Payment Preferences" the URL for the auto return function is as follows:<br><br>';
	echo '<b>'.$mosConfig_live_site.'/index.php?option=com_maianmusic&section=thanks</b><br><br>';
	echo 'Be sure to turn on "Auto Return" and "Payment Data Transfer".  Copy your pin for use in the application</p></div>';

}

?> 