<?php
/*++++++++++++++++++++++++++++++++++++++++

Script: Maian Music v1.2
Written by: David Ian Bennett
E-Mail: support@maianscriptworld.co.uk
Website: http://www.maianscriptworld.co.uk

++++++++++++++++++++++++++++++++++++++++

This File: class_music.inc.php
Description: Music Class

++++++++++++++++++++++++++++++++++++++++*/

class musicDB extends genericOptions{
	var $prefix;

	// Add album..
	function add_album($DATA)
	{
		global $database;
		// Prepare array data for safe importing..
		$DATA = $this->safe_import_callback($DATA);

		$database->setQuery("INSERT INTO #__mm_albums (
		artist,
		name,
		image,
		artwork,
		comments,
		status,
		addDate,
		keywords,
		rss_date,
		parent,
		child,
		discount
		) VALUES (
		'{$DATA['artist']}',
		'{$DATA['name']}',
		'{$DATA['image']}',
		'{$DATA['artwork']}',
		'{$DATA['comments']}',
		'".(isset($DATA['status']) ? $DATA['status'] : 0)."',
               '".date("Y-m-d")."',
		'{$DATA['keywords']}',
		'".date('D, j M Y H:i:s')." GMT',
               '".(ctype_digit($DATA['cat']) ? '0' : '1')."',
               '".(ctype_digit($DATA['cat']) ? $DATA['cat'] : '0')."',
		'{$DATA['discount']}'
		)");
		$database->query();
	}



	// Edit album..

	function edit_album($DATA)

	{
		global $database;
		// Prepare array data for safe importing..

		$DATA = $this->safe_import_callback($DATA);

		$database->setQuery("UPDATE #__mm_albums SET

		artist    = '{$DATA['artist']}',

		name      = '{$DATA['name']}',

		image     = '{$DATA['image']}',

		artwork   = '{$DATA['artwork']}',

		comments  = '{$DATA['comments']}',

		status    = '".(isset($DATA['status']) ? $DATA['status'] : 0)."',

		keywords  = '{$DATA['keywords']}',

		rss_date  = '".date('D, j M Y H:i:s')." GMT',

		hits      = '{$DATA['hits']}',

		parent    = '".(ctype_digit($DATA['cat']) ? '0' : '1')."',

        child     = '".(ctype_digit($DATA['cat']) ? $DATA['cat'] : '0')."',

		discount  = '{$DATA['discount']}'

		WHERE id  = '{$_POST['id']}'

		LIMIT 1

               ");
		$database->query();
	}



	// Clear album and tracks..

	function clear_data($id)

	{
		global $database;
		$database->setQuery("DELETE FROM #__mm_albums WHERE id = '{$id}' LIMIT 1");
		$database->query();
		$database->setQuery("DELETE FROM #__mm_tracks WHERE track_album = '{$id}'");
		$database->query();
	}



	// Add tracks..

	function add_tracks($DATA)

	{

		$run = 0;
		global $database;


		for ($i=0; $i<count($_POST['track_name']); $i++)

		{

			// Only add track if name, path & cost were specified..

			if ($_POST['track_name'][$i] && $_POST['mp3_path'][$i] && $_POST['track_cost'][$i])

			{

				// Get last order by number...

				$database->setQuery("SELECT track_order FROM #__mm_tracks

				WHERE track_album = '{$_POST['track_album'][$i]}'

				ORDER BY track_order DESC

				LIMIT 1");
				
				$database->loadObject($ORDER);

				$database->setQuery("INSERT INTO #__mm_tracks (

                    track_name,

                    track_album,

                    mp3_path,

                    preview_path,

                    track_length,

                    track_cost,

                    track_single,

                    addDate,

                    track_order

                    ) VALUES (

                    '".$this->add_slashes($_POST['track_name'][$i])."',

                    '".$_POST['track_album'][$i]."',

                    '".$this->add_slashes($_POST['mp3_path'][$i])."',

                    '".$this->add_slashes($_POST['preview_path'][$i])."',

                    '".$this->add_slashes($_POST['track_length'][$i])."',

                    '".number_format($_POST['track_cost'][$i],2)."',

                    '".(isset($_POST['track_single_'.$i]) ? 1 : 0)."',

                    '".date("Y-m-d")."',

                    '".($ORDER->track_order+1)."'

                    )");

				$database->query();

				$run++;

			}

		}



		return $run;

	}



	// Update track..

	function update_track($DATA)

	{
		global $database;
		// Prepare array data for safe importing..

		$DATA = $this->safe_import_callback($DATA);



		$database->setQuery("UPDATE #__mm_tracks SET

               track_name    = '".($DATA['track_name'] ? $DATA['track_name'] : $DATA['t_name'])."',

		track_album   = '{$DATA['track_album']}',

		mp3_path      = '".($DATA['mp3_path'] ? $DATA['mp3_path'] : $DATA['t_path'])."',

		preview_path  = '{$DATA['preview_path']}',

		track_length  = '{$DATA['track_length']}',

		track_cost    = '".number_format(($DATA['track_cost'] ? $DATA['track_cost'] : $DATA['t_cost']),2)."',

               track_single  = '".(isset($DATA['track_single']) ? 1 : 0)."'

		WHERE id      = '{$DATA['edit']}'

		LIMIT 1

               ");
		$database->query();
	}



	// Change order..

	function change_order($direction,$track,$album)

	{
		global $database;
		// Explode track id..

		$split = explode("-",$track);



		// Get count of tracks for this album..

		$q_count = $database->setQuery("SELECT count(*) AS t_count FROM #__mm_tracks

		WHERE track_album = '{$album}'

                          ");
		$database->loadObject($COUNT);

		switch ($direction) {

			case 'up':

				$pos  = ($split[1]=='1' ? $COUNT->t_count : ($split[1]-1));

				break;



			case 'down':

				$pos  = ($split[1]==$COUNT->t_count ? '1' : ($split[1]+1));

				break;

		}



		// Get id of track in the position track is being moved to..

		$database->setQuery("SELECT * FROM #__mm_tracks

		WHERE track_album  = '{$album}'

		AND track_order    = '{$pos}'

		LIMIT 1");
		$database->loadObject($ID);

		// Update positions..

		$database->setQuery("UPDATE #__mm_tracks SET track_order = '$pos'

		WHERE id         = '{$split[0]}'

		AND track_album  = '{$album}'

		LIMIT 1

               ");
		$database->query();
		 

		$database->setQuery("UPDATE #__mm_tracks SET track_order = '{$split[1]}'

		WHERE id         = '{$ID->id}'

		AND track_album  = '{$album}'

		LIMIT 1

               ");

		$database->query();

	}



	// Rebuilds the order index..

	function rebuild_order_index($DATA)	{

		$count = 0;
		global $database;


		if ($DATA['track_album']==$_POST['id']) {

			return;

		} else {

			// Update previous album index..

			$database->setQuery("SELECT * FROM #__mm_tracks

			WHERE track_album = '{$DATA['id']}'

			ORDER BY track_order

                              ");

			$q_current = $database->loadObjectList();

			foreach ($q_current as $CURRENT) {
			//while ($CURRENT = mysql_fetch_object($q_current))

				$count = ($count+1);

				$database->setQuery("UPDATE #__mm_tracks SET track_order = '{$count}'

				WHERE id = '{$CURRENT->id}'

				LIMIT 1

                   ");
				$database->query();
			}



			// Reset count..

			$count = 0;



			// Update new album index..

			 $database->setQuery("SELECT * FROM #__mm_tracks

			WHERE track_album = '{$DATA['track_album']}'

			ORDER BY track_order

                          ");
			$q_new = $database->loadObjectList();

			foreach ($q_new as $NEW) {
			//while ($NEW = mysql_fetch_object($q_new))

				$count = ($count+1);

				$database->setQuery("UPDATE #__mm_tracks SET track_order = '{$count}'

				WHERE id = '{$NEW->id}'

				LIMIT 1

                   ");
				$database->query();
			}

		}

	}



	// Rebuilds the order index if track deleted..

	function rebuild_order_index_delete($id)
	{

		$count = 0;
		global $database;

		// Update previous album index..

		$database->setQuery("SELECT * FROM #__mm_tracks
		WHERE track_album = '{$id}'
		ORDER BY track_order");

		$q_album = $database->loadObjectList();

		foreach ($q_album as $ALBUM) {
		//while ($ALBUM = mysql_fetch_object($q_album))

			$count = ($count+1);

			$database->setQuery("UPDATE #__mm_tracks SET track_order = '{$count}'

			WHERE id = '{$ALBUM->id}'

			LIMIT 1

                 ");
			$database->query();
		}

	}

	// Clear track..
	function clear_track($id){
		global $database;
		$database->setQuery("DELETE FROM #__mm_tracks WHERE id = '{$id}' LIMIT 1");
		$database->query();
	}



	// Reset download count - all albums..

	function resetAlbumDownloadCount(){
		global $database;
		$database->setQuery("UPDATE #__mm_albums SET downloads = '0'");
		$database->query();
	}

	// Reset download count - all tracks..

	function resetTrackDownloadCount(){
		global $database;
		$database->setQuery("UPDATE #__mm_tracks SET downloads = '0'");
		$database->query();
	}



	// Reset download count - all tracks in album..

	function resetTracksDownloadCountInAlbum($id){
		global $database;
		$database->setQuery("UPDATE #__mm_tracks SET downloads = '0' WHERE track_album = '{$id}'");
		$database->query();
	}
}


?>