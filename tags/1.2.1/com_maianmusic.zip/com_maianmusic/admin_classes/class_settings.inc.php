<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: class_settings.inc.php
  Description: Settings Class

  ++++++++++++++++++++++++++++++++++++++++*/

class settings extends genericOptions {
var $prefix;

// Update settings..
function update($DATA)
{  
  // Prepare array data for safe importing..  
  global $database;
  //$otherdata = $DATA;
  $DATA = $this->safe_import_callback($DATA);
  
  $queryString = "UPDATE #__mm_settings SET 
  website_name     = '{$DATA['website_name']}',
  email_address    = '{$DATA['email_address']}',
  homepage_url     = '{$DATA['homepage_url']}',
  install_url      = '{$DATA['install_url']}',
  language         = '{$DATA['language']}',
               about            = '{$DATA['about']}',
               music            = '{$DATA['music']}',
               licence          = '{$DATA['licence']}',
               enable_captcha   = '".(isset($DATA['enable_captcha']) ? 1 : 0)."',
               mp3_path         = '{$DATA['mp3_path']}',
               pdt              = '{$DATA['pdt']}',
               player           = '{$DATA['player']}',
			   default_page     = '{$DATA['default_page']}',
               preview_path     = '{$DATA['preview_path']}',
               rssfeeds         = '{$DATA['rssfeeds']}',
               poplinks         = '{$DATA['poplinks']}',
               page_expiry      = '{$DATA['page_expiry']}',
               download_expiry  = '{$DATA['download_expiry']}',
               paypal_mode      = '".(isset($DATA['paypal_mode']) ? 1 : 0)."',
               paypal_currency  = '{$DATA['paypal_currency']}',
               paypal_email     = '{$DATA['paypal_email']}',
               page_style       = '{$DATA['page_style']}',
               log_errors       = '".(isset($DATA['log_errors']) ? 1 : 0)."',
               ssl_enabled      = '".(isset($DATA['ssl_enabled']) ? 1 : 0)."',
               smtp             = '".(isset($DATA['smtp']) ? 1 : 0)."', 
               smtp_host        = '{$DATA['smtp_host']}',
               smtp_user        = '{$DATA['smtp_user']}',
               smtp_pass        = '{$DATA['smtp_pass']}',
               smtp_port        = '{$DATA['smtp_port']}'
               LIMIT 1";
  
  echo $queryString;
  $database->setQuery($queryString);
  $database->query();
}

// Reset all album hits..
function resetAllAlbumHits()
{  

  global $database;
  $database->setQuery("UPDATE #__mm_albums SET hits = '0'");  
  $database->query();
}

}

?>