<?php
/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: class_sales.inc.php
  Description: Sales Class

  ++++++++++++++++++++++++++++++++++++++++*/

class sales extends genericOptions {

var $prefix;

// Delete sale..
function deleteSale($id,$code)
{	global $database;
  $database->setQuery("DELETE FROM #__mm_paypal WHERE id = '{$id}' LIMIT 1") ;	$database->query();  
  $database->setQuery("DELETE FROM #__mm_purchases WHERE cart_code = '{$code}'") ;	$database->query();  
}

// Reset purchase counts..
function resetPurchaseCounts($code)
{
	global $database;
  $database->setQuery("SELECT * FROM #__mm_paypal 
                        WHERE cart_code = '{$code}'
                        LIMIT 1
                        ") ;
   $database->loadObject($row);
  
  // Split purchases...
  $field   = explode("||", $row->purchases);
  $albums  = explode(",", $field[0]);
  $tracks  = explode(",", $field[1]);
  // Reset albums..
  for ($i=0; $i<count($albums); $i++) {
    if ($albums[$i]>0) {
      $database->setQuery("UPDATE #__mm_albums SET 
                   downloads = (downloads-1)
                   WHERE id = '{$albums[$i]}'
                   LIMIT 1
                   ") ;	$database->query();
    }
  }
  
  // Reset tracks..
  for ($i=0; $i<count($tracks); $i++) {
    if ($tracks[$i]>0) {
      $database->setQuery("UPDATE #__mm_tracks SET 
                   downloads = (downloads-1)
                   WHERE id = '{$tracks[$i]}'
                   LIMIT 1
                   ") ;	$database->query();
    }
  }
}

}

?>
