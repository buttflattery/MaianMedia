<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: view_tracks.php
  Description: View/Update Tracks

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }
global $database, 
$msg_viewtracks2,	
$msg_viewtracks3,		
$msg_add12,	
$msg_add11,	
$msg_add10,	
$msg_viewtracks6,	
$msg_viewtracks7,	
$msg_viewtracks4,	
$msg_viewtracks5,	
$msg_viewtracks8,	
$msg_viewtracks9,		
$msg_javascript,		
$msg_viewtracks,	
$msg_javascript20,	
$msg_javascript21,	
$msg_script8,	
$msg_add6,	
$msg_add7,	
$msg_javascript17,		
$msg_javascript16,	
$msg_javascript19,		
$msg_javascript18,	
$msg_add8,	
$msg_add9;
$database->setQuery("SELECT * FROM #__mm_albums 
                        WHERE id = '{$_GET['id']}' LIMIT 1") ;
$database->loadObject($ALBUM);
//$ALBUM = mysql_fetch_object($q_album);

?>
  <div id="main">
		<p><b><?php echo $msg_viewtracks; ?></b> &raquo;<br><br>
    <?php echo $msg_viewtracks2; ?></p>
    <?php
    if (isset($_SESSION['updated']))
    {
    ?>
    <table width="100%" cellspacing="0" cellpadding="0" style="background-color:#D9EEF4;border:1px dashed #40ACC7">
    <tr>
      <td align="left" style="padding:5px;color:#000000" width="85%"><?php echo $msg_viewtracks8; ?><br><br>[ <a href="index2.php?option=com_maianmusic&section=view_tracks&amp;id=<?php echo $_GET['id']; ?>" title="<?php echo $msg_viewtracks9; ?>"><?php echo $msg_viewtracks9; ?></a> ]</td>
      <td align="center" width="15%"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/ok.gif" title="" alt=""></td>
    </tr>
    </table><br>
    <?php
    unset($_SESSION['updated']);
    }
    ?>
    <p style="text-align:center">- <b><?php echo cleanData($ALBUM->artist).' - '.cleanData($ALBUM->name); ?></b> -</p>
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_viewtracks; ?> (<?php echo rowCount('tracks',' WHERE track_album = \''.$_GET['id'].'\''); ?>)</td>
    </tr>
    <?php
    
    $database->setQuery("SELECT * FROM #__mm_tracks 
                             WHERE track_album = '".$_GET['id']."'
                             ORDER BY track_order
                             ") ;
    $q_tracks = $database->loadObjectList();
    if (count($q_tracks)>0)
    {
    ?>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <?php 
            $count = 0;
      		foreach ($q_tracks as $TRACKS){
      ?>
      <table width="100%" cellspacing="0" cellpadding="0" style="border-bottom:1px solid #D9EEF4;border-left:1px solid #D9EEF4;margin-bottom:3px">
      <tr>
        <td class="formOption" width="60%" style="padding:10px 5px 10px 5px">[<?php echo ++$count; ?>] - <b><?php echo cleanData($TRACKS->track_name); ?></b></td>
        <td align="center" width="20%"><a href="index2.php?option=com_maianmusic&section=view_tracks&amp;id=<?php echo $_GET['id']; ?>&amp;up=<?php echo $TRACKS->id; ?>-<?php echo $TRACKS->track_order; ?>"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/move_up.gif" alt="<?php echo $msg_viewtracks4; ?>" title="<?php echo $msg_viewtracks4; ?>" border="0"></a> <a href="index2.php?option=com_maianmusic&section=view_tracks&amp;id=<?php echo $_GET['id']; ?>&amp;down=<?php echo $TRACKS->id; ?>-<?php echo $TRACKS->track_order; ?>"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/move_down.gif" alt="<?php echo $msg_viewtracks5; ?>" title="<?php echo $msg_viewtracks5; ?>" border="0"></a></td>
        <td align="right" width="20%"><a href="javascript:toggle_box('edit_track_<?php echo $TRACKS->id; ?>')"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/edit.gif" alt="<?php echo $msg_viewtracks3; ?>" title="<?php echo $msg_viewtracks3; ?>" border="0"></a> <a href="#" onclick="submit_confirm('<?php echo $msg_javascript21; ?>','index2.php?option=com_maianmusic&section=view_tracks&amp;id=<?php echo $_GET['id']; ?>&amp;del=<?php echo $TRACKS->id; ?>');return false"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/delete.gif" alt="<?php echo $msg_script8; ?>" title="<?php echo $msg_script8; ?>" border="0"></a></td>
      </tr>
      </table>
      <form method="post" action="index2.php?option=com_maianmusic&section=view_tracks">
      <input type="hidden" name="edit" value="<?php echo $TRACKS->id; ?>">
      <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
      <input type="hidden" name="t_path" value="<?php echo $TRACKS->mp3_path; ?>">
      <input type="hidden" name="t_name" value="<?php echo cleanData($TRACKS->track_name); ?>">
      <input type="hidden" name="t_cost" value="<?php echo $TRACKS->track_cost; ?>">
      <div id="edit_track_<?php echo $TRACKS->id; ?>" style="margin-bottom:3px;display:none">
      <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #000000">
      <tr>
        <td align="left" style="padding:5px;">
        <table width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td class="formOption" width="30%"><?php echo $msg_add6; ?></td>
          <td align="left" style="padding:5px" width="70%"><input class="formBox" type="text" name="track_name" maxlength="250" size="30" value="<?php echo cleanData($TRACKS->track_name); ?>"></td>
        </tr>
        <tr>
          <td class="formOption"><?php echo $msg_add7; ?></td>
          <td align="left" style="padding:5px"><select name="track_album">
          <?php
        
           $database->setQuery("SELECT * FROM #__mm_albums 
                                   ORDER BY name
                                   ");		$q_albums = $database->loadObjectList();
                  foreach ($q_albums as $ALBUMS){
            echo '<option value="'.$ALBUMS->id.'"'.($_GET['id']==$ALBUMS->id ? ' selected' : '').'>'.cleanData($ALBUMS->artist).' - '.cleanData($ALBUMS->name).'</option>'."\n";
          }
        
          ?>
          </select></td>
        </tr>
        <tr>
          <td class="formOption"><?php echo $msg_add8; ?></td>
          <td align="left" style="padding:5px"><input class="formBox" type="text" name="mp3_path" maxlength="250" size="30" value="<?php echo cleanData($TRACKS->mp3_path); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript16); ?></td>
        </tr>
        <tr>
          <td class="formOption"><?php echo $msg_add9; ?></td>
          <td align="left" style="padding:5px"><input class="formBox" type="text" name="preview_path" maxlength="250" size="30" value="<?php echo cleanData($TRACKS->preview_path); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript17); ?></td>
        </tr>
        <tr>
          <td colspan="2">
          <table width="100%" cellspacing="0" cellpadding="0" style="background-color:#D9EEF4;border:1px dashed #40ABC6">
          <tr>
            <td align="left" style="padding:5px;font-weight:bold" width="20%"><?php echo $msg_add10; ?>:</td>
            <td align="left" style="padding:5px" width="20%"><input class="formBox" type="text" name="track_length" maxlength="50" size="30" value="<?php echo cleanData($TRACKS->track_length); ?>" style="width:70%"> <?php echo toolTip($msg_javascript,$msg_javascript18); ?></td>
            <td align="right" style="padding:5px;font-weight:bold" width="10%"><?php echo $msg_add11; ?>:</td>
            <td align="left" style="padding:5px" width="20%"><input class="formBox" type="text" name="track_cost" maxlength="5" size="30" value="<?php echo cleanData($TRACKS->track_cost); ?>" style="width:50%"> <?php echo toolTip($msg_javascript,$msg_javascript19); ?></td>
            <td align="right" style="padding:5px;font-weight:bold" width="20%"><?php echo $msg_add12; ?>:</td>
            <td align="left" style="padding:5px" width="10%"><input type="checkbox" name="track_single" value="1"<?php echo ($TRACKS->track_single ? ' checked' : ''); ?>> <?php echo toolTip($msg_javascript,$msg_javascript20); ?></td>
          </tr>
          </table>
          </td>      
        </tr>
        </table>
        </td>
      </tr>
      <tr>
        <td align="center" style="padding:5px" colspan="2"><input class="formButton" type="submit" value="<?php echo $msg_viewtracks3; ?>" title="<?php echo $msg_viewtracks3; ?>"></td>
      </tr>
      </table>
      </div>
      </form>
      <?php
      }
      ?>
      </td>
    </tr>
    <?php
    } else {
    ?>  
    <tr>
      <td align="center" style="padding:10px 0 10px 0;border-top:1px solid #40ABC6"><?php echo $msg_viewtracks6; ?></td>
    </tr>
    <?php
    }
    ?>
    </table><br>
    <table width="100%" cellspacing="1" cellpadding="0">
    <tr>
        <td align="center" style="padding:5px"><input class="formButton" type="button" name="add" value="<?php echo $msg_viewtracks7; ?>" title="<?php echo $msg_viewtracks7; ?>" onclick="window.location='index2.php?option=com_maianmusic&section=tracks'"></td>
    </tr>
    </table>
	</div>

