<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: statistics.php
  Description: Graphical Statistics

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }

include(FOLDER_PATH.'admin_classes/graphs.inc.php');
global $database, 
$msg_statistics,
$msg_statistics11,
$msg_statistics10,
$sql,
$limit,
$msg_statistics6,
$msg_statistics7,
$msg_statistics4,	
$msg_statistics5,
$msg_statistics2,
$msg_statistics3,
$page,
$limitvalue,
$msg_header11,	
$msg_statistics8,
$msg_albums9,
$msg_statistics9;
?>
  <div id="main">
		<p><b><?php echo $msg_header11; ?></b> &raquo;<br><br>
    <?php echo $msg_statistics; ?></p>
    <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td align="left"><a href="index2.php?option=com_maianmusic&section=stats&amp;expand=1<?php echo (isset($_GET['order']) ? '&amp;order='.$_GET['order'] : ''); ?>" title="<?php echo $msg_statistics10; ?>"><?php echo $msg_statistics10; ?></a> | <a href="index2.php?option=com_maianmusic&section=stats&amp;close=1<?php echo (isset($_GET['order']) ? '&amp;order='.$_GET['order'] : ''); ?>" title="<?php echo $msg_statistics11; ?>"><?php echo $msg_statistics11; ?></a></td>
      <td align="right"><b><?php echo $msg_statistics2; ?></b>: 
       <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
       <option style="padding-left:3px" value="0">---</option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=stats&amp;order=hits_desc"<?php echo (isset($_GET['order']) && $_GET['order']=='hits_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_statistics3; ?></option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=stats&amp;order=hits_asc"<?php echo (isset($_GET['order']) && $_GET['order']=='hits_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_statistics4; ?></option>
       </select>
      </td>
    </tr>
    </table><br>
    <?php
    
    $database->setQuery("SELECT * FROM #__mm_albums 
                             ".(isset($sql) ? $sql : 'ORDER BY artist,name')."
                             LIMIT $limitvalue,$limit
                             ") ;
    $q_albums = $database->loadObjectList();                         
    if (count($q_albums)>0)
    {
      		foreach($q_albums as $ALBUMS){
        $database->setQuery("SELECT count(*) AS a_count FROM #__purchases
                                    WHERE item_id = 'a".$ALBUMS->id."'
                                    AND track_id  = '0'
                                    ") ;
        $database->loadObject($PURCHASES);
      ?>
      <table width="100%" cellspacing="0" cellpadding="0" style="border:1px solid #D9EEF4;margin-bottom:3px">
      <tr>
        <td align="left" style="padding:5px" width="90%">
        <b><?php echo cleanData($ALBUMS->artist); ?> - <?php echo cleanData($ALBUMS->name); ?></b><br><br>
        <span style="color:#FF7700">

        <?php 
                  if($PURCHASES->a_count == null){
                       $purchasesCount = 0;
                  }else{
        		$purchasesCount = number_format($PURCHASES->a_count);
        	  }
        		echo str_replace(array('{hits}','{albums}','{tracks}'),
                               array(number_format($ALBUMS->hits),
                                     $purchasesCount,
                                     number_format(getTrackPurchasesForAlbum($ALBUMS->id))
                                     ),
                                     $msg_statistics7); ?></span>
        </td>
        <td align="center" width="10%"><a href="javascript:toggle_box('show_track_<?php echo $ALBUMS->id; ?>')"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/track_stats.gif" alt="<?php echo $msg_statistics8; ?>" title="<?php echo $msg_statistics8; ?>" border="0" /></a></td>
      </tr>
      </table>
      <div id="show_track_<?php echo $ALBUMS->id; ?>" style="border:1px solid #40ACC7;margin-bottom:3px;padding:10px;<?php echo (isset($_SESSION['expand_stats']) ? '' : 'display:none'); ?>">
      <?php
      echo $msg_statistics9.'<br><br>';
      
      // Show graph..
      $graph                    = new BAR_GRAPH('hBar');
      $graph->values            = getTrackDataForGraph($ALBUMS->id);
      $graph->labels            = getTrackDataForGraph($ALBUMS->id,true);
      $graph->legend            = $msg_statistics6.','.$msg_statistics5;
      $graph->showValues        = 1;
      $graph->percValuesColor   = '#40ACC7';
      $graph->labelColor        = '#40ACC7';
      $graph->labelBGColor      = '#FFFFFF';
      $graph->labelBorder       = '1px solid #40ACC7';
      $graph->absValuesColor    = '#40ACC7';
      $graph->absValuesBGColor  = '#D9EEF4';
      $graph->absValuesBorder   = '1px dashed #40ACC7';
      $graph->barBorder         = '1px solid #40ACC7';
      $graph->barColors         = $mainframe->getCfg('live_site').'/components/com_maianmusic/images/menuTable_bg.gif,'.$mainframe->getCfg('live_site').'/components/com_maianmusic/images/menuTable2_bg.gif';
      echo $graph->create();
      unset($graph);
      
      ?>
      </div>
      <?php
      }
      
      // Page numbers..
      echo admin_page_numbers(rowCount('albums'),$limit,$page);
      ?>
      <br>
      <div style="text-align:center;font-size:11px">
       Graphs created using <a href="http://www.gerd-tentler.de/tools/phpgraphs/main.php" target="_blank" title="HTML Graph">HTML Graph</a>. &copy; Gerd Tentler
      </div>
      <?php      
    }
    else
    {
      echo $msg_albums9;
    }                         
    
    ?>
	</div>