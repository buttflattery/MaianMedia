<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: add.php
  Description: Add Tracks

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }
global $msg_add13,
$ALBUMS,
$msg_add12,
$msg_add,
$msg_add11,
$msg_add10,
$msg_add15,
$msg_add14,
$run,
$q_albums,
$msg_add2,
$msg_javascript,
$msg_add3,
$msg_javascript20,
$msg_add6,
$msg_add7,
$msg_add4,
$msg_javascript17,
$msg_javascript16,
$msg_add5,
$msg_javascript19,
$msg_javascript18,
$msg_add8,
$msg_add9,
$database,
$count;	
?>
  <div id="main">
		<p><b><?php echo $msg_header5; ?></b> &raquo;<br><br>
    <?php echo $msg_add; ?></p>
    <?php
    if (isset($DONE))
    {
    ?>
    <table width="100%" cellspacing="0" cellpadding="0" style="background-color:#D9EEF4;border:1px dashed #40ACC7">
    <tr>
      <td align="left" style="padding:5px;color:#000000" width="85%"><?php echo str_replace("{count}",$run,$msg_add13); ?></td>
      <td align="center" width="15%"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/admin_images/ok.gif" title="" alt=""></td>
    </tr>
    </table><br>
    <?php
    $count = 0;
    }
    ?>
    <form method="post" action="index2.php?option=com_maianmusic&section=add">
    <input type="hidden" name="process" value="1">
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_add2; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <?php echo $msg_add3; ?><br><br>
      <select name="total" onchange="form.submit()">
      <option value="0">---</option>
      <?php
      for ($i=1; $i<ADD_TRACKS_TOTAL+1; $i++)
      {
        echo '<option style="padding-left:3px"'.($count==$i ? ' selected' : '').'>'.$i.'</option>'."\n";
      }
      ?>
      </select>
      </td>
    </tr>
    </table><br>
    <?php
    if ($count>0)
    {
      ?>
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center"><?php echo $msg_add14; ?> <select name="album" onchange="form.submit()">
        <option value="0">---</option>
        <?php
        
        $database->setQuery("SELECT * FROM #__mm_albums 
                                 ORDER BY artist");		$q_albums = $database->loadObjectList();
        		foreach ($q_albums as $ALBUMS){
        //while ($ALBUMS = mysql_fetch_object($q_albums))
          echo '<option value="'.$ALBUMS->id.'"'.(isset($_POST['album']) && $_POST['album']==$ALBUMS->id ? ' selected' : '').'>'.cleanData($ALBUMS->artist).' - '.cleanData($ALBUMS->name).'</option>'."\n";
        }
        
        ?>
        </select> <?php echo $msg_add15; ?></td>
      </tr>
      </table><br>
      <?php
      for ($i=0; $i<$count; $i++)
      {
    ?>
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_add4; ?>: <?php echo ($i+1); ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td class="formOption" width="30%"><?php echo $msg_add6; ?></td>
        <td align="left" style="padding:5px" width="70%"><input class="formBox" type="text" name="track_name[]" maxlength="250" size="30" value="<?php echo (isset($_POST['track_name'][$i]) ? cleanData($_POST['track_name'][$i]) : ''); ?>"></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_add7; ?></td>
        <td align="left" style="padding:5px"><select name="track_album[]">
        <?php
        
        $database->setQuery("SELECT * FROM #__mm_albums 
                                 ORDER BY artist") ;
        $q_albums = $database->loadObjectList();
        
		foreach ($q_albums as $ALBUMS){
          echo '<option value="'.$ALBUMS->id.'"'.(isset($_POST['album']) && $_POST['album']>0 && $_POST['album']==$ALBUMS->id ? ' selected' : (isset($_POST['album']) && $_POST['album']==0 && isset($_POST['track_album'][$i]) && $_POST['track_album'][$i]==$ALBUMS->id ? ' selected' : '')).'>'.cleanData($ALBUMS->artist).' - '.cleanData($ALBUMS->name).'</option>'."\n";
        }
        ?>
        </select></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_add8; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="mp3_path[]" maxlength="250" size="30" value="<?php echo (isset($_POST['mp3_path'][$i]) ? cleanData($_POST['mp3_path'][$i]) : ''); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript16); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_add9; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="preview_path[]" maxlength="250" size="30" value="<?php echo (isset($_POST['preview_path'][$i]) ? cleanData($_POST['preview_path'][$i]) : ''); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript17); ?></td>
      </tr>
      <tr>
        <td colspan="2">
        <table width="100%" cellspacing="0" cellpadding="0" style="background-color:#D9EEF4;border:1px dashed #40ABC6">
        <tr>
          <td align="left" style="padding:5px;font-weight:bold" width="20%"><?php echo $msg_add10; ?>:</td>
          <td align="left" style="padding:5px" width="20%"><input class="formBox" type="text" name="track_length[]" maxlength="50" size="30" value="<?php echo (isset($_POST['track_length'][$i]) ? cleanData($_POST['track_length'][$i]) : ''); ?>" style="width:70%"> <?php echo toolTip($msg_javascript,$msg_javascript18); ?></td>
          <td align="right" style="padding:5px;font-weight:bold" width="10%"><?php echo $msg_add11; ?>:</td>
          <td align="left" style="padding:5px" width="20%"><input class="formBox" type="text" name="track_cost[]" maxlength="5" size="30" value="<?php echo (isset($_POST['track_cost'][$i]) ? cleanData($_POST['track_cost'][$i]) : ''); ?>" style="width:50%"> <?php echo toolTip($msg_javascript,$msg_javascript19); ?></td>
          <td align="right" style="padding:5px;font-weight:bold" width="20%"><?php echo $msg_add12; ?>:</td>
          <td align="left" style="padding:5px" width="10%"><input type="checkbox" name="track_single_<?php echo $i; ?>" value="1"<?php echo (isset($_POST['track_single_'.$i]) ? ' checked' : ''); ?>> <?php echo toolTip($msg_javascript,$msg_javascript20); ?></td>
        </tr>
        </table>
        </td>      
      </tr>
      </table>
      </td>
    </tr>
    </table><br>
    <?php
    }
    }
    if ($count>0)
    {
    ?>   
    <table width="100%" cellspacing="1" cellpadding="0">
    <tr>
        <td align="center" style="padding:5px"><input class="formButton" type="submit" name="add" value="<?php echo $msg_add5; ?>" title="<?php echo $msg_add5; ?>"></td>
    </tr>
    </table>
    <?php
    }
    ?>
    </form>
	</div>

