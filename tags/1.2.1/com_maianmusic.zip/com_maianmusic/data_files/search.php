<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: search.php
  Description: Search

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }
global $database, 	
$sql_string,	
$msg_sales18,
$msg_sales19,
$msg_header8,	
$q_search,
$s_days,
$months,
$msg_sales21,
$msg_sales20,
$msg_sales32,
$msg_sales23,
$days,
$s_months,
$msg_sales22,
$msg_search10,
$msg_sales16,
$msg_search11,
$msg_sales17,
$msg_search,
$msg_search12,
$msg_sales14,
$msg_sales15,
$msg_javascript33,
$limit,
$msg_search9,
$s_years,
$msg_search8,
$page,
$msg_publicsearch4,
$msg_search5,
$msg_search4,
$years,
$msg_search7,
$msg_search6,
$purchases,
$msg_search3,
$s_months_value,
$msg_search2, $SEARCH_RESULTS;
include(FOLDER_PATH.'admin_inc/cal_array.inc.php');

?>
  <div id="main">
    <?php
    if (isset($SEARCH_RESULTS))
    {
    ?>
    <p><b><?php echo $msg_search10; ?></b> &raquo;<br><br>
    <?php echo $msg_search11; ?>:</p>
    <form method="post" name="MyForm" action="index2.php?option=com_maianmusic&section=sales" onsubmit="return delete_confirm('<?php echo $msg_javascript33; ?>')">
    <input type="hidden" name="process" value="1">
    <input type="hidden" name="search" value="1">
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable" align="left" width="95%">&raquo; <?php echo str_replace("{count}",rowCount('paypal',' '.$sql_string),$msg_publicsearch4); ?></td>
      <td align="center" class="menuTable"><input type="checkbox" name="log" onclick="selectAll()"></td>
    </tr>
    </table>
    <?php
    
    if (count($q_search)>0)
    {
      //while ($PAYPAL = mysql_fetch_object($q_search))
      foreach ($q_search AS $PAYPAL)
      {
        $purchases = explode("||", $PAYPAL->purchases);
      ?>
      <table width="100%" cellspacing="0" cellpadding="0" style="border:1px solid #40ACC7;margin-top:3px">
      <tr>
        <td align="left" style="padding:5px" width="40%">
        <b><?php echo cleanData($PAYPAL->first_name.' '.$PAYPAL->last_name); ?></b><br>
        <?php echo $PAYPAL->p_date; ?>
        </td>
        <td align="left" style="padding:5px" width="20%">
        <?php echo $msg_sales20.': '.($PAYPAL->total_albums>0 ? '<a href="javascript:toggle_box(\'show_purchases_'.$PAYPAL->id.'\')" title="'.$msg_sales32.'"><b>'.$PAYPAL->total_albums.'</b></a>' : '<b>'.$PAYPAL->total_albums.'</b>'); ?><br>
        <?php echo $msg_sales21.': '.($PAYPAL->total_tracks>0 ? '<a href="javascript:toggle_box(\'show_purchases_'.$PAYPAL->id.'\')" title="'.$msg_sales32.'"><b>'.$PAYPAL->total_tracks.'</b></a>' : '<b>'.$PAYPAL->total_tracks.'</b>'); ?>
        </td>
        <td align="center" style="padding:5px;font-size:14px;font-weight:bold" width="15%"><?php echo get_cur_symbol(number_format($PAYPAL->gross-$PAYPAL->fee,2),$SETTINGS->paypal_currency); ?><br>
        <span style="font-size:10px;font-weight:normal"><?php echo get_cur_symbol(number_format($PAYPAL->gross,2),$SETTINGS->paypal_currency); ?> - <?php echo get_cur_symbol(number_format($PAYPAL->fee,2),$SETTINGS->paypal_currency); ?></span></td>
        <td align="center" style="padding:5px" width="20%">
        <a href="index2.php?option=com_maianmusic&section=sales&amp;view=<?php echo $PAYPAL->id; ?>" rel="gb_page_center[620, 450]" title="<?php echo $msg_sales22; ?> - <?php echo cleanData($PAYPAL->first_name.' '.$PAYPAL->last_name); ?>"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/view_sale.gif" alt="<?php echo $msg_sales22; ?>" title="<?php echo $msg_sales22; ?>" class="image_pad"></a> 
        <a href="index2.php?option=com_maianmusic&section=sales&amp;contact=<?php echo $PAYPAL->id; ?>" rel="gb_page_center[680, 350]" title="<?php echo $msg_sales23; ?> - <?php echo cleanData($PAYPAL->first_name.' '.$PAYPAL->last_name); ?>"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/contact_buyer.gif" alt="<?php echo $msg_sales23; ?>" title="<?php echo $msg_sales23; ?>" class="image_pad"></a></td>
        <td align="center" style="padding:5px"><input type="checkbox" name="sale[]" value="<?php echo $PAYPAL->id; ?>##<?php echo $PAYPAL->cart_code; ?>"></td>
      </tr>
      </table>
      <div id="show_purchases_<?php echo $PAYPAL->id; ?>" style="border:1px solid #D9EEF4;margin-top:3px;padding:10px;<?php echo (isset($_SESSION['expand_sales']) ? '' : 'display:none'); ?>">
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" width="50%" valign="top"><span class="orange">[ <?php echo $msg_sales15; ?> ]</span><br><br>
        <?php
        
        $database->setQuery("SELECT * FROM #__mm_albums
                              WHERE id IN (".$purchases[0].")
                              ORDER BY name
                              ") ;
       $q_album =  $database->loadObjectList();
        if (count($q_album)>0)
        {
          while ($ALBUM = mysql_fetch_object($q_album))
          {
            echo '&#8226; '.cleanData($ALBUM->name).'<br>
                  <span class="italics">'.$msg_sales19.' '.cleanData($ALBUM->artist).'</span><br><br>
                  ';
          }
        }
        else
        {
          echo $msg_sales17; 
        }
        
        ?>
        </td>
        <td align="left" width="50%" valign="top"><span class="orange">[ <?php echo $msg_sales16; ?> ]</span><br><br>
        <?php
        
        $database->setQuery("SELECT * FROM #__mm_tracks
                                 WHERE id IN (".$purchases[1].")
                                 ORDER BY track_album,track_name
                                 ") ;
        		$q_tracks = $database->loadObjectList();
        if (count($q_tracks)>0)
        {
          foreach($q_tracks as $TRACKS){
            $ad = getAlbumData($TRACKS->track_album,true);
            
            echo '&#8226; '.cleanData($TRACKS->track_name).'<br>
                  <span class="italics">'.cleanData($ad->name).'/'.cleanData($ad->artist).'</span><br><br>';
          }
        }
        else
        {
          echo $msg_sales18; 
        }
        
        ?>
        </td>
      </tr>
      </table>
      </div>
      <?php
      }
      ?>
      <table width="100%" cellspacing="0" cellpadding="0" style="margin-top:5px">
      <tr>
        <td align="left"><input class="formButton" type="button" value="<?php echo $msg_search12; ?>" title="<?php echo $msg_search12; ?>" onclick="window.location='index2.php?option=com_maianmusic&section=search'"></td>
        <td align="right"><input class="formButton" type="submit" value="<?php echo $msg_sales14; ?>" title="<?php echo $msg_sales14; ?>"></td>
      </tr>
      </table>
      </form>
      <?php
      
      // Page numbers..
      echo admin_page_numbers(rowCount('paypal',' '.$sql_string),$limit,$page);
    }
    
    }
    else
    {
    ?>
		<p><b><?php echo $msg_header8; ?></b> &raquo;<br><br>
    <?php echo $msg_search; ?></p>
    <?php
    if (isset($NO_RESULTS))
    {
    ?>
    <div style="border: 1px solid #FF7700;margin-bottom: 10px;padding:10px;color:#FF7700">
      <p style="margin:0;padding:0"><?php echo $msg_search9; ?></p>
    </div>
    <?php
    }
    ?>
    <form method="get" action="index.php?option=com_maianmusic&section=search">
    <input type="hidden" name="option" value="com_maianmusic">
    <input type="hidden" name="section" value="search">
    <input type="hidden" name="process" value="1">
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_search2; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td class="formOption" width="30%"><?php echo $msg_search3; ?></td>
        <td align="left" style="padding:5px" width="70%"><input class="formBox" type="text" name="name" maxlength="250" size="30" value="<?php echo (isset($_POST['name']) ? cleanData($_POST['name']) : ''); ?>"></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_search4; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="email" maxlength="250" size="30" value="<?php echo (isset($_POST['email']) ? cleanData($_POST['email']) : ''); ?>"></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_search5; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="invoice" maxlength="250" size="30" value="<?php echo (isset($_POST['invoice']) ? cleanData($_POST['invoice']) : ''); ?>"></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_search6; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="txn_id" maxlength="250" size="30" value="<?php echo (isset($_POST['txn_id']) ? cleanData($_POST['txn_id']) : ''); ?>"></td>
      </tr>
      <tr>
        <td class="formOption" valign="top" style="padding-top:7px"><?php echo $msg_search7; ?></td>
        <td align="left" style="padding:5px">
        <select name="from_day">
            <option selected value="0"> - </option>
            <?php

            foreach ($days as $s_days)
            {
              echo '<option'.(isset($_POST['from_day']) && $_POST['from_day']==$s_days ? ' selected ' : ' ').'value="'.$s_days.'" style="padding-left:3px">'.$s_days.'</option>'."\n";
            }

            ?>
            </select>
            <select name="from_month">
            <option selected value="0"> - </option>
            <?php

            foreach ($months as $s_months => $s_months_value)
            {
              echo '<option'.(isset($_POST['from_month']) && $_POST['from_month']==$s_months ? ' selected ' : ' ').'value="'.$s_months.'" style="padding-left:3px">'.$s_months_value.'</option>'."\n";
            }
        
            ?>
            </select>
            <select name="from_year">
            <option selected value="0"> - </option>
            <?php

            foreach ($years as $s_years)
            {
              echo '<option'.(isset($_POST['from_year']) && $_POST['from_year']==$s_years ? ' selected ' : ' ').'value="'.$s_years.'" style="padding-left:3px">'.$s_years.'</option>'."\n";
            }

            ?>
            </select><br><br>
            <select name="to_day">
            <option selected value="0"> - </option>
            <?php

            foreach ($days as $s_days)
            {
              echo '<option'.(isset($_POST['to_day']) && $_POST['to_day']==$s_days ? ' selected ' : ' ').'value="'.$s_days.'" style="padding-left:3px">'.$s_days.'</option>'."\n";
            }

            ?>
            </select>
            <select name="to_month">
            <option selected value="0"> - </option>
            <?php

            foreach ($months as $s_months => $s_months_value)
            {
              echo '<option'.(isset($_POST['to_month']) && $_POST['to_month']==$s_months ? ' selected ' : ' ').'value="'.$s_months.'" style="padding-left:3px">'.$s_months_value.'</option>'."\n";
            }
        
            ?>
            </select>
            <select name="to_year">
            <option selected value="0"> - </option>
            <?php

            foreach ($years as $s_years)
            {
              echo '<option'.(isset($_POST['to_year']) && $_POST['to_year']==$s_years ? ' selected ' : ' ').'value="'.$s_years.'" style="padding-left:3px">'.$s_years.'</option>'."\n";
            }

            ?>
            </select>
        </td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="left" style="padding:5px"><input class="formButton" type="submit" value="<?php echo $msg_search8; ?>" title="<?php echo $msg_search8; ?>"></td>
      </tr>
      </table>
      </td>
    </tr>
    </table> 
    </form> 
    <?php
    }
    ?>
	</div>

