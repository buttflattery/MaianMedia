<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: search.php
  Description: Search

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }
?>
  <div id="main">
		<p><?php echo $msg_login2; ?></p>
    <form method="post" name="login" action="index.php?cmd=login">
    <input type="hidden" name="process" value="1">
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_login; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6"><br />
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td class="formOption" width="30%"><?php echo (isset($n_error) ? '<span style="color:red">'.$msg_login3.'</span>' : $msg_login3); ?></td>
        <td align="left" style="padding:5px" width="70%"><input class="formBox" type="text" name="user" size="30" value="<?php echo (isset($_POST['user']) ? cleanData($_POST['user']) : ''); ?>"<?php echo (isset($n_error) ? ' style="border:1px solid red"' : ''); ?>> <?php echo (isset($n_error) ? '<span style="color:red;font-weight:bold">'.$msg_login6.'</span>' : ''); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo (isset($p_error) ? '<span style="color:red">'.$msg_login4.'</span>' : $msg_login4); ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="password" name="pass" size="30" value="<?php echo (isset($_POST['pass']) ? cleanData($_POST['pass']) : ''); ?>"<?php echo (isset($p_error) ? ' style="border:1px solid red"' : ''); ?>> <?php echo (isset($p_error) ? '<span style="color:red;font-weight:bold">'.$msg_login6.'</span>' : ''); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_login7; ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="cookie" value="1"> <?php echo toolTip($msg_javascript,$msg_javascript31); ?></td>
      </tr>
      </table><br><br>
      </td>
    </tr>
    </table><br>
    <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center" style="padding:5px"><input class="formButton" type="submit" value="<?php echo $msg_login5; ?>" title="<?php echo $msg_login5; ?>"></td>
    </tr>
    </table>
    </form>
	</div>

