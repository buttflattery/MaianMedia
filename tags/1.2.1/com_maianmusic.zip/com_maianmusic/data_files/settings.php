<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: settings.php
  Description: Settings

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }

global $msg_settings35,	
$msg_settings24,		
$msg_settings25,	
$msg_settings41,
$msg_settings42,
$msg_settings43,	
$msg_settings34,	
$msg_javascript2,	
$msg_settings26,	
$msg_settings37,	
$msg_settings27,	
$msg_javascript3,	
$msg_settings14,	
$msg_settings36,	
$msg_settings13,	
$msg_javascript4,	
$msg_settings31,		
$msg_settings20,	
$msg_javascript5,	
$msg_settings30,	
$msg_settings21,	
$msg_settings12,	
$msg_settings,	
$msg_javascript6,	
$msg_settings11,	
$msg_settings33,	
$msg_settings10,	
$msg_javascript7,	
$msg_settings23,	
$msg_settings32,	
$msg_javascript8,	
$msg_javascript9,	
$msg_settings28,	
$msg_settings29,	
$msg_settings19,		
$msg_settings18,	
$msg_settings6,	
$msg_javascript,	
$msg_javascript11,	
$msg_settings7,	
$msg_javascript10,	
$msg_javascript32,	
$msg_settings4,		
$msg_settings5,	
$msg_javascript30,	
$msg_settings2,	
$msg_javascript37,	
$msg_settings3,	
$msg_javascript36,	
$msg_javascript24,	
$msg_javascript35,		
$msg_javascript29,	
$msg_settings8,	
$msg_settings9,
$msg_settings38,	
$msg_settings39,
$msg_settings40,
$msg_javascript38,
$msg_javascript39,
$msg_settings44,
$msg_public_header12,
$msg_public_header3,
$msg_public_header15,
$msg_settings16;

$popP = '';
$musicP = '';

if ($SETTINGS->default_page == '0') {
	$popP = 'checked';
}
else if ($SETTINGS->default_page == '1') {
	$musicP = 'checked';
}

$radioBox = '<checked>';
?>
  <div id="main">
		<p><b><?php echo $msg_header3; ?></b> &raquo;<br><br>
    <?php echo $msg_settings; ?></p>
    <form method="post" action="index2.php?option=com_maianmusic&section=settings">
    <input type="hidden" name="process" value="1">
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_settings2; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td class="formOption"><?php echo $msg_settings41; ?></td>
        <td align="left" style="padding:5px">
        	<input type="radio" name="default_page" value="0" <?php echo $popP?>><?php echo$msg_settings42; ?>&nbsp;
        	<input type="radio" name="default_page" value="1"<?php echo $musicP?>><?php echo $msg_settings43; ?>&nbsp;
        	<?php echo toolTip($msg_javascript,$msg_javascript39); ?>
        </td>
      </tr>
      <tr>
        <td class="formOption" width="30%"><?php echo $msg_settings3; ?></td>
        <td align="left" style="padding:5px" width="70%"><input class="formBox" type="text" name="website_name" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->website_name); ?>"></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings4; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="email_address" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->email_address); ?>"></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings7; ?></td>
        <td align="left" style="padding:5px"><select name="language">
        <?php

        // Load language files..
        $lang = opendir(RELATIVE_PATH.'lang/');

        while ($READ = readdir($lang))
        {
  	      if ($READ != "." && $READ != ".." && $READ != "index.html") {
        	  echo '<option'.(($READ == $SETTINGS->language) ? ' selected' : '').'>'.$READ.'</option>'."\n";
          }
        }

        closedir($lang);
        
        ?>
        </select></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings26; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="rssfeeds" maxlength="3" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->rssfeeds); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript36); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings27; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="poplinks" maxlength="3" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->poplinks); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript37); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings8; ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="enable_captcha" value="1"<?php echo ($SETTINGS->enable_captcha ? ' checked' : ''); ?>> <?php echo toolTip($msg_javascript,$msg_javascript3); ?></td>
      </tr>
      </table>
      </td>
    </tr>
    </table><br> 
<table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">

    <tr>

      <td class="menuTable">&raquo; <?php echo $msg_settings38; ?></td>

    </tr>

    <tr>

      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">

      <table width="100%" cellspacing="0" cellpadding="0">

      <tr>

        <td class="formOption"><?php echo $msg_settings39; ?></td>

        <td align="left" style="padding:5px"><select STYLE="width: 230px" id="player" name="player">
		<?php
       	
		$key = 1;
		$skin = 0;
		
		while($key <=12) {
			
			if($key == 1){
       			$value = 'Premium Beat + Skin 1';
       			$skin = 1;
       		}
       		
			if($key == 2){
       			$value = 'Premium Beat + Skin 2';
       			$skin = 2;
       		}
       		
			if($key == 3){
       			$value = 'Premium Beat + Skin 3';
       			$skin = 3;
       		}
       		
			if($key == 4){
       			$value = 'Premium Beat + Skin 4';
       			$skin = 4;
       		}

			if($key == 5){
       			$value = 'Premium Beat + Skin 5';
       			$skin = 5;
       		}
       		
			if($key == 6){
       			$value = 'dewplayer + vol';
       		}
       		
       		if($key == 7){
       			$value = 'dewplayer standard';
       		}
       		
       		if($key == 8){
       			$value = 'dewplayer mini';
       		}
       		
       		if($key == 9){
       			$value = 'simplemp3player';
       		}
       		
       		if($key == 10){
       			$value = 'simplemp3player mini';
       		}
       		
			if($key == 11){
       			$value = 'player_mp3';
       		}
       		
			if($key == 12){
       			$value = 'mediaplayer';
       		}
       		
        	echo '<option value="'.$key.'" style="padding-left:3px"'.($SETTINGS->player==$key ? ' selected' : '').'>'.$value.'</option>'."\n";
			
        	$key= $key + 1;
        }
        echo '</select> </td><td>';
        include_once($mainframe->getCfg('absolute_path').'/components/com_maianmusic/players/mp3players.php');
        echo '<!-- Begin Flash Player -->'.mp3players::getplayer($SETTINGS->player, "test.mp3", $SETTINGS->player, 1).'<!-- End Flash Player -->';
        ?>        
        
        </td>
      </tr>

      </table>

      </td>

    </tr>

    </table><br>

    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_settings9; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td class="formOption" width="30%"><?php echo $msg_settings10; ?></td>
        <td align="left" style="padding:5px" width="70%"><input class="formBox" type="text" name="mp3_path" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->mp3_path); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript4); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings11; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="preview_path" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->preview_path); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript5); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings25; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="page_expiry" maxlength="2" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->page_expiry); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript24); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings31; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="download_expiry" maxlength="2" size="30" style="width:10%" value="<?php echo cleanData($SETTINGS->download_expiry); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript30); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings30; ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="reset" value="1"> <?php echo toolTip($msg_javascript,$msg_javascript29); ?></td>
      </tr>
      </table>
      </td>
    </tr>
    </table><br>
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_settings14; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td class="formOption" width="30%"><?php echo $msg_settings21; ?></td>
        <td align="left" style="padding:5px" width="70%"><select name="paypal_currency">
        <?php
        
        include(FOLDER_PATH.'admin_inc/currencies.inc.php');
        
        foreach ($currencies AS $key => $value) {
          echo '<option value="'.$key.'" style="padding-left:3px"'.($SETTINGS->paypal_currency==$key ? ' selected' : '').'>'.$value.'</option>'."\n";
        }
        
        ?>
        </select> <?php echo toolTip($msg_javascript,$msg_javascript11); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings20; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="paypal_email" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->paypal_email); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript8); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings40; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="pdt" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->pdt); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript38); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings19; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="page_style" maxlength="250" size="30" value="<?php echo cleanData($SETTINGS->page_style); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript9); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings16; ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="paypal_mode" value="1"<?php echo ($SETTINGS->paypal_mode ? ' checked' : ''); ?>> <?php echo toolTip($msg_javascript,$msg_javascript7); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings18; ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="log_errors" value="1"<?php echo ($SETTINGS->log_errors ? ' checked' : ''); ?>> <?php echo toolTip($msg_javascript,$msg_javascript10); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_settings28; ?></td>
        <td align="left" style="padding:5px"><input type="checkbox" name="ssl_enabled" value="1"<?php echo ($SETTINGS->ssl_enabled ? ' checked' : ''); ?>> <?php echo toolTip($msg_javascript,$msg_javascript35); ?></td>
      </tr>
      </table>
      </td>
    </tr>
    </table><br>
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_settings33; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" width="30%"><?php echo $msg_settings34; ?>:</td>
        <td align="left" width="70%" style="padding:5px"><input type="checkbox" name="smtp" value="1"<?php echo ($SETTINGS->smtp ? ' checked' : ''); ?>> <?php echo toolTip($msg_javascript,$msg_javascript32); ?></td>
      </tr>
      <tr>
        <td align="left"><?php echo $msg_settings35; ?>:</td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="smtp_host" size="20" value="<?php echo $SETTINGS->smtp_host; ?>"></td>
      </tr>
      <tr>
        <td align="left"><?php echo $msg_settings36; ?>:</td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="smtp_user" size="20" value="<?php echo $SETTINGS->smtp_user; ?>"></td>
      </tr>
      <tr>
        <td align="left"><?php echo $msg_settings37; ?>:</td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="smtp_pass" size="20" value="<?php echo $SETTINGS->smtp_pass; ?>"></td>
      </tr>
      <tr>
        <td align="left"><?php echo $msg_settings29; ?>:</td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="smtp_port" size="20" value="<?php echo $SETTINGS->smtp_port; ?>" style="width:10%"></td>
      </tr>
      </table>
      </td>
    </tr>
    </table><br>
<?php
// instantiate new tab system
$tabs = new mosTabs(1);

// start tab pane
$tabs->startPane("TabPaneOne");

//First tab
$tabs->startTab($msg_public_header3,"firsttab-page");
?>
  
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_public_header15; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
<?php
					// parameters : areaname, content, hidden field, width, height, rows, cols
					editorArea( 'about', cleanData($SETTINGS->about), 'about', '98%;', '350', '75', '20' ) ; ?>

      <span style="font-size:10px;display:block;margin-top:3px"><?php echo $msg_settings24; ?></span>
      </td>
    </tr>
    </table>
<?php
$tabs->endTab();

//Second Tab
$tabs->startTab($msg_settings43,"secondtab-page");
?>
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_settings44; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
<?php
					// parameters : areaname, content, hidden field, width, height, rows, cols
					editorArea( 'music', cleanData($SETTINGS->music), 'music', '98%;', '350', '75', '20' ) ; ?>

      <span style="font-size:10px;display:block;margin-top:3px"><?php echo $msg_settings24; ?></span>
      </td>
    </tr>
    </table>
<?php
$tabs->endTab();

//Second Tab
$tabs->startTab($msg_public_header12,"thirdtab-page");
?>
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_settings32; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
<?php
					// parameters : areaname, content, hidden field, width, height, rows, cols
					editorArea( 'licence', cleanData($SETTINGS->licence), 'licence', '98%;', '350', '75', '20' ) ; ?>

      <span style="font-size:10px;display:block;margin-top:3px"><?php echo $msg_settings24; ?></span>
      </td>
    </tr>
    </table>
<?php
$tabs->endTab();

// end tab pane
$tabs->endPane("TabPaneOne");

?>

    <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center" style="padding:5px"><input class="formButton" type="submit" value="<?php echo $msg_settings12; ?>" title="<?php echo $msg_settings12; ?>"></td>
    </tr>
    </table>

    </form>
	</div>