<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: home.php
  Description: Admin Home

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }
global $database, $SETTINGS, $msg_home, $msg_home4, $msg_home5, $msg_home6, $msg_home7, $msg_home2, $msg_home3,
$setup15, $setup16, $setup17, $setup18, $setup19, $setup20, $setup22;

?>
  <div id="main">
    <?php
    // Is the installation dir present..
		if (isset($install))
		{
		?>
		<div style="text-align: center;padding:10px;display:block;border:2px solid #FF0000;color:#FF0000;font-size:18px;font-weight: bold">
     <?php echo $msg_home7; ?>
    </div><br />
		<?php
		}
		?>
		<p><?php echo $msg_home; ?></p>
	<table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
  		<tr>
      		<td class="menuTable">&raquo; <?php echo $setup17; ?></td>
      		<td class="menuTable"></td>
		</tr>
  		<tr>
    		<td class="pad" width="60%"><b><?php echo $setup16; ?></b> v<?php echo phpversion(); ?> </td>
    		<td class="pad"><span class="info"><b><?php echo (phpversion()>'4.3.0' ? $setup19 : $setup22); ?></b></span></td>
  		</tr>
  		<tr>
    		<td class="pad"><b><?php echo $setup15; ?></b></td>
    		<td class="pad"><span class="info"><b><?php echo (function_exists('curl_setopt') ? $setup19 : $setup20); ?></b></span></td>
  		</tr>
  		<tr>
    		<td class="pad"><b><?php echo $setup18; ?></b></td>
    		<td class="pad"><span class="info"><b><?php echo (function_exists('imagecreatetruecolor') ? $setup19 : $setup20); ?></b></span></td>
  		</tr>
  </table>


		<table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_home5; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <?php 
      
      $database->setQuery("SELECT SUM(fee) AS p_fee,SUM(gross) AS p_gross
                            FROM #__mm_paypal
                            WHERE active_cart = '1'");	  $database->loadObject($PP);     
      $find     = array('{tracks}','{albums}','{fees}','{profit}','{a_purchases}','{t_purchases}');
      $replace  = array(number_format(getTableRowCount('tracks')),
                        number_format(getTableRowCount('albums')),
                        get_cur_symbol(number_format($PP->p_fee,2),$SETTINGS->paypal_currency),
                        get_cur_symbol(number_format($PP->p_gross-$PP->p_fee,2),$SETTINGS->paypal_currency),
                        number_format(getTableRowCount('purchases',' WHERE SUBSTRING(item_id,1,1)=\'a\' AND track_id = \'0\'')),
                        number_format(getTableRowCount('purchases',' WHERE SUBSTRING(item_id,1,1)=\'t\''))
                        );
      
      echo str_replace($find,$replace,$msg_home6); 
      
      ?>
      </td>
    </tr>
    </table><br>
		<table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td COLSPAN=2 class="menuTable">&raquo; <?php echo $msg_home2; ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6"><?php echo $msg_home3; ?><br><br>
      <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=alaoa%40sbcglobal%2enet&item_name=Are%20Times&item_number=Are-<?php echo date("Y"); ?>&no_shipping=0&no_note=1&tax=0&currency_code=USD&lc=US&bn=PP%2dDonationsBF&charset=UTF%2d8" target="_blank"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/donation.gif" border="0" alt="Donate using Paypal" title="Donate using Paypal"></a><br><br>
      <?php echo $msg_home4; ?></td>
      <td style="padding:5px;border-top:1px solid #40ABC6"><a href="http://www.aretimes.com/index.php?option=com_maianmusic&section=album&album=1" alt="Visions Of A Better Life" ><img border="0" src="../components/com_maianmusic/images/visions_of_a_better_life.png"></img></a></td>
    </tr>
    </table>
	</div>

