<?php
/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: tracks.php
  Description: Manage Tracks

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }

global $database, 
$msg_tracks4,	
$msg_tracks3,	
$msg_tracks2,		
$limit,	
$msg_albums4,	
$page,	
$limitvalue,	
$msg_albums9,	
$msg_tracks;
?>
  <div id="main">
		<p><b><?php echo $msg_header6; ?></b> &raquo;<br><br>
    <?php echo $msg_tracks; ?></p>
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_albums4; ?> (<?php echo rowCount('albums'); ?>)</td>
    </tr>
    <?php
    
    $database->setQuery("SELECT * FROM #__mm_albums 
                             ORDER BY artist,name
                             LIMIT $limitvalue,$limit
                             ");
    $q_albums = $database->loadObjectList();
    if (count($q_albums)>0)
    {
    ?>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <?php             foreach ($q_albums as $ALBUMS){
      ?>
      <table width="100%" cellspacing="0" cellpadding="0" style="border-bottom:1px solid #D9EEF4;border-left:1px solid #D9EEF4;margin-bottom:3px">
      <tr>
        <td class="formOption" width="70%" style="padding:10px 5px 10px 5px"><b><?php echo cleanData($ALBUMS->artist); ?></b><br>-<?php echo cleanData($ALBUMS->name); ?></td>
        <td align="center" width="20%">- <?php echo str_replace("{count}",rowCount('tracks',' WHERE track_album = \''.$ALBUMS->id.'\''),$msg_tracks2); ?> -</td>
        <td align="center" width="10%"><?php echo (rowCount('tracks',' WHERE track_album = \''.$ALBUMS->id.'\'')>0 ? '<a href="index2.php?option=com_maianmusic&section=view_tracks&amp;id='.$ALBUMS->id.'"><img src="components/com_maianmusic/images/view.gif" alt="'.$msg_tracks3.'" title="'.$msg_tracks3.'" border="0"></a>' : '<img src="components/com_maianmusic/images/view2.gif" alt="'.$msg_tracks4.'" title="'.$msg_tracks4.'" border="0">'); ?></td>
      </tr>
      </table>
      <?php
      }
      ?>
      </td>
    </tr>
    <?php
    } else {
    ?>  
    <tr>
      <td align="center" style="padding:10px 0 10px 0;border-top:1px solid #40ABC6"><?php echo $msg_albums9; ?></td>
    </tr>
    <?php
    }
    ?>
    </table>
    <?php
    if (count($q_albums)>0)
    {
      echo admin_page_numbers(rowCount('albums'),$limit,$page);
    }
    ?>
	</div>

