<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: view_sale.php
  Description: View Sale

  ++++++++++++++++++++++++++++++++++++++++*/
global $database,
$mainframe,
$msg_sales29,	
$msg_sales38,	
$msg_sales39,	
$msg_sales18,	
$msg_sales19,	
$msg_sales30,	
$msg_sales31,	
$msg_sales33,	
$msg_script11,	
$msg_sales34,	
$msg_sales16,	
$msg_script10,	
$msg_sales35,	
$msg_sales17,	
$msg_sales36,	
$msg_sales41,	
$msg_sales37,	
$msg_sales40,	
$msg_sales15,	
$msg_javascript34;


$database->setQuery("SELECT *,DATE_FORMAT(pay_date,'%e %b %Y') AS p_date 
                        FROM #__mm_paypal
                        WHERE id = '{$_GET['view']}'
                        LIMIT 1
                        ");
$database->loadObject($BUYER);
$purchases = explode("||", $BUYER->purchases);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title></title>
<script type="text/javascript" src="js/js_code.js"></script>
<link href="components/com_maianmusic/stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>

<div class="pop">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
    <td align="left" style="padding:5px">
    <?php
    if (isset($RESET))
    {
    ?>
    &#8226; <span style="letter-spacing:1px"><b><?php echo $msg_sales31; ?></b></span> (<a href="index2.php?option=com_maianmusic&section=sales&amp;view=<?php echo $_GET['view']; ?>" title="<?php echo $msg_script10; ?>"><?php echo $msg_script10; ?></a>)
    <?php
    }
    else
    {
    ?>
    &#8226; <a href="index2.php?option=com_maianmusic&section=sales&amp;view=<?php echo $_GET['view']; ?>&resend=<?php echo $BUYER->cart_code; ?>" onclick="return delete_confirm('<?php echo $msg_javascript34; ?>')" title="<?php echo $msg_sales29; ?>"><?php echo $msg_sales29; ?></a>
    <?php
    }
    ?>
    </td>
    <td align="right" width="5%" style="padding:5px"><a href="javascript:window.print()"><img src="components/com_maianmusic/images/print.gif" alt="<?php echo $msg_script11; ?>" title="<?php echo $msg_script11; ?>" border="0"></a></td>
</tr>
</table>
</div> 

<div class="pop">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
    <td align="left" style="padding:5px">
    <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td align="left" width="50%" style="padding:5px" valign="top"><span class="orange">[ <?php echo $msg_sales30; ?> ]</span><br><br>
      &#8226; <b><?php echo $msg_sales33; ?></b>: <br>
      <?php echo cleanData($BUYER->first_name.' '.$BUYER->last_name); ?><br><br>
      &#8226; <b><?php echo $msg_sales34; ?></b>: <br>
      <a href="mailto:<?php echo $BUYER->email; ?>" style="color:#40ACC7;text-decoration:none"><?php echo $BUYER->email; ?></a><br><br>
      &#8226; <b><?php echo $msg_sales35; ?></b>: <br>
      <?php echo $BUYER->p_date; ?><br><br>
      &#8226; <b><?php echo $msg_sales36; ?></b>: <br>
      <?php echo nl2br(cleanData($BUYER->address)); ?><br><br>
      &#8226; <b><?php echo $msg_sales37; ?></b>: <br>
      <?php echo ($BUYER->memo ? nl2br(cleanData($BUYER->memo)) : 'N/A'); ?><br><br>
      &#8226; <b><?php echo $msg_sales38; ?></b>: <br>
      <?php echo $BUYER->payment_status; ?><br><br>
      &#8226; <b><?php echo $msg_sales39; ?></b>: <br>
      <?php echo get_cur_symbol(number_format($BUYER->gross,2),$SETTINGS->paypal_currency); ?> / <?php echo get_cur_symbol(number_format($BUYER->fee,2),$SETTINGS->paypal_currency); ?> / <?php echo get_cur_symbol(number_format($BUYER->gross-$BUYER->fee,2),$SETTINGS->paypal_currency); ?><br><br>
      &#8226; <b><?php echo $msg_sales40; ?></b>: <br>
      <?php echo $BUYER->txn_id; ?><br><br>
      &#8226; <b><?php echo $msg_sales41; ?></b>: <br>
      <?php echo $BUYER->invoice; ?><br><br>
      </td>
      <td align="left" width="50%" style="padding:5px;border-left:1px solid #40ACC7" valign="top">
      <span class="orange">[ <?php echo $msg_sales15; ?> ]</span><br><br>
      <?php
        
      $database->setQuery("SELECT * FROM #__mm_albums
                              WHERE id IN (".$purchases[0].")
                              ORDER BY name
                              ");	  $q_album  = $database->loadObjectList(); 
        
      if (count($q_album)>0)
      {      	 foreach ($q_album as $ALBUM ){
          echo '&#8226; '.cleanData($ALBUM->name).'<br>
                <span class="italics">'.$msg_sales19.' '.cleanData($ALBUM->artist).'</span><br><br>
                ';
        }
      }
      else
      {
        echo $msg_sales17.'<br><br>'; 
      }
      
      ?>
      <span class="orange">[ <?php echo $msg_sales16; ?> ]</span><br><br>
      <?php
        
       $database->setQuery("SELECT * FROM #__mm_tracks
                               WHERE id IN (".$purchases[1].")
                               ORDER BY track_album,track_name
                               ");
     $q_tracks  = $database->loadObjectList(); 
      if (count($q_tracks)>0)
      {
        foreach ($q_tracks as $TRACKS){
          $ad = getAlbumData($TRACKS->track_album,true);
            
          echo '&#8226; '.cleanData($TRACKS->track_name).'<br>
                <span class="italics">'.cleanData($ad->name).'/'.cleanData($ad->artist).'</span><br><br>';
        }
      }
      else
      {
        echo $msg_sales18; 
      }
        
      ?>
      </td>
    </tr>
    </table>
    </td>
</tr>
</table>
</div>  

</body>
</html>
