<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: sales.php
  Description: View Sales

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }
global $database,
$msg_sales18,	
$msg_sales19,	
$msg_statistics11,	
$msg_statistics10,	
$msg_sales12,	
$msg_sales21,	
$msg_sales20,	
$msg_sales13,	
$msg_sales10,	
$msg_sales32,	
$msg_sales23,	
$sql,	
$msg_header7,	
$msg_sales,	
$msg_sales11,	
$msg_sales22,	
$msg_sales16,	
$msg_sales17,	
$msg_sales14,	
$msg_sales15,	
$limit,	
$msg_javascript33,		
$msg_sales9,		
$msg_sales8,		
$msg_statistics2,	
$page,		
$msg_sales3,	
$msg_sales2,		
$limitvalue,	
$msg_sales7,		
$msg_sales6,		
$msg_sales5,	
$msg_sales4;
// Per page drop down options..
// Change these values or add to them if you want to..
$per = array(10,25,50,75,100,125,150,200,250,300,375,400,500);

// Query database for paypal information..
 $database->setQuery("SELECT *,DATE_FORMAT(pay_date,'%e %b %Y') AS p_date 
                        FROM #__mm_paypal
                        WHERE active_cart = '1'
                        ".(isset($sql) ? $sql : '')."
                        LIMIT $limitvalue,$limit");
 $q_paypal = $database->loadObjectList();
?>
  <div id="main">
		<p><b><?php echo $msg_header7; ?></b> &raquo;<br><br>
    <?php echo $msg_sales; ?></p>
    <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td align="left" width="33%"><a href="index2.php?option=com_maianmusic&section=sales&amp;expand=1<?php echo (isset($_GET['order']) ? '&amp;order='.$_GET['order'] : ''); ?><?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>" title="<?php echo $msg_statistics10; ?>"><?php echo $msg_statistics10; ?></a> | <a href="index2.php?option=com_maianmusic&section=sales&amp;close=1<?php echo (isset($_GET['order']) ? '&amp;order='.$_GET['order'] : ''); ?><?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>" title="<?php echo $msg_statistics11; ?>"><?php echo $msg_statistics11; ?></a></td>
      <td align="left" width="33%"><b><?php echo $msg_sales2; ?></b>: 
       <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
       <option style="padding-left:3px" value="0">---</option>
       <?php
       foreach ($per AS $show)
       {
       ?>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=sales&amp;show=<?php echo $show; ?><?php echo (isset($_GET['order']) ? '&amp;order='.$_GET['order'] : ''); ?>"<?php echo (isset($_GET['show']) && $_GET['show']==$show ? ' selected="selected"' : ''); ?>><?php echo $show; ?></option>
       <?php
       }
       ?>
       </select> <b><?php echo $msg_sales3; ?></b></td>
      <td align="right" width="33%"><b><?php echo $msg_statistics2; ?></b>: 
       <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
       <option style="padding-left:3px" value="0">---</option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=sales&amp;order=date_desc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($_GET['order']) && $_GET['order']=='date_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales4; ?></option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=sales&amp;order=date_asc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($_GET['order']) && $_GET['order']=='date_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales5; ?></option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=sales&amp;order=tracks<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($_GET['order']) && $_GET['order']=='tracks' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales6; ?></option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=sales&amp;order=downloads<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($_GET['order']) && $_GET['order']=='downloads' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales7; ?></option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=sales&amp;order=gross_desc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($_GET['order']) && $_GET['order']=='gross_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales8; ?></option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=sales&amp;order=gross_asc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($_GET['order']) && $_GET['order']=='gross_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales9; ?></option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=sales&amp;order=name_asc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($_GET['order']) && $_GET['order']=='name_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales10; ?></option>
       <option style="padding-left:3px" value="index2.php?option=com_maianmusic&section=sales&amp;order=name_desc<?php echo (isset($_GET['show']) ? '&amp;show='.$_GET['show'] : ''); ?>"<?php echo (isset($_GET['order']) && $_GET['order']=='name_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales11; ?></option>
       </select>
      </td>
    </tr>
    </table><br>
    <form method="post" name="MyForm" action="index.php?option=com_maianmusic&section=sales" onsubmit="return delete_confirm('<?php echo $msg_javascript33; ?>')">
    <input type="hidden" name="process" value="1">
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable" align="left" width="95%">&raquo; <?php echo str_replace("{count}",rowCount('paypal',' WHERE active_cart = \'1\''.(isset($sql) ? ' '.$sql : '')),$msg_sales12); ?></td>
      <td align="center" class="menuTable"><input type="checkbox" name="log" onclick="selectAll()"></td>
    </tr>
    </table>
    <?php
    
    if (count($q_paypal)>0)
    {		foreach ($q_paypal AS $PAYPAL)
      //while ($PAYPAL = mysql_fetch_object($q_paypal))
      {
        $purchases = explode("||", $PAYPAL->purchases);
      ?>
      <table width="100%" cellspacing="0" cellpadding="0" style="border:1px solid #40ACC7;margin-top:3px">
      <tr>
        <td align="left" style="padding:5px" width="40%">
        <b><?php echo cleanData($PAYPAL->first_name.' '.$PAYPAL->last_name); ?></b><br>
        <?php echo $PAYPAL->p_date; ?>
        </td>
        <td align="left" style="padding:5px" width="20%">
        <?php echo $msg_sales20.': '.($PAYPAL->total_albums>0 ? '<a href="javascript:toggle_box(\'show_purchases_'.$PAYPAL->id.'\')" title="'.$msg_sales32.'"><b>'.$PAYPAL->total_albums.'</b></a>' : '<b>'.$PAYPAL->total_albums.'</b>'); ?><br>
        <?php echo $msg_sales21.': '.($PAYPAL->total_tracks>0 ? '<a href="javascript:toggle_box(\'show_purchases_'.$PAYPAL->id.'\')" title="'.$msg_sales32.'"><b>'.$PAYPAL->total_tracks.'</b></a>' : '<b>'.$PAYPAL->total_tracks.'</b>'); ?>
        </td>
        <td align="center" style="padding:5px;font-size:14px;font-weight:bold" width="15%"><?php echo get_cur_symbol(number_format($PAYPAL->gross-$PAYPAL->fee,2),$SETTINGS->paypal_currency); ?><br>
        <span style="font-size:10px;font-weight:normal"><?php echo get_cur_symbol(number_format($PAYPAL->gross,2),$SETTINGS->paypal_currency); ?> - <?php echo get_cur_symbol(number_format($PAYPAL->fee,2),$SETTINGS->paypal_currency); ?></span></td>
        <td align="center" style="padding:5px" width="20%">
        <a href="index2.php?option=com_maianmusic&section=sales&amp;view=<?php echo $PAYPAL->id; ?>" rel="gb_page_center[620, 450]" title="<?php echo $msg_sales22; ?> - <?php echo cleanData($PAYPAL->first_name.' '.$PAYPAL->last_name); ?>"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/view_sale.gif" alt="<?php echo $msg_sales22; ?>" title="<?php echo $msg_sales22; ?>" class="image_pad"></a> 
        <a href="index2.php?option=com_maianmusic&section=sales&amp;contact=<?php echo $PAYPAL->id; ?>" rel="gb_page_center[680, 350]" title="<?php echo $msg_sales23; ?> - <?php echo cleanData($PAYPAL->first_name.' '.$PAYPAL->last_name); ?>"><img src="<?php echo $mainframe->getCfg('live_site'); ?>/components/com_maianmusic/images/contact_buyer.gif" alt="<?php echo $msg_sales23; ?>" title="<?php echo $msg_sales23; ?>" class="image_pad"></a></td>
        <td align="center" style="padding:5px"><input type="checkbox" name="sale[]" value="<?php echo $PAYPAL->id; ?>##<?php echo $PAYPAL->cart_code; ?>"></td>
      </tr>
      </table>
      <div id="show_purchases_<?php echo $PAYPAL->id; ?>" style="border:1px solid #D9EEF4;margin-top:3px;padding:10px;<?php echo (isset($_SESSION['expand_sales']) ? '' : 'display:none'); ?>">
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" width="50%" valign="top"><span class="orange">[ <?php echo $msg_sales15; ?> ]</span><br><br>
        <?php
        
         $database->setQuery("SELECT * FROM #__mm_albums
                              WHERE id IN (".$purchases[0].")
                              ORDER BY name
                              ");		 $q_album = $database->loadObjectList();
        
        if (count($q_album)>0)
        {			foreach ($q_album AS $ALBUM)
          //while ($ALBUM = mysql_fetch_object($q_album))
          {
            echo '&#8226; '.cleanData($ALBUM->name).'<br>
                  <span class="italics">'.$msg_sales19.' '.cleanData($ALBUM->artist).'</span><br><br>
                  ';
          }
        }
        else
        {
          echo $msg_sales17; 
        }
        
        ?>
        </td>
        <td align="left" width="50%" valign="top"><span class="orange">[ <?php echo $msg_sales16; ?> ]</span><br><br>
        <?php
        
        $database->setQuery("SELECT * FROM #__mm_tracks
                                 WHERE id IN (".$purchases[1].")
                                 ORDER BY track_album,track_name
                                 ");
        $q_tracks = $database->loadObjectList();
        if (count($q_tracks)>0)
        {
          foreach($q_tracks as $TRACKS){
            $ad = getAlbumData($TRACKS->track_album,true);
            
            echo '&#8226; '.cleanData($TRACKS->track_name).'<br>
                  <span class="italics">'.cleanData($ad->name).'/'.cleanData($ad->artist).'</span><br><br>';
          }
        }
        else
        {
          echo $msg_sales18; 
        }
        
        ?>
        </td>
      </tr>
      </table>
      </div>
      <?php
      }
      ?>
      <p align="right" style="margin:0;padding:5px 0 5px 0;text-align:right"><input class="formButton" type="submit" value="<?php echo $msg_sales14; ?>" title="<?php echo $msg_sales14; ?>"></p>
      </form>
      <?php
      
      // Page numbers..
      echo admin_page_numbers(rowCount('paypal',' WHERE active_cart = \'1\''.(isset($sql) ? ' '.$sql : '')),$limit,$page);
    }
    else
    {
    ?><br>
    <table width="100%" cellspacing="0" cellpadding="0" style="border:1px solid #D9EEF4;margin-bottom:3px">
    <tr>
        <td align="center" style="padding:5px"><?php echo $msg_sales13; ?></td>
    </tr>
    </table>
    <?php
    }
    
    ?>
	</div>
