<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: albums.php
  Description: Albums

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('INC_FILES')) { exit; }
global $database, 
$msg_albums16, 
$msg_albums17,		
$msg_albums15,	
$msg_albums12,	
$msg_albums10,		
$msg_albums,	
$msg_albums11,	
$msg_header4,		
$msg_albums18,		
$msg_albums19,	
$msg_javascript,	
$msg_albums7,	
$msg_javascript22,		
$msg_albums6,	
$msg_javascript23,	
$msg_albums5,	
$msg_javascript13,	
$msg_javascript12,	
$msg_albums4,	
$msg_albums3,	
$msg_javascript15,	
$msg_script8,	
$msg_albums2,	
$msg_javascript14,	
$msg_script9,		
$page,
$limit,	
$msg_script4,	
$limitvalue,	
$msg_script7,	
$msg_script2,	
$msg_albums9,	
$msg_albums8,	
$msg_script3,
$msg_albums20,
$msg_albums21,
$msg_albums22,
$msg_javascript38,
$msg_javascript39;	

// Are we in edit mode?
if (isset($_GET['id']))
{
  $database->setQuery("SELECT * FROM #__mm_albums 
                         WHERE id = '{$_GET['id']}' 
                         LIMIT 1");
  $database->loadObject($EDIT);
}
?>
  <div id="main">
		<p><b><?php echo $msg_header4; ?></b> &raquo;<br><br>
    <?php echo $msg_albums; ?></p>
    <form method="post" action="index2.php?option=com_maianmusic&section=albums">
    <input type="hidden" name="process" value="1">
    <?php
    if (isset($EDIT))
    {
    ?>
    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
    <?php
    }
    ?>
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo (isset($EDIT) ? $msg_albums10 : $msg_albums2); ?></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td class="formOption" width="30%"><?php echo $msg_albums11; ?></td>
        <td align="left" style="padding:5px" width="70%"><input class="formBox" type="text" name="artist" maxlength="250" size="30" value="<?php echo (isset($EDIT) ? cleanData($EDIT->artist) : ''); ?>"></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_albums3; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="name" maxlength="250" size="30" value="<?php echo (isset($EDIT) ? cleanData($EDIT->name) : ''); ?>"></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_albums16; ?></td>
        <td align="left" style="padding:5px">
        <select name="cat">
        <option value="new"><?php echo $msg_albums17; ?></option>
        <?php
        $database->setQuery("SELECT * FROM #__mm_albums
                                 WHERE parent  = '1' 
                                 AND child     = '0'
                                 ".(isset($EDIT) ? '
                                 AND id        != \''.$EDIT->id.'\'
                                 ' : ''
                                 )."
                                 ORDER BY artist,name");		
        $q_albums = $database->loadObjectList();
        if (count($q_albums) > 0) {
        ?>
        <option disabled="disabled">&nbsp;</option>
        <optgroup label="<?php echo $msg_albums18; ?>">
        <?php        foreach ($q_albums as $ALB) {
        //while ($ALB = $database->loadObject($q_albums)) {
        ?>
        <option value="<?php echo $ALB->id; ?>"<?php echo (isset($EDIT) && $EDIT->child>0 && $EDIT->child==$ALB->id ? ' selected="selected"' : ''); ?>><?php echo cleanData($ALB->artist.' - '.$ALB->name); ?></option>
        <?php
        }
        ?>
        </optgroup>
        <?php
        }
        ?>
        </select>
        </td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_albums5; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="image" maxlength="250" size="30" value="<?php echo (isset($EDIT) ? cleanData($EDIT->image) : 'http://'); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript12); ?></td>
      </tr>
      
      <!-- tr>

        <td class="formOption"><?php echo $msg_albums20; ?></td>
		
        <td align="left" style="padding:5px"><?php echo $msg_albums21; ?> <input class="formBox" type="text" name="dimensions" size="30" style="width:7%" value="<?php echo (isset($EDIT) ? cleanData($EDIT->dimensions_height) : ''); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript38); ?>
		<?php echo $msg_albums22; ?>
		<input class="formBox" type="text" name="dimensions" size="30" style="width:7%" value="<?php echo (isset($EDIT) ? cleanData($EDIT->dimensions_width) : ''); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript39); ?></td>
      </tr-->
      <tr>
        <td class="formOption"><?php echo $msg_albums6; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="artwork" maxlength="250" size="30" value="<?php echo (isset($EDIT) ? cleanData($EDIT->artwork) : 'http://'); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript13); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_albums7; ?><br><br><i>(<?php echo $msg_script4; ?>)</i></td>
        <td align="left" style="padding:5px"><textarea name="comments" rows="5" cols="20"><?php echo (isset($EDIT) ? cleanData($EDIT->comments) : ''); ?></textarea> </td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_albums12; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="keywords" maxlength="250" size="30" value="<?php echo (isset($EDIT) ? cleanData($EDIT->keywords) : ''); ?>"> <?php echo toolTip($msg_javascript,$msg_javascript22); ?></td>
      </tr>
      <tr>
        <td class="formOption"><?php echo $msg_albums19; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="discount" size="30" style="width:7%" value="<?php echo (isset($EDIT) ? cleanData($EDIT->discount) : ''); ?>">% <?php echo toolTip($msg_javascript,$msg_javascript23); ?></td>
      </tr>
      <?php
      if (isset($EDIT))
      {
      ?>
      <tr>
        <td class="formOption"><?php echo $msg_albums15; ?></td>
        <td align="left" style="padding:5px"><input class="formBox" type="text" name="hits" size="30" style="width:10%" value="<?php echo (isset($EDIT) ? cleanData($EDIT->hits) : ''); ?>"> </td>
      </tr>
      <?php
      }
      ?>
      <tr>
        <td class="formOption"><?php echo $msg_albums8; ?></td>
        <td align="left" style="padding:5px"><?php echo $msg_script2; ?> <input type="radio" name="status" value="1"<?php echo (isset($EDIT) && $EDIT->status ? ' checked' : (!isset($EDIT) ? ' checked' : '')); ?>> <?php echo $msg_script3; ?> <input type="radio" name="status" value="0"<?php echo (isset($EDIT) && !$EDIT->status ? ' checked' : ''); ?>> <?php echo toolTip($msg_javascript,$msg_javascript14); ?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="left" style="padding:5px"><input class="formButton" type="submit" value="<?php echo (isset($EDIT) ? $msg_albums10 : $msg_albums2); ?>" title="<?php echo (isset($EDIT) ? $msg_albums10 : $msg_albums2); ?>"> <?php echo (isset($EDIT) ? '&nbsp;&nbsp;&nbsp;&nbsp;<input class="formButton" type="button" value="'.$msg_script9.'" title="'.$msg_script9.'" onclick="window.location=\'index2.php?option=com_maianmusic&section=albums\'">' : ''); ?></td>
      </tr>
      </table>
      </td>
    </tr>
    </table></form><br>
    <?php
    $database->setQuery("SELECT * FROM #__mm_albums 
                             WHERE parent = '1'
                             AND child    = '0'
                             ORDER BY artist,name
                             LIMIT $limitvalue,$limit
                             ");	
    $q_albums =$database->loadObjectList();
    ?>
    <table width="100%" cellspacing="1" cellpadding="0" style="border:1px solid #40ACC7">
    <tr>
      <td class="menuTable">&raquo; <?php echo $msg_albums4; ?> (<?php echo rowCount('albums'); ?>)</td>
    </tr>
    <?php
    if (count($q_albums) > 0)
    {
    ?>
    <tr>
      <td align="left" style="padding:5px;border-top:1px solid #40ABC6">
      <?php       foreach ($q_albums as $ALBUMS) {
      //while ($ALBUMS = $database->loadObject($q_albums)) {
        $database->setQuery("SELECT * FROM #__mm_albums
                                   WHERE parent = '0'
                                   AND child    = '$ALBUMS->id'
                                   ORDER BY artist,name
                                   ");		
       $q_children = $database->loadObjectList();
      ?>
      <table width="100%" cellspacing="0" cellpadding="0" style="border-bottom:1px solid #D9EEF4;border-left:1px solid #D9EEF4;margin-bottom:3px">
      <tr>
        <td class="formOption" width="85%" style="padding:10px 5px 10px 5px"><a href="index2.php?option=com_maianmusic&section=albums&amp;id=<?php echo $ALBUMS->id; ?>" title="<?php echo $msg_script7; ?>"><b><?php echo cleanData($ALBUMS->artist); ?></b> - <?php echo cleanData($ALBUMS->name); ?></a> [<a href="#" onclick="submit_confirm('<?php echo $msg_javascript15; ?>','index2.php?option=com_maianmusic&section=albums&amp;del=<?php echo $ALBUMS->id; ?>');return false" title="<?php echo $msg_script8; ?>"><b style="color:red">X</b></a>]
        <?php
        if (count($q_children)>0) {
        ?>
        <span style="display:block;padding-top:5px">
        <?php          foreach ($q_children as $CHILDREN) {
          //while ($CHILDREN = $database->loadObject($q_children)) {
          ?>
          <span style="font-size:11px"><a href="index2.php?option=com_maianmusic&section=albums&amp;id=<?php echo $CHILDREN->id; ?>" title="<?php echo $msg_script7; ?>" style="color:#40acc7"><?php echo cleanData($CHILDREN->artist); ?> - <?php echo cleanData($CHILDREN->name); ?></a> [<a href="#" onclick="submit_confirm('<?php echo $msg_javascript15; ?>','index2.php?option=com_maianmusic&section=albums&amp;del=<?php echo $CHILDREN->id; ?>');return false" title="<?php echo $msg_script8; ?>"><b style="color:red">X</b></a>]</span>
          <?php
            if (++$count!=count($q_children)) {
              echo ', ';
            }
          }
          ?>
          </span>
          <?php
        }
        ?>
        </td>
      </tr>
      </table>
      <?php
      }
      ?>
      </td>
    </tr>
    <?php
    } else {
    ?>  
    <tr>
      <td align="center" style="padding:10px 0 10px 0;border-top:1px solid #40ABC6"><?php echo $msg_albums9; ?></td>
    </tr>
    <?php
    }
    ?>
    </table>
    <?php
    if (count($q_albums)>0)
    {
      echo admin_page_numbers(rowCount('albums'),$limit,$page);
    }
    ?>
	</div>

