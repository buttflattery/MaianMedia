<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: header.php
  Description: Admin Header

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  exit;
} 
global $msg_login, $msg_header8, $mm_title, $msg_header9, $msg_header4,$msg_header5, $SETTINGS,
		$msg_header6, $msg_header7, $msg_header2, $task, $msg_header3, $msg_header11, $msg_header10, $mainframe;
$cmd= $task;
?><meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><?php echo $mm_title; ?></title>
<link href="components/com_maianmusic/stylesheet.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
    var GB_ROOT_DIR = "<?php echo $mainframe->getCfg('live_site')?>/components/com_maianmusic/greybox/";
</script>
<script type="text/javascript" src="<?php echo $mainframe->getCfg('live_site')?>/components/com_maianmusic/greybox/AJS.js"></script>
<script type="text/javascript" src="<?php echo $mainframe->getCfg('live_site')?>/components/com_maianmusic/greybox/gb_scripts.js"></script>
<script type="text/javascript" src="<?php echo $mainframe->getCfg('live_site')?>/components/com_maianmusic/js/overlib.js"><!-- overLIB (c) Erik Bosrup --></script>
<script type="text/javascript" src="<?php echo $mainframe->getCfg('live_site')?>/components/com_maianmusic/js/js_code.js"></script>
<link href="<?php echo $mainframe->getCfg('live_site')?>/components/com_maianmusic/greybox/gb_styles.css" rel="stylesheet" type="text/css">
<body<?php echo ($cmd=='login' ? ' onload="document.login.user.focus()"' : ''); ?>>
<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>
<div id="top">
  <p><br><b><?php echo $msg_header9; ?></b>:<br /><br />
  <select class="menu" onChange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="index2.php?option=com_maianmusic&section=home" style="padding-left:3px"<?php echo ($cmd=='home' ? ' selected' : ''); ?>><?php echo $msg_header2; ?></option>
  <option value="index2.php?option=com_maianmusic&section=settings" style="padding-left:3px"<?php echo ($cmd=='settings' ? ' selected' : ''); ?>><?php echo $msg_header3; ?></option>
  <option value="index2.php?option=com_maianmusic&section=albums" style="padding-left:3px"<?php echo ($cmd=='albums' ? ' selected' : ''); ?>><?php echo $msg_header4; ?></option>
  <option value="index2.php?option=com_maianmusic&section=add" style="padding-left:3px"<?php echo ($cmd=='add' ? ' selected' : ''); ?>><?php echo $msg_header5; ?></option>
  <option value="index2.php?option=com_maianmusic&section=tracks" style="padding-left:3px"<?php echo ($cmd=='tracks' || $cmd=='view_tracks' ? ' selected' : ''); ?>><?php echo $msg_header6; ?></option>
  <option value="index2.php?option=com_maianmusic&section=sales" style="padding-left:3px"<?php echo ($cmd=='sales' ? ' selected' : ''); ?>><?php echo $msg_header7; ?></option>
  <option value="index2.php?option=com_maianmusic&section=search" style="padding-left:3px"<?php echo ($cmd=='search' ? ' selected' : ''); ?>><?php echo $msg_header8; ?></option>
  <option value="index2.php?option=com_maianmusic&section=stats" style="padding-left:3px"<?php echo ($cmd=='stats' ? ' selected' : ''); ?>><?php echo $msg_header11; ?></option>
  </select></p>
</div>

<div id="maiain_content">
