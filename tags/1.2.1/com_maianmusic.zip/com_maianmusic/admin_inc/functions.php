<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: functions.php
  Description: Program Functions

  ++++++++++++++++++++++++++++++++++++++++*/

//==============================
// Render track data for graph
//==============================

function getTrackDataForGraph($id,$name=false)
{
  global $database;
  $array = array();
  $database->setQuery("SELECT * FROM #__mm_tracks
                           WHERE track_album = '{$id}'
                           ORDER BY track_order") ;  $q_tracks = $database->loadObjectList();
  
  foreach ($q_tracks as $TRACK) {
  //while ($TRACK = mysql_fetch_object($q_tracks)) {
    if (!$name) {
      $database->setQuery("SELECT count(*) AS t_count FROM #__mm_purchases
                                  WHERE item_id = 't".$TRACK->id."'") ;	  $database->loadObject($PURCHASES);
    
      $database->setQuery("SELECT count(*) AS a_count FROM #__mm_purchases
                                   WHERE track_id   = '{$TRACK->id}'") ;	  $database->loadObject($PURCHASES2);
    }
    $array[] = ($name ? cleanData($TRACK->track_name) : $PURCHASES->t_count.';'.$PURCHASES2->a_count);
  }
  return implode(",",$array);
}

//===========================================================
// Get ids for tracks in album and see if purchases exist
//===========================================================

function getTrackPurchasesForAlbum($id)
{
  global $database;
  $count = 0;
  $database->setQuery("SELECT * FROM #__mm_tracks
                           WHERE track_album = '{$id}'
                           ORDER BY track_order") ;
  $q_tracks = $database->loadObjectList();
    foreach ($q_tracks as $TRACK) {
  //while ($TRACK = mysql_fetch_object($q_tracks)) {
    $database->setQuery("SELECT count(*) AS t_count FROM #__mm_purchases
                                WHERE item_id = 't".$TRACK->id."'") ;
    $database->loadObject($PURCHASES);
    $count = $count+$PURCHASES->t_count;
  }
  return $count;
}
function encrypt($data) {
  return (function_exists('sha1') ? sha1($data) : md5($data));
}

//=====================
// Get table count
//=====================

function rowCount($table,$where='')
{
  global $database;
  $database->setQuery("SELECT count(*) AS t_count FROM #__mm_".$table.$where."");
  $database->loadObject($COUNT);
  return $COUNT->t_count;
}

//------------------------------------------------
// Pagination for pages
//------------------------------------------------

function admin_page_numbers($count,$limit,$page,$stringVar='page')
{
  global $SETTINGS,$msg_script5,$msg_script6;
  $PaginateIt = new PaginateIt();
  $PaginateIt->SetCurrentPage($page);
  $PaginateIt->SetItemCount($count);
  $PaginateIt->SetItemsPerPage($limit);
  $PaginateIt->SetLinksToDisplay(50);
  $PaginateIt->SetQueryStringVar($stringVar);
  $PaginateIt->SetLinksFormat('&laquo; '.$msg_script5,
                              ' &bull; ',
                              $msg_script5.' &raquo;');
  return '<div id="page_numbers">'.$PaginateIt->GetPageLinks().'</div>';                            
}

?>
