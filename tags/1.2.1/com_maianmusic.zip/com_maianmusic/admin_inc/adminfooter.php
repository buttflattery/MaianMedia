<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  
  This File: footer.php
  Description: Admin Footer

  ++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  exit;
} 
global $msg_script, $msg_footer, $msg_footer2;

?>
</div>
<div id="footer">
	<p><?php echo $msg_script; ?>. <?php echo $msg_footer; ?> &copy; <?php echo (date("Y")=='2007' ? '2007' : '2007-'.date("Y")); ?> <a href="http://www.maianscriptworld.co.uk/free-php-scripts/maian-music/free-mp3-music-store-system/index.html" title="Maian Script World">Maian Script World</a>. <?php echo $msg_footer2; ?>.</p>	<p>Configured for the joomla by <a href="http://www.AreTimes.com">Are Times</a></p>
</div>
