ALTER TABLE mm_albums ADD COLUMN child INT(5) NOT NULL default '0';
ALTER TABLE mm_albums ADD COLUMN parent ENUM('0','1') NOT NULL default '1';
ALTER TABLE mm_albums ADD COLUMN discount VARCHAR(20) NOT NULL default '0';
