<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: index.php
  Description: Main Parsing File

  +++++++++++++++++++++++++++++++++++++++++++++*/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $mosConfig_live_site, $mosConfig_absolute_path, $mosConfig_lang, $database;

$database->setQuery("SELECT * FROM #__menu WHERE link LIKE 'index.php?option=com_maianmusic' LIMIT 1");
$database->loadObject($menu_link);

// load .class.php and .html.php files for the component
require_once( $mainframe->getPath( 'front_html' ) );
// Set paths/options..
define ('FOLDER_PATH', dirname(__FILE__).'/');
define ('PER_PAGE', 25);
define ('PARENT',1);
// Load include files/classes..
include(FOLDER_PATH.'inc/functions.php');
include(FOLDER_PATH.'classes/class_generic.inc.php');
include(FOLDER_PATH.'classes/PaginateIt.php');
include(FOLDER_PATH.'classes/class_cart.inc.php');
include(FOLDER_PATH.'classes/class_rss.inc.php');
include(FOLDER_PATH.'classes/class_paypal.inc.php');
include(FOLDER_PATH.'classes/class_mail.inc.php');
// For captcha..
$cryptinstall    = "crypt/cryptographp.fct.php";
include $cryptinstall;

// Initialise settings..
global $SETTINGS;

$database->setQuery("SELECT * FROM #__mm_settings LIMIT 1");
$database->loadObject($SETTINGS);

// Load language file..
if($SETTINGS->language != ''){
	include(FOLDER_PATH.'lang/'.$SETTINGS->language); 
}else{
	include(FOLDER_PATH.'lang/english.php'); 
}

// Define variables..
global $mm_title, $page, $error_string, $count, $limit, $limitvalue, $cartID;

$cmd           = trim( mosGetParam( $_REQUEST, 'section', '' ));
$mm_title         = str_replace("{website}",cleanData($SETTINGS->website_name),$msg_public_header);
$page          = (isset($_GET['page']) ? strip_tags($_GET['page']) : '1');
$error_string  = array();
$count         = 0;
$limit         = PER_PAGE;
$limitvalue    = $page * $limit - ($limit); 
$cartID        = session_id();

// Page var check..
if (!ctype_digit($page)) {
  header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&Itemid='.$menu_link->id)."");
  exit;
}
// Initialise classes..
global $MM_MAIL, $MM_CART, $MM_FEED, $MM_PAYPAL;

$MM_MAIL              = new mailClass();
$MM_CART              = new mm_Cart();
$MM_FEED              = new rss_Feed();
$MM_PAYPAL            = new paypalIPN((isset($_POST) ? $_POST : ''),$SETTINGS);
$MM_CART->prefix      = '#__mm_';
$MM_PAYPAL->prefix    = '#__mm_';
$MM_MAIL->smtp        = $SETTINGS->smtp;
$MM_MAIL->smtp_host   = $SETTINGS->smtp_host;
$MM_MAIL->smtp_user   = $SETTINGS->smtp_user;
$MM_MAIL->smtp_pass   = $SETTINGS->smtp_pass;
$MM_MAIL->smtp_port   = $SETTINGS->smtp_port;
$MM_MAIL->addTag('{WEBSITE_NAME}',$SETTINGS->website_name);
$MM_MAIL->addTag('{WEBSITE_URL}',$mosConfig_live_site);
$MM_MAIL->addTag('{WEBSITE_EMAIL}',$SETTINGS->email_address);
// Clear data in cart older than 14 days thats not been used..
clearDeadData();

if($cmd != 'rss'){
	$mainframe->setPageTitle(str_replace("{website}",cleanData($SETTINGS->website_name),$msg_public_header));

	$mainframe->addCustomHeadTag('<script type="text/javascript"> /*<![CDATA[*/
 	var GB_ROOT_DIR = "components/com_maianmusic/greybox/"; /*]]>*/
 	</script>');
	$mainframe->addCustomHeadTag( '<script type="text/javascript" src="'.$mosConfig_live_site.'/components/com_maianmusic/greybox/AJS.js"></script>' );
	$mainframe->addCustomHeadTag( '<script type="text/javascript" src="'.$mosConfig_live_site.'/components/com_maianmusic/greybox/gb_scripts.js"></script>' );
	$mainframe->addCustomHeadTag( '<script type="text/javascript" src="'.$mosConfig_live_site.'/components/com_maianmusic/js/js_code.js"></script>' );

	if(genericOptions::get_browser_type() == 'IE'){
		$mainframe->addCustomHeadTag( '<link rel="stylesheet" type="text/css" href="'.$mosConfig_live_site.'/components/com_maianmusic/templates/mm_stylesheet.css"/>' );
	}else{
	$mainframe->addCustomHeadTag('<link href="'.$mosConfig_live_site.'/components/com_maianmusic/templates/mm_stylesheet.css" rel="stylesheet" type="text/css" />');
	}

	$mainframe->addCustomHeadTag( '<link href="'.$mosConfig_live_site.'/components/com_maianmusic/greybox/gb_styles.css" rel="stylesheet" type="text/css" />' );
	$mainframe->addCustomHeadTag('<link rel="alternate" type="application/rss+xml" title="RSS" href="index.php?option=com_maianmusic&section=rss" />');
}


// Main switch..
switch ($cmd)
{
  // Homepage..
  case 'home':
  $p_tracks  = '';
  $p_albums  = '';
  // Get most popular albums..
  $database->setQuery("SELECT * FROM #__mm_albums
                               ORDER BY downloads DESC
                               LIMIT $SETTINGS->poplinks") ;
  $q_pop_albums = $database->loadObjectList();
  if (count($q_pop_albums)>0) {
    foreach($q_pop_albums as $P_ALBUMS){

      $p_albums .= str_replace(array('{url}','{name}','{artist}'),
                               array(
                               sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$P_ALBUMS->id),
                               cleanData($P_ALBUMS->name),
                               cleanData($P_ALBUMS->artist)
                               ),
                               file_get_contents(FOLDER_PATH.'templates/tpl_files/li_tag.html')
                               );
    }
  }
  // Get most popular tracks..
  $database->setQuery("SELECT *,#__mm_albums.id AS i_id 
                               FROM #__mm_tracks
                               LEFT JOIN #__mm_albums
                               ON #__mm_tracks.track_album = #__mm_albums.id
                               ORDER BY #__mm_tracks.downloads DESC
                               LIMIT $SETTINGS->poplinks
                               ");
  $q_pop_tracks = $database->loadObjectList();
  if (count($q_pop_tracks)>0) {  	 
  	foreach($q_pop_tracks as $P_TRACKS){
    //while ($P_TRACKS = mysql_fetch_object($q_pop_tracks)) {
      $p_tracks .= str_replace(array('{url}','{name}','{artist}'),
                               array(
                               sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$P_TRACKS->i_id),
                               cleanData($P_TRACKS->track_name),
                               cleanData($P_TRACKS->artist)
                               ),
                               file_get_contents(FOLDER_PATH.'templates/tpl_files/li_tag.html')
                               );
    }
  }	
  
    $tplDisplayHome = array();
  	$tplDisplayHome['HOME_TEXT'] = cleanData($SETTINGS->website_name);
  	//$tplDisplayHome['HOME_MESSAGE'] = $msg_publichome;
  	$tplDisplayHome['HOME_MESSAGE'] = str_replace('\"','"',$SETTINGS->about);
  	$tplDisplayHome['PAYPAL_MESSAGE'] = $msg_publichome2;
  	$tplDisplayHome['MOST_POPULAR_TRACKS'] = $SETTINGS->poplinks.' '.$msg_publichome3;
 	$tplDisplayHome['MOST_POPULAR_ALBUMS'] = $SETTINGS->poplinks.' '.$msg_publichome4;
  	$tplDisplayHome['MOST_POPULAR_TRACKS_LIST'] = $p_tracks;
  	$tplDisplayHome['MOST_POPULAR_ALBUMS_LIST'] = $p_albums;
  
  HTML_maiainFront::show_MainPage($tplDisplayHome);

  break;
  // Music..
  case 'music':
  $mData = '';
  // Get music/album data..
   $database->setQuery("SELECT * FROM #__mm_albums 
                          WHERE status = '1'
                          AND parent   = '1'
                          ORDER BY artist,name
                          LIMIT $limitvalue,$limit") ;
    $q_music = $database->loadObjectList();
        foreach($q_music as $MUSIC){	
    $image_link = $mosConfig_live_site.'/components/com_maianmusic/images/no_picture.png';
    $more_info_image = $mosConfig_live_site.'/components/com_maianmusic/images/more_info.png';
    $images_dimensions = '';
    	
    if($MUSIC->image != "" && $MUSIC->image !="http://"){
    	$image_link = $MUSIC->image;
    	$images_dimensions = 'height=75px width=75px';
    }
    
    $find     = array('{url}','{more_info_image}','{dimensions}','{album_image}','{more_info}','{artist}','{album_title}','{tracks}');
    $replace  = array(sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$MUSIC->id),
    					$more_info_image,$images_dimensions, $image_link,$msg_music2,cleanData($MUSIC->artist),cleanData($MUSIC->name),str_replace("{count}",getTrackCount($MUSIC->id),$msg_music3));
    $mData .= str_replace($find,$replace,
                          file_get_contents(FOLDER_PATH.'templates/tpl_files/album_data.html')
                          );
  }
  $title = $title.' - '.$msg_public_header4;
  $tplDisplayData = array();
  $tplDisplayData['MUSIC_TEXT']=$SETTINGS->music;
  $tplDisplayData['MUSIC_MESSAGE']=$msg_music;
  $tplDisplayData['MUSIC_DATA']= $mData;
  $tplDisplayData['PAGE_NUMBERS']= (count($q_music)>0 ? page_numbers(getTableRowCount('albums','WHERE status = \'1\' AND parent   = \'1\''),$limit,$page) : '');
  
  HTML_maiainFront::show_MusicPage($tplDisplayData);
  
  break;
  // Contact..
  case 'contact':
  if (isset($_POST['process'])) {
    // Apply call back element to trim post vars..
    $_POST = array_map('trim',$_POST);
    if (isset($_POST['send'])) {
      if ($_POST['name']=='') {
        $N_ERROR = true;
        $count++;
      }
      if (!eregi("^([a-z]|[0-9]|\.|-|_)+@([a-z]|[0-9]|\.|-|_)+\.([a-z]|[0-9]){2,4}$", $_POST['email'])) {
        $E_ERROR = true;
        $count++;
      }
      if ($_POST['subject']=='') { 
        $S_ERROR = true;
        $count++;
      }
      if ($_POST['comments']=='') {
        $C_ERROR = true;
        $count++;
      }
      if ($SETTINGS->enable_captcha && isset($_POST['code'])) {
        if (!chk_crypt($_POST['code'])) {
         $SUM_ERROR = true;
         $count++;
        }
      }
               
      if ($count==0) {
        $MM_MAIL->addTag('{NAME}',cleanEvilTags($_POST['name'],true));
        $MM_MAIL->addTag('{EMAIL}',$_POST['email']);
        $MM_MAIL->addTag('{COMMENTS}',cleanEvilTags($_POST['comments'],true));
        $MM_MAIL->addTag('{IP}',$_SERVER['REMOTE_ADDR']);
        // Send to webmaster..
        $MM_MAIL->sendMail($SETTINGS->website_name,
                           $SETTINGS->email_address,
                           $SETTINGS->website_name,
                           $SETTINGS->email_address,
                           '['.$SETTINGS->website_name.'] '.cleanEvilTags($_POST['subject'],true),
                           $MM_MAIL->template(FOLDER_PATH.'templates/email/contact_message.txt'));
        // Send auto responder..
        $MM_MAIL->sendMail($_POST['name'],
                           $_POST['email'],
                           $SETTINGS->website_name,
                           $SETTINGS->email_address,
                           '['.$SETTINGS->website_name.'] re:'.cleanEvilTags($_POST['subject'],true),
                           $MM_MAIL->template(FOLDER_PATH.'templates/email/contact_auto.txt'));                 
        $SENT = true; 
      }                   
    }
  }
  $title = $title.' - '.$msg_contact2;
  $tplDisplayData = array();
    $tplDisplayData['CONTACT_MESSAGE'] = (isset($SENT) ? $msg_contact8 : $msg_contact);
    $tplDisplayData['FORM_TEXT'] = (isset($SENT) ? $msg_contact13 : $msg_contact2);
    $tplDisplayData['FORM_DISPLAY'] = (isset($SENT) ? ' style="display:none"' : '');
    $tplDisplayData['NAME_TEXT'] = $msg_contact9;
    $tplDisplayData['EMAIL_TEXT'] = $msg_contact10;
    $tplDisplayData['SUBJECT_TEXT'] = $msg_contact3;
    $tplDisplayData['C_URL'] = sefRelToAbs('index.php?option=com_maianmusic&section=contact');
    $tplDisplayData['COMMENT_TEXT'] = $msg_contact4;
    $tplDisplayData['NAME_VALUE'] = (isset($_POST['name']) ? cleanData($_POST['name']) : '');
    $tplDisplayData['EMAIL_VALUE'] = (isset($_POST['email']) ? cleanData($_POST['email']) : '');
    $tplDisplayData['SUBJECT_VALUE'] = (isset($_POST['subject']) ? cleanData($_POST['subject']) : '');
    $tplDisplayData['COMMENT_VALUE'] = (isset($_POST['comments']) ? cleanData($_POST['comments']) : '');
    $tplDisplayData['CAPTCHA'] =showCaptcha($msg_contact11,(isset($SUM_ERROR) ? '<br /><span class="error">'.$msg_contact12.'</span>' : ''));
    $tplDisplayData['N_ERROR'] = (isset($N_ERROR) ? '<br /><span class="error">'.$msg_contact15.'</span>' : '');
    $tplDisplayData['E_ERROR'] = (isset($E_ERROR) ? '<br /><span class="error">'.$msg_contact16.'</span>' : '');
    $tplDisplayData['S_ERROR'] = (isset($S_ERROR) ? '<br /><span class="error">'.$msg_contact6.'</span>' : '');
    $tplDisplayData['C_ERROR'] = (isset($C_ERROR) ? '<br /><span class="error">'.$msg_contact7.'</span>' : '');
    $tplDisplayData['SEND_TEXT'] = $msg_contact5;
    
    HTML_maiainFront::show_ContactPage($tplDisplayData);
  break;
  
  // About..
  case 'about':
  $title = $title.' - '.$msg_public_header6;
  $tplDisplayData = array();
  $tplDisplayData['ABOUT_TEXT'] = $msg_public_header6;
  $tplDisplayData['ABOUT'] = nl2br(cleanData($SETTINGS->about));
  
  HTML_maiainFront::show_AboutPage($tplDisplayData);
  break;
  
  // Licence..
  case 'licence':
  $title = $title.' - '.$msg_public_header12;
  $tplDisplayData = array();
  $tplDisplayData['LICENCE_TEXT'] = $msg_public_header12;
  $tplDisplayData['LICENCE'] = nl2br(cleanData($SETTINGS->licence));  
  HTML_maiainFront::show_LicencePage($tplDisplayData);
  
  break;
  
  // Search..
  case 'search':
  $title  = $title.' - '.$msg_public_header7;
  $sql    = '';
  $sData  = '';
  // Search database..
  if (!isset($_GET['keywords'])) {
    header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&Itemid='.$menu_link->id)."");
    exit;
  }
  // Split keywords and trim whitespace..
  $keys = array_map('trim',explode(" ", cleanEvilTags($_GET['keywords'])));
  // Loop through keywords...
  for ($i=0; $i<count($keys); $i++) {
    $sql .= ($i ? 'OR ' : 'WHERE ')."artist LIKE '%".mysql_real_escape_string($keys[$i])."%' OR name LIKE '%".mysql_real_escape_string($keys[$i])."%' OR keywords LIKE '%".mysql_real_escape_string($keys[$i])."%'";
  }
  // Query database..
  $database->setQuery("SELECT * FROM #__mm_albums $sql
                          LIMIT $limitvalue,$limit") ;
  $q_music =  $database->loadObjectList();                       
   
  if (count($q_music)>0 && $keys) {
  	  	
  foreach($q_music as $MUSIC){
  	
  	$image_link = $mosConfig_live_site.'/components/com_maianmusic/images/no_picture.png';
    $more_info_image = $mosConfig_live_site.'/components/com_maianmusic/images/more_info.png';
    $images_dimensions = '';
    	
    if($MUSIC->image != ""){
    	$image_link = $MUSIC->image;
    	$images_dimensions = 'height=75px width=75px';
    }
      //$find     = array('{url}','{more_info}','{artist}','{album_title}','{tracks}');
      //$replace  = array(sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$MUSIC->id),$msg_music2,cleanData($MUSIC->artist),cleanData($MUSIC->name),str_replace("{count}",getTrackCount($MUSIC->id),$msg_music3));
    $find     = array('{url}','{more_info_image}','{dimensions}','{album_image}','{more_info}','{artist}','{album_title}','{tracks}');
    $replace  = array(sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$MUSIC->id),
    					$more_info_image,$images_dimensions, $image_link,$msg_music2,cleanData($MUSIC->artist),cleanData($MUSIC->name),str_replace("{count}",getTrackCount($MUSIC->id),$msg_music3));  
  	$sData .= str_replace($find,$replace,
                            file_get_contents(FOLDER_PATH.'templates/tpl_files/album_data.html')
                            );
    }
  } else {
    $sData = str_replace("{message}",$msg_publicsearch3,file_get_contents(FOLDER_PATH.'templates/tpl_files/message.html'));
  }
  $tplDisplayData = array();
  $tplDisplayData['SEARCH_TEXT'] =  $msg_publicsearch;
  $tplDisplayData['SEARCH_MESSAGE'] =  str_replace("{keywords}",cleanEvilTags($_GET['keywords']),$msg_publicsearch2);
  $tplDisplayData['SEARCH_DATA'] =  $sData;
  $tplDisplayData['PAGE_NUMBERS'] =  (count($q_music)>0 && $keys ? page_numbers(getTableRowCount('albums',$sql),$limit,$page) : '');  HTML_maiainFront::show_SearchPage($tplDisplayData);
  
  break;
  // Albums..
  case 'album':
  $aData = '';
  // Assign id based on url...
  $id = (isset($_GET['album']) ? strip_tags($_GET['album']) : '');
  // Security check..
  if (!ctype_digit($id)) {
    header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&Itemid='.$menu_link->id)."");
    exit;
  }
  // Get album data...
  $database->setQuery("SELECT * FROM #__mm_albums 
                        WHERE id = '{$id}' 
                        LIMIT 1") ;  $database->loadObject($ALBUM);	                     $q_album = $database->loadObjectList();
  // Row check..
  if (count($q_album)==0) {
    header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&Itemid='.$menu_link->id)."");
    exit;
  }
  // Get tracks.. 
  $database->setQuery("SELECT * FROM #__mm_tracks 
                           WHERE track_album = '{$ALBUM->id}' 
                           ORDER BY track_order") ;  $q_tracks = $database->loadObjectList();
    foreach($q_tracks as $TRACKS) {
    $intNumber = $intNumber + 1;
    $altRow = '';
    if ($intNumber % 2 == 0 )
	{
		$altRow = 'class = "alt_row"';
	}
    	$single = 'N/A';
    // Is single track purchasable?
    if ($TRACKS->track_single) {
      $single = str_replace('{id}',$TRACKS->id,
                            file_get_contents(FOLDER_PATH.'templates/tpl_files/add_to_cart.html'));
    }	
    $tracklength;
    if($TRACKS->track_length != ""){
    	$tracklength = "(".$TRACKS->track_length.")";
    }
    
    include_once($mainframe->getCfg('absolute_path').'/components/com_maianmusic/players/mp3players.php');
    
    $find     = array('{flash_player}','{title}','{alt_row}','({duration})','{cost}','{add_to_cart}');
    $replace  = array('<!-- Begin Flash Player -->'.mp3players::getplayer($SETTINGS->player, ($TRACKS->preview_path ? $SETTINGS->preview_path.'/'.$TRACKS->preview_path : $SETTINGS->mp3_path.'/'.$TRACKS->mp3_path), $SETTINGS->player, ++$count).'<!-- End Flash Player -->',
    					cleanData($TRACKS->track_name), $altRow,
    					$TRACKS->track_length,get_cur_symbol($TRACKS->track_cost, $SETTINGS->paypal_currency),
    					$single);
    $aData .= str_replace($find,$replace,
                          file_get_contents(FOLDER_PATH.'templates/tpl_files/tracks.html'));
  }
  // Update hits..
  $database->setQuery("UPDATE #__mm_albums SET 
               hits      = (hits+1)
               WHERE id  = '{$ALBUM->id}'
               LIMIT 1") ;
  $database->query();
  $title = $title.' - '.cleanData($ALBUM->artist).' - '.cleanData($ALBUM->name);
  // Children..
  // New in v1.2..
  $children = '';
  $links    = '';
  $database->setQuery("SELECT * FROM #__mm_albums
                             ".($ALBUM->parent>0 ? '
                             WHERE parent = \'0\'
                             AND child    = \''.$ALBUM->id.'\'
                             ' : '
                             WHERE parent = \''.$ALBUM->child.'\'
                             OR child     = \''.$ALBUM->child.'\'
                             AND id       != \''.$ALBUM->id.'\'
                             ')
                             ."
                             ORDER BY artist,name
                             ") ;  $q_children = $database->loadObjectList();
  
  if (count($q_children)>0) {
  	foreach($q_children as $CHILDREN){
      $links .= '<span class="child"><a href="'.sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$CHILDREN->id).'" title="'.cleanData($CHILDREN->artist).' - '.cleanData($CHILDREN->name).'">'.cleanData($CHILDREN->artist).' - '.cleanData($CHILDREN->name).'</a></span>';
    }
    $find     = array('{related_albums}','{children}');
    $replace  = array($msg_publicalbum14,$links);
    $children = str_replace($find,$replace,
                            file_get_contents(FOLDER_PATH.'templates/tpl_files/children.html'));
  }
  // Set keywords..
  $meta_keys = cleanData($ALBUM->keywords);
 $tplDisplayData = array();
 
  $tplDisplayData['ALBUM_TEXT'] = $msg_publicalbum;
  $tplDisplayData['ALBUM_MESSAGE'] = ($ALBUM->comments ? cleanData($ALBUM->comments) : $msg_publicalbum2);
  $tplDisplayData['IMG_INLINE_STYLE'] =  (strlen($ALBUM->image)>7 ? '<img height="95px" width="95px" src="'.$ALBUM->image.'"></img>' : '');
  //$tplDisplayData['IMG_INLINE_STYLE'] = (strlen($ALBUM->image)>7 ? ' style="background: url(\''.$ALBUM->image.'\') no-repeat center right"' : '');
  $tplDisplayData['ARTIST'] = cleanData($ALBUM->artist);
  $tplDisplayData['TRACK_NAME'] = $msg_publicalbum5;
  $tplDisplayData['TRACK_COST'] = $msg_publicalbum6;
  $tplDisplayData['TRACK_OPTIONS'] = $msg_publicalbum3;
  $tplDisplayData['CHILDREN'] =  $children;
  $tplDisplayData['NAME'] = cleanData($ALBUM->name);
  $tplDisplayData['ADD_ALL'] = $msg_publicalbum8;
  $tplDisplayData['ALBUM_DATA'] =  $aData;
  $tplDisplayData['ADD_URL'] =  sefRelToAbs( $mosConfig_live_site.'/index.php?option=com_maianmusic&section=cart&amp;album='.$ALBUM->id);
  $tplDisplayData['PREV_URL'] =  sefRelToAbs('index.php?option=com_maianmusic&section=preview-tracks&amp;album='.$ALBUM->id);
  $tplDisplayData['CANCEL'] = $msg_script9;
  $tplDisplayData['PREVIEW'] = $msg_publicalbum10;
  $tplDisplayData['ALBUM_ID'] =  $ALBUM->id;
  $tplDisplayData['DISCOUNT'] =  ($ALBUM->discount>0 ? ' - '.str_replace("{amount}",$ALBUM->discount,$msg_publicalbum13) : '');
  $tplDisplayData['FORM_ACTION'] = sefRelToAbs('index.php?option=com_maianmusic&section=cart');
  $tplDisplayData['ADD_TO_CART'] = $msg_publicalbum9;
  $tplDisplayData['URL'] = sefRelToAbs('index.php?option=com_maianmusic&section=music');
  $tplDisplayData['HITS'] = str_replace("{count}",number_format($ALBUM->hits),$msg_publicalbum12);	
  HTML_maiainFront::show_AlbumPage($tplDisplayData);
  break;
  
  // Cart..
  case 'cart':
  if (isset($_GET['album'])) {
    if (!ctype_digit($_GET['album'])) {
      header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&Itemid='.$menu_link->id)."");
      exit;
    }
    // Add album to cart...
    $MM_CART->addToCart(true,$_GET['album'],0,$msg_cart9);
  } else {
    if (!isset($_POST)) {
      header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&Itemid='.$menu_link->id)."");
      exit;
    }
    // Add selected tracks to cart.. 
    if (isset($_POST['process'])) {
      // If no boxes were checked, do nothing..
      if (!empty($_POST['track'])) {
        // Loop through checkboxes..
        for ($i=0; $i<count($_POST['track']); $i++) {
          // Only assign tracks that were checked..
          if (isset($_POST['track'][$i])) {
            $MM_CART->addToCart(false,0,$_POST['track'][$i],$msg_cart9);
          }
        }
      }
    }
  }
  // Get album data and refresh page..
  // If invalid id var, go back to homepage..
  $database->setQuery("SELECT * FROM #__mm_albums 
                          WHERE id = '".(int)(isset($_POST['album']) ? $_POST['album'] : $_GET['album'])."' 
                          LIMIT 1") ;
  $q_album = $database->loadObjectList();
  $database->loadObject($ALBUM);

  if (count($q_album)==0) {
    header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&Itemid='.$menu_link->id)."");
    exit;
  } else {
    header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&section=album&album='.$ALBUM->id.'&Itemid='.$menu_link->id)."");
    //header("Location: ".sefRelToAbs('mp3-download/'.$ALBUM->id.'/'.addTitleToUrl(cleanData($ALBUM->artist)).'/'.addTitleToUrl(cleanData($ALBUM->name))."");
    
  }
  break;
  case 'clear-cart':
  $MM_CART->clearCart();
  header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&section=view-cart&Itemid='.$menu_link->id)."");
  break;
  case 'delete-item':
  if (!ctype_alnum($_GET['item'])) {
    header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&Itemid='.$menu_link->id)."");
    exit;
  }
  $MM_CART->deleteCartItem($_GET['item']);
  header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&section=view-cart&Itemid='.$menu_link->id)."");
  break;
  // View Cart..
  case 'view-cart':
  
  $title     = $title.' - '.$msg_cart;
  $cData     = '';
  $cButtons  = '';
  // Get cart data..
  if ($MM_CART->cartCount()>0) {
    // Cart header..
    $cData = str_replace('{item_name}',str_replace("{count}",$MM_CART->cartCount(),$msg_cart4),file_get_contents(FOLDER_PATH.'templates/tpl_files/cart_items_header.html'));
    // Cart data..
    for ($i=0; $i<count($_SESSION['album_name']); $i++) {
      
    	// Assign album data if track..
      if (isset($_SESSION['track_id'][$i]) && $_SESSION['track_id'][$i]>0) {
        $ADATA = getAlbumData($_SESSION['track_id'][$i]);
      }
      // Check key exists..prevents offset errors..
      // None should exist. but good practice to check..
      if (isset($_SESSION['track_id'][$i])) {
        // If track and album id are empty, this is a deleted item, so don`t show it..
        if ($_SESSION['track_id'][$i]>0 || $_SESSION['album_id'][$i]>0) {
          $cData .= str_replace(array('{item_name}','{cost}','{delete_url}','{delete_this_item}','{are_you_sure}'),
                                array(
                                cleanData(($_SESSION['album_name'][$i] ? $_SESSION['album_name'][$i] : $_SESSION['track_name'][$i])).($_SESSION['track_name'][$i] ? '<br /><span class="from_album">'.$msg_cart8.' <a href="'.sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$ADATA->id).'" title="'.cleanData($ADATA->artist).' - '.cleanData($ADATA->name).'">'.cleanData($ADATA->artist).' - '.cleanData($ADATA->name).'</a></span>' : ''),
                                get_cur_symbol(($_SESSION['track_cost'][$i] ? $_SESSION['track_cost'][$i] : $_SESSION['album_cost'][$i]),$SETTINGS->paypal_currency),
                                sefRelToAbs('index.php?option=com_maianmusic&section=delete-item&item='.$_SESSION['entry_code'][$i]),
                                $msg_javascript26,
                                $msg_javascript26
                                ),
                                file_get_contents(FOLDER_PATH.'templates/tpl_files/cart_item.html')
                                );
        }
      }
    }
    // Cart total..
    $cData .= str_replace("{cart_total}",$msg_cart5.': '.get_cur_symbol($MM_CART->cartTotal(),$SETTINGS->paypal_currency),
                          file_get_contents(FOLDER_PATH.'templates/tpl_files/cart_total.html'));
    // Cart buttons..
    $cButtons = str_replace(array('{clear_url}','{are_you_sure}','{clear}','{checkout_url}','{checkout}'),
                            array(
                            sefRelToAbs('index.php?option=com_maianmusic&section=clear-cart'),
                            $msg_javascript25,
                            $msg_cart6,
                            sefRelToAbs('index.php?option=com_maianmusic&section=checkout'),
                            $msg_cart7
                            ),
                            file_get_contents(FOLDER_PATH.'templates/tpl_files/cart_buttons.html')
                            );
  } else {
    $cData = str_replace('{text}',$msg_cart3,file_get_contents(FOLDER_PATH.'templates/tpl_files/empty_cart.html'));
  }
  $tplDisplayData = array();
  
  $tplDisplayData['CART_TEXT'] = $msg_cart;
  $tplDisplayData['CART_MESSAGE'] = $msg_cart2;
  $tplDisplayData['CART_DATA'] = $cData;
  $tplDisplayData['CART_BUTTONS'] = $cButtons;  
  HTML_maiainFront::show_CartPage($tplDisplayData);
  break;
  // Checkout..
  case 'checkout':
  // Add paypal fields...
  $MM_PAYPAL->add_field('rm','2');
  $MM_PAYPAL->add_field('cmd','_xclick');
  $MM_PAYPAL->add_field('business',$SETTINGS->paypal_email);
  $MM_PAYPAL->add_field('item_name',$msg_paypal2);
  $MM_PAYPAL->add_field('quantity','1');
  $MM_PAYPAL->add_field('notify_url','http'.($SETTINGS->ssl_enabled ? 's' : '').'://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?option=com_maianmusic&section=notify');
  $MM_PAYPAL->add_field('cancel_return','http'.($SETTINGS->ssl_enabled ? 's' : '').'://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?option=com_maianmusic&section=cancel');
  $MM_PAYPAL->add_field('return','http'.($SETTINGS->ssl_enabled ? 's' : '').'://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?option=com_maianmusic&section=thanks');
  // Only show page style field if one is set, otherwise paypal throws an error..
  if ($SETTINGS->page_style) {
    $MM_PAYPAL->add_field('page_style',$SETTINGS->page_style);
  }

  $MM_PAYPAL->add_field('invoice','INV-'.time().'-'.rand(1111,9999));
  $MM_PAYPAL->add_field('amount',$MM_CART->cartTotal());
  $MM_PAYPAL->add_field('currency_code',$SETTINGS->paypal_currency);
  $MM_PAYPAL->add_field('custom',$cartID.'-mswmusic');
  // Log data in database..
  $MM_CART->addCartToDatabase($cartID, $MM_CART->cartTotal());
  // Kill session data..
  $MM_CART->clearCart();
  // Set var for form submission..
  $cartOnLoad = true;
  $tplDisplayData = array();
  $tplDisplayData['CONNECTING'] =  $msg_paypal;
  $tplDisplayData['PAYPAL_FORM_FIELDS'] =  $MM_PAYPAL->loadHiddenFields();

  HTML_maiainFront::show_CheckoutPage($tplDisplayData);
  break;
  // Paypal..
  case 'notify':
  case 'thanks':
  case 'cancel':
  case 'invalid':
  
  if(empty($_POST)){
  	$tx = $_GET['tx'];
  	$_POST = $MM_PAYPAL->send_pdt($tx,$SETTINGS->pdt);
  }
  /*Notify Testing
  $MM_MAIL->sendMail($SETTINGS->website_name,
                         $SETTINGS->email_address,
                         $SETTINGS->website_name,
                         $SETTINGS->email_address,
                         '['.$SETTINGS->website_name.'] Testing Notify',
                         '$_POST[custom] = '.$_POST['custom'].'$_POST[payment_status] = '.$_POST['payment_status'].'$_POST[mc_gross] = '.$_POST['mc_gross']); 
  */
  switch ($cmd)
  {
    case 'notify':
    // Get paypal response..
    $MM_PAYPAL->send_response();
    /*Notify Testing
    $MM_MAIL->sendMail($SETTINGS->website_name,
                         $SETTINGS->email_address,
                         $SETTINGS->website_name,
                         $SETTINGS->email_address,
                         '['.$SETTINGS->website_name.'] Testing Notify',
                         '$_POST[custom] = '.$_POST['custom'].'$MM_PAYPAL->is_verified() = '.$MM_PAYPAL->is_verified()); 
    */
    // Validate response from Paypal website..
    if(!$MM_PAYPAL->is_verified()) {
      $MM_PAYPAL->error_out($msg_ipn,$msg_ipn2,$msg_ipn3,$msg_ipn4,
                            $SETTINGS->log_errors);
      $MM_MAIL->sendMail($SETTINGS->website_name,
                         $SETTINGS->email_address,
                         $SETTINGS->website_name,
                         $SETTINGS->email_address,
                         '['.$SETTINGS->website_name.'] '.$msg_ipn9,
                         $MM_MAIL->template(FOLDER_PATH.'templates/email/paypal_invalid.txt')); 
      exit;                                         
    }
    // Explode custom var field..
    // The first slot will hold the cart code, thats all we need..
    $tx = $_GET['tx'];
    //$_POST = $MM_PAYPAL->send_pdt($tx,$SETTINGS->pdt);
    //$returnVal = $MM_PAYPAL->paypal_post_vars;
    
    
    $DATA = explode("-", $_POST['custom']);
    // Get current data..
    $cartData = $MM_CART->getCartData($DATA[0]);
    
    /*Notify Testing
    $MM_MAIL->sendMail($SETTINGS->website_name,
                         $SETTINGS->email_address,
                         $SETTINGS->website_name,
                         $SETTINGS->email_address,
                         '['.$SETTINGS->website_name.'] Testing Notify',
                         '$_POST[custom] = '.$_POST['mc_gross'].' $DATA[0] = '.$DATA[0].' $cartData->total = '.$cartData->total.' $_POST[mc_gross] = '.$_POST['mc_gross']); 
    */
    
    // Check call isn`t coming from another script..
    if (!isset($_POST['custom']) || strpos($_POST['custom'],'mswmusic')===FALSE) {
      exit;
    }
    // E-mail vars..
    $MM_MAIL->addTag('{NAME}',$_POST['first_name'].' '.$_POST['last_name']);
    $MM_MAIL->addTag('{INVOICE}',$_POST['invoice']);
    $MM_MAIL->addTag('{TRANS_ID}',$_POST['txn_id']);
    $MM_MAIL->addTag('{TOTAL}',$_POST['mc_gross']);
    $MM_MAIL->addTag('{DOWNLOAD_LINK}',sefRelToAbs('index.php?option=com_maianmusic&section=download&code='.$cartData->download_code));
    // Process based on payment status..
    switch($MM_PAYPAL->get_payment_status()) {
      case 'Completed':
      // Firstly, lets make sure this isn`t a fraudulent transaction..
      // If it is, do nothing else..
      if (($_POST['mc_gross']==$cartData->total) && $MM_CART->checkForDuplicates($DATA[0], $cartData->download_code)){
        
      	// Update database info..
        $MM_CART->updateCartDatabase($DATA[0],$_POST, $cartData->download_code);
        // Log purchase data..
        $MM_CART->generatePurchasesForDownload($DATA[0]);
        // Additional tags for tracks/albums purchased..
        $MM_MAIL->addTag('{ALBUMS}',$MM_CART->purchasedItems('albums',$DATA[0],$msg_cart8));
        $MM_MAIL->addTag('{TRACKS}',$MM_CART->purchasedItems('tracks',$DATA[0],$msg_cart8));
        // Send mail to buyer..
        $MM_MAIL->sendMail($_POST['first_name'].' '.$_POST['last_name'],
                           $_POST['payer_email'],
                           $SETTINGS->website_name,
                           $SETTINGS->email_address,
                           '['.$SETTINGS->website_name.'] '.$msg_ipn10,
                           $MM_MAIL->template(FOLDER_PATH.'templates/email/paypal_thanks.txt'));
        // Send mail to webmaster..
        $MM_MAIL->sendMail($SETTINGS->website_name,
                           $SETTINGS->email_address,
                           $SETTINGS->website_name,
                           $SETTINGS->email_address,
                           '['.$SETTINGS->website_name.'] '.$msg_ipn11.'IPN',
                           $MM_MAIL->template(FOLDER_PATH.'templates/email/paypal_notify.txt'));
      }
      exit;
      
      break;
      
      case 'Pending':
      // Send mail to buyer..
      $MM_MAIL->sendMail($_POST['first_name'].' '.$_POST['last_name'],
                         $_POST['payer_email'],
                         $SETTINGS->website_name,
                         $SETTINGS->email_address,
                         '['.$SETTINGS->website_name.'] '.$msg_ipn8,
                         $MM_MAIL->template(FOLDER_PATH.'templates/email/paypal_pending_auto.txt'));
      // Send mail to webmaster..
      $MM_MAIL->sendMail($SETTINGS->website_name,
                         $SETTINGS->email_address,
                         $SETTINGS->website_name,
                         $SETTINGS->email_address,
                         '['.$SETTINGS->website_name.'] '.$msg_ipn8,
                         $MM_MAIL->template(FOLDER_PATH.'templates/email/paypal_pending.txt'));                    
      break;
      case 'Failed':
      $MM_PAYPAL->error_out($msg_ipn5,$msg_ipn2,$msg_ipn3,$msg_ipn4,
                            $SETTINGS->log_errors);
      $invalid = true;                      
      break;
      case 'Denied':
      $MM_PAYPAL->error_out($msg_ipn6,$msg_ipn2,$msg_ipn3,$msg_ipn4,
                            $SETTINGS->log_errors
                            );
      $invalid = true;                        
	    break;
      case 'Refunded':
      break;
      default:
	    $MM_PAYPAL->error_out($msg_ipn7.': '.$MM_PAYPAL->get_payment_status(),$msg_ipn2,$msg_ipn3,$msg_ipn4,
                            $SETTINGS->log_errors
                            );
      $invalid = true;                        
      break;
    }
    
    // Send e-mail to webmaster if problem occured..
    if (isset($invalid)) {
      $MM_MAIL->sendMail($SETTINGS->website_name,
                         $SETTINGS->email_address,
                         $SETTINGS->website_name,
                         $SETTINGS->email_address,
                         '['.$SETTINGS->website_name.'] '.$msg_ipn9,
                         $MM_MAIL->template(FOLDER_PATH.'templates/email/paypal_invalid.txt')); 
    }
    break;
    case 'thanks':
    // Post data present..	
    	
    if (!isset($_POST)) {
      header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&Itemid='.$menu_link->id)."");
      exit;
    }
    

    $tx = $_GET['tx'];
    $_POST = $MM_PAYPAL->send_pdt($tx,$SETTINGS->pdt);
    $returnVal = $MM_PAYPAL->paypal_post_vars;

    // Check trans amount as valid..
    $DATA  = explode("-", $returnVal['custom']);
    $cartData = $MM_CART->getCartData($DATA[0]);
    /*PDT Testing
    $MM_MAIL->sendMail($SETTINGS->website_name,
                         $SETTINGS->email_address,
                         $SETTINGS->website_name,
                         $SETTINGS->email_address,
                         '['.$SETTINGS->website_name.'] Testing PDT',
                         '$_POST[custom] = '.$_POST['mc_gross'].' $DATA[0] = '.$DATA[0].' $cartData->total = '.$cartData->total.' $_POST[mc_gross] = '.$_POST['mc_gross']); 
    */
    
    if ($cartData->total==$returnVal['mc_gross']) {

      $tplDisplayData = array();
      $tplDisplayData['THANKS_TEXT'] = $msg_paypal7;
      $tplDisplayData['THANKS_MESSAGE'] = str_replace(array('{email}','{store}'),array($_POST['payer_email'],cleanData($SETTINGS->website_name)),$msg_paypal8);
      
      
    //$DATA = explode("-", $_POST['custom']);
    // Get current data..
    //$cartData = $MM_CART->getCartData($DATA[0]);
    // Check call isn`t coming from another script..

    if (!isset($_POST['custom']) || strpos($_POST['custom'],'mswmusic')===FALSE) {
      //exit;
    }
    // E-mail vars..
    $MM_MAIL->addTag('{NAME}',$_POST['first_name'].' '.$_POST['last_name']);
    $MM_MAIL->addTag('{INVOICE}',$_POST['invoice']);
    $MM_MAIL->addTag('{TRANS_ID}',$_POST['txn_id']);
    $MM_MAIL->addTag('{TOTAL}',$_POST['mc_gross']);
    $MM_MAIL->addTag('{DOWNLOAD_LINK}',sefRelToAbs('index.php?option=com_maianmusic&section=download&code='.$cartData->download_code));
      
      
    if ($_POST['mc_gross']==$cartData->total) {
        
       if($MM_CART->checkForDuplicates($DATA[0], $cartData->download_code)){ 
      	// Update database info..
        //$MM_CART->updateCartDatabase($DATA[0],$_POST);
        // Log purchase data..
        //$MM_CART->generatePurchasesForDownload($DATA[0]);
        // Additional tags for tracks/albums purchased..
        //$MM_MAIL->addTag('{ALBUMS}',$MM_CART->purchasedItems('albums',$DATA[0],$msg_cart8));
        //$MM_MAIL->addTag('{TRACKS}',$MM_CART->purchasedItems('tracks',$DATA[0],$msg_cart8));
        // Send mail to buyer..
        //$MM_MAIL->sendMail($_POST['first_name'].' '.$_POST['last_name'],
        //                   $_POST['payer_email'],
        //                   $SETTINGS->website_name,
        //                   $SETTINGS->email_address,
        //                   '['.$SETTINGS->website_name.'] '.$msg_ipn10.'PDT',
        //                   $MM_MAIL->template(FOLDER_PATH.'templates/email/paypal_thanks.txt'));
        // Send mail to webmaster..
        //$MM_MAIL->sendMail($SETTINGS->website_name,
        // //                  $SETTINGS->email_address,
        //                   $SETTINGS->website_name,
        //                   $SETTINGS->email_address,
        //                   '['.$SETTINGS->website_name.'] '.$msg_ipn11.'PDT',
        //                   $MM_MAIL->template(FOLDER_PATH.'templates/email/paypal_notify.txt'));
         }
      }
      
      
      HTML_maiainFront::show_ThanksPage($tplDisplayData);
    } else {
    	
    	$myFile = $mosConfig_absolute_path.'/components/com_maianmusic/error_log';
        $fh = fopen($myFile, 'w') or die("can't open file");
        $stringData ='$tx = '.$tx.'\n';
        $stringData = $stringData.'$_POST[mc_gross] = '.$_POST['mc_gross'].'\n';
        $stringData = $stringData.'$cartData->total = '.$cartData->total.'\n';
        $stringData = $stringData.'$cartData->download_code = '.$cartData->download_code.'\n';
        $stringData = $stringData.'$cartCode = '.$DATA[0];
        $stringData = $stringData.'$returnVal[custom] = '.$returnVal['custom'];
        
        fwrite($fh, $stringData);
        fclose($fh);
    	
      	header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&section=invalid&Itemid='.$menu_link->id)."");
      exit;
    }
    break;
    
    case 'cancel':
    $tplDisplayData = array();
    $tplDisplayData['CANCEL_TEXT'] = $msg_paypal3;
    $tplDisplayData['CANCEL_MESSAGE'] = $msg_paypal4;	HTML_maiainFront::show_CancelPage($tplDisplayData);

    break;
    case 'invalid':
    // Send mail to webmaster..
    $MM_MAIL->addTag('{IP}',$_SERVER['REMOTE_ADDR']);
    $MM_MAIL->sendMail($SETTINGS->website_name,
                       $SETTINGS->email_address,
                       $SETTINGS->website_name,
                       $SETTINGS->email_address,
                       '['.$SETTINGS->website_name.'] '.$msg_paypal5,
                       $MM_MAIL->template(FOLDER_PATH.'templates/email/invalid_transaction.txt'));
    $tplDisplayData = array();
    $tplDisplayData['ERROR_TEXT'] = $msg_paypal5;
    $tplDisplayData['ERROR_MESSAGE'] = $msg_paypal6;	HTML_maiainFront::show_InvalidPage($tplDisplayData);
    break;
  }
  break;
  // Download..
  case 'download':
  // Check code..
  if (!isset($_GET['code']) || (isset($_GET['code']) && !ctype_alnum($_GET['code']))) {

    $tplDisplayData = array();
    $tplDisplayData['ERROR_TEXT'] = $msg_paypal9;
    $tplDisplayData['ERROR_MESSAGE'] = $msg_paypal10;
    
    HTML_maiainFront::show_ErrorPage($tplDisplayData);

  }
  
  // Is code valid...
  if (!$MM_CART->getDownloadData($_GET['code'],true)) {
    $tplDisplayData = array();
    $tplDisplayData['ERROR_TEXT'] = $msg_paypal9;
    $tplDisplayData['ERROR_MESSAGE'] = $msg_paypal11;
    HTML_maiainFront::show_ErrorPage($tplDisplayData);


  }
  // Assign cart data array to var..
  $cartPurchase = $MM_CART->getDownloadData($_GET['code']);
  // Has download page expired..
  if ($SETTINGS->page_expiry>0 && ($SETTINGS->page_expiry==$cartPurchase->visits)) {

    $tplDisplayData = array();
    $tplDisplayData['ERROR_TEXT'] = $msg_paypal12;
    $tplDisplayData['ERROR_MESSAGE'] = str_replace("{store}",cleanData($SETTINGS->website_name),$msg_paypal13);
    HTML_maiainFront::show_ErrorPage($tplDisplayData);

  }
  // Update page visits..
  $MM_CART->updateDownloadPageVisits($cartPurchase->download_code);
  // Ok, all checks passed, now display download data on page...
  $albumData  = '';
  $trackData  = '';
  // Album data..
  if ($MM_CART->albumDownloads($cartPurchase->cart_code,true)) {
    // Assign album data to array..
    $database->setQuery("SELECT * FROM #__mm_purchases
                            WHERE cart_code             = '{$cartPurchase->cart_code}'
                            AND SUBSTRING(item_id,1,1)  = 'a'
                            AND track_id                = '0'") ;	$q_album = $database->loadObjectList();
	    foreach($q_album as $aD){
      $info = $MM_CART->getTrackOrAlbumData(substr($aD->item_id,1),'album');
      $albumData .= str_replace(array('{item_name}','{download_url}','{download_this_item}','{artwork}'),
                                array(
                                cleanData($info->artist).' - '.cleanData($info->name),
                                sefRelToAbs('index2.php?option=com_maianmusic&section=55788&amp;code='.$aD->download_code),
                                $msg_paypal26,
                                ($info->artwork && strlen($info->artwork)>7 ? '<a href="'.$info->artwork.'"><img src="images/cart/artwork.gif" alt="'.$msg_paypal25.'" title="'.$msg_paypal25.'" /></a>' : ''),
                                ),
                                file_get_contents(FOLDER_PATH.'templates/tpl_files/download_item_album.html')
                                );
    }
  } else {
    $albumData = str_replace("{message}",$msg_paypal21,file_get_contents(FOLDER_PATH.'templates/tpl_files/message.html'));
  }
  // Track data..
  if ($MM_CART->trackDownloads($cartPurchase->cart_code,true)) {
    
  	// Assign track data to array..
    $database->setQuery("SELECT * FROM #__mm_purchases
                            WHERE cart_code             = '{$cartPurchase->cart_code}'
                            AND SUBSTRING(item_id,1,1)  = 't'
                            AND track_id                = '0'") ;	$q_track = $database->loadObjectList();
	    foreach($q_track as $tD){
      $info   = $MM_CART->getTrackOrAlbumData(substr($tD->item_id,1),'track');
      $ainfo  = $MM_CART->getTrackOrAlbumData($info->track_album,'album');
      $trackData .= str_replace(array('{item_name}','{download_url}','{download_this_item}','{artwork}'),
                                array(
                                cleanData($ainfo->artist).' - '.cleanData($info->track_name),
                                sefRelToAbs('index2.php?option=com_maianmusic&section=55788&amp;code='.$tD->download_code),
                                $msg_paypal24,
                                ''
                                ),
                                file_get_contents(FOLDER_PATH.'templates/tpl_files/download_item_track.html')
                                );
    }
  } else {
    $trackData = str_replace("{message}",$msg_paypal22,file_get_contents(FOLDER_PATH.'templates/tpl_files/message.html'));
  }
  // Set permissions session var..
  // If this isn`t set when the download window opens, terminate..
  // Prevents someone from sending a direct link to the download window..
  $_SESSION['download_permissions'] = '1';
  $tplDisplayData = array();
  $tplDisplayData['DOWNLOAD_TEXT'] =  $msg_paypal14;
  $tplDisplayData['DOWNLOAD_MESSAGE'] =  str_replace("{duration}",($SETTINGS->download_expiry=='1' ? '<b>'.$msg_paypal16.'</b>' : ($SETTINGS->download_expiry=='2' ? '<b>'.$msg_paypal17.'</b>' : '<b>'.($SETTINGS->download_expiry==0 ? $msg_script12 : $SETTINGS->download_expiry).'</b> '.$msg_paypal18)),$msg_paypal15);
  $tplDisplayData['ALBUMS'] = $msg_paypal19;
  $tplDisplayData['TRACKS'] = $msg_paypal20;
  $tplDisplayData['ALBUM_DATA'] = $albumData;
  $tplDisplayData['TRACK_DATA'] = $trackData;
  $tplDisplayData['ENJOY_MUSIC'] =  $msg_paypal23;
  HTML_maiainFront::show_DownloadPage($tplDisplayData);
  break;
  // Fetch download..
  case '55788':
  case '55798':
  case '55799':
  $data = '';
  $link = '';
  $size = 0;
  $file = $MM_CART->getDownloadFile($_GET['code']);
  // Are permissions set..
  if (!isset($_SESSION['download_permissions'])) {
    $data  = $msg_downloaditem2;
    $link  = '';
  }
  // Has download expired..
  if ($SETTINGS->download_expiry>0 && ($SETTINGS->download_expiry==$file->downloads)) {
    $data  = $msg_downloaditem;
    $link  = ($cmd=='55799' ? str_replace(array('{url}','{back_to_previous_page}'),
                                          array(
                                          sefRelToAbs('index.php?option=com_maianmusic&section=download&amp;code='.$MM_CART->getDownloadPageCode($_GET['code'])),
                                          $msg_paypal30
                                          ),
                                          file_get_contents(FOLDER_PATH.'templates/tpl_files/back_link.html')
                                          ) 
             : '');
  }
  // Show download link..
  if ($data=='' && $cmd=='55788') {
    if (substr($file->item_id,0,1)=='a') {
      $info    = $MM_CART->getTrackOrAlbumData(substr($file->item_id,1),'album');
      $cart    = $MM_CART->getDownloadFile($_GET['code']);
      $name    = cleanData($info->name);
      $artist  = cleanData($info->artist);
      $size    = $MM_CART->downloadSize(substr($file->item_id,1),'album',$SETTINGS);
      $tracks  = '';
      // Get tracks..
      $database->setQuery("SELECT * FROM #__mm_purchases
                               WHERE item_id  = '{$file->item_id}'
                               AND cart_code  = '{$cart->cart_code}'
                               AND track_id   > '0'
                               ORDER BY id
                               ") ;
      $q_tracks = $database->loadObjectList(); 
                               	  foreach($q_tracks as $TRACKS){
        $t        = $MM_CART->getTrackOrAlbumData($TRACKS->track_id,'track');
        $find     = array('{url}','{image}','{click_to_download}','{track}','{size}');
        $replace  = array(sefRelToAbs('index.php?option=com_maianmusic&section=55799&amp;code='.$TRACKS->download_code),
                          ($SETTINGS->download_expiry>0 && ($TRACKS->downloads==$SETTINGS->download_expiry) ? 'expired.gif' : 'small_download2.gif'),
                          ($SETTINGS->download_expiry>0 && ($TRACKS->downloads==$SETTINGS->download_expiry) ? $msg_paypal31 : $msg_paypal24),
                          cleanData($t->track_name),
                          file_size_conversion($MM_CART->downloadSize($TRACKS->track_id,'track',$SETTINGS)));
        $tracks .= str_replace($find,$replace,
                               file_get_contents(FOLDER_PATH.'templates/tpl_files/album_tracks.html'));
      }
    } else {
      $info    = $MM_CART->getTrackOrAlbumData(substr($file->item_id,1),'track');
      $name    = cleanData($info->track_name);
      $size    = $MM_CART->downloadSize(substr($file->item_id,1),'track',$SETTINGS);
    }
    $data = str_replace(array('{artist}','{name}','{download_url}','{size}','{click_to_download}','{click_to_download2}','{tracks}'),
                        array(
                        (isset($artist) ? $artist : ''),
                        $name,
                        sefRelToAbs('index.php?option=com_maianmusic&section=55798&amp;code='.$file->download_code),
                        (isset($artist) ? $msg_paypal28.' ' : '').file_size_conversion($size),
                        $msg_paypal29,
                        $msg_paypal24,
                        (isset($tracks) ? $tracks : '')
                        ),
                        file_get_contents(FOLDER_PATH.'templates/tpl_files/'.(substr($file->item_id,0,1)=='a' ? 'download_window_album.html' : 'download_window_track.html').'')
                        );
  }
  
  // Download track/album..
  if ($data=='' && ($cmd=='55798' || $cmd=='55799')) {
    // Update purchase download count..
    $MM_CART->updateFileDownloadCount($file->id);
    // Determine track id..
    $t_id = ($cmd=='55798' ? substr($file->item_id,1) : $file->track_id);
    // Path to mp3 file..
    $mp3_path = $SETTINGS->mp3_path.'/'.$MM_CART->getMP3PathForZipFile($t_id,'track');
    // Download..
    $MM_CART->forceDownload($mp3_path,$msg_paypal27);
    exit;
  }
  $tplDisplayData = array();
  $tplDisplayData['DATA'] =  $data;
  $tplDisplayData['LINK'] =  $link;
  
  HTML_maiainFront::show_ItemPage($tplDisplayData);

  break;
  
  // RSS Feed..
  case 'rss':
  $rss_feed       = '';
  $build_date     = date('D, j M Y H:i:s').' GMT';
  // Open channel..
  $rss_feed = $MM_FEED->open_channel();
  // Feed info..
  $rss_feed .= $MM_FEED->feed_info(str_replace("{website_name}",$SETTINGS->website_name,$msg_rss),
                                   sefRelToAbs('index.php'),
                                   $build_date,
                                   str_replace("{website_name}",$SETTINGS->website_name,$msg_rss2),
                                   $SETTINGS->website_name);
   
  // Get latest posts..
  $database->setQuery("SELECT * FROM #__mm_albums 
                        ORDER BY id DESC 
                        LIMIT ".$SETTINGS->rssfeeds."
                        ") ;
  $query = $database->loadObjectList();
   foreach($query as $RSS){
    $rss_feed .= $MM_FEED->add_item($msg_rss3.$RSS->artist.' - '.$RSS->name,
                                    sefRelToAbs('index.php?option=com_maianmusic&section=album&amp;album='.$RSS->id),
                                    ($RSS->rss_date ? $RSS->rss_date : $build_date),
                                    $RSS->comments);
  }
  // Close channel..
  $rss_feed .= $MM_FEED->close_channel();
  // Display RSS feed..
  header('Content-Type: text/xml');
  
   HTML_maiainFront::show_RSS($rss_feed);
  
  break;
  
  // Captcha..
  case 'captcha':
  $MMC = new PhpCaptcha();
  $MMC->Create();
  break;
  // Default location..
  default:
  	
  if($SETTINGS->default_page == '0')
  	header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&section=home&Itemid='.$menu_link->id)."");
  else
  	header("Location: ".sefRelToAbs('index.php?option=com_maianmusic&section=music&Itemid='.$menu_link->id)."");
  break;
}

?>