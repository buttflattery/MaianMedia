<?php

/*------------------------------------------
  MAIAN MUSIC v1.2
  Written by David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: www.maianscriptworld.co.uk
  This File: English language file
-------------------------------------------*/

/******************************************************************************************************
 * LANGUAGE FILE - PLEASE READ                                                                        *
 * This is a language file for the Maian Music script. Edit it to suit your own preferences.          *
 * DO NOT edit the $lang[] variable names in any way and be careful NOT to remove any of the          *
 * apostrophe`s (') that contain the variable info. This will cause the script to malfunction.        *
 * USING APOSTROPHES IN MESSAGES                                                                      *
 * If you need to use an apostrophe, escape it with a backslash. ie: d\'apostrophe                    *
 * SYSTEM VARIABLES                                                                                   *
 * Single letter variables with a percentage sign and variables between braces are system variables.  *
 *  ie: %d, %s, {count} etc                                                                           *
 * The system will not fail if you accidentally delete these, but some language may not display       *
 * correctly.                                                                                         *
 ******************************************************************************************************/

/*---------------------------------------------
  CHARACTER SET
  For encoding HTML characters
  Unless specified in language file,
   this may not need altering.
----------------------------------------------*/
global $mainframe ,$msg_charset;

$msg_charset               = 'iso-8859-1';


/*--------------------------------------
  INC/HEADER.PHP
  -------------------------------------*/
global $msg_public_header, $msg_public_header2, $msg_public_header3,
$msg_public_header4, $msg_public_header5, $msg_public_header6,$msg_public_header7,
$msg_public_header8,$msg_public_header9,$msg_public_header10,$msg_public_header11,
$msg_public_header12,$msg_public_header13,$msg_public_header14,$msg_public_header15; 
  
$msg_public_header         = 'Our Music Download Store @ {website}';  
$msg_public_header2        = 'Items in Cart';
$msg_public_header3        = 'Most Popular';
$msg_public_header4        = 'Music';
$msg_public_header5        = 'Contact';
$msg_public_header6        = 'About';
$msg_public_header7        = 'Search';
$msg_public_header8        = 'Keywords';
$msg_public_header9        = 'Premium Beat Flash Player';
$msg_public_header10       = 'This system uses<br />Premium Beat Flash Player<br /><b>&copy; Premium Beat.com</b>';
$msg_public_header11       = 'Item in Cart';
$msg_public_header12       = 'Licence';
$msg_public_header13       = 'MP3 Tracks for download from our music store.';
$msg_public_header14       = 'mp3,downloads,albums,tracks,music,music store';
$msg_public_header15        = 'Most Popular Text';



/*--------------------------------------
  TEMPLATES/ALBUM.TPL.PHP
  -------------------------------------*/
global $msg_publicalbum, $msg_publicalbum2,           
$msg_publicalbum3,
$msg_publicalbum4,
$msg_publicalbum5,
$msg_publicalbum6,
$msg_publicalbum7,
$msg_publicalbum8,
$msg_publicalbum9,
$msg_publicalbum10,
$msg_publicalbum11,
$msg_publicalbum12,
$msg_publicalbum13,
$msg_publicalbum14;  
  
$msg_publicalbum           = 'Preview/Purchase Tracks';  
$msg_publicalbum2          = 'Please use the buttons provided to preview or purchase tracks. You can add as many tracks to your shopping cart
                              as you want before purchase. Thank you.';
$msg_publicalbum3          = 'Preview';
$msg_publicalbum4          = 'Add to Cart';
$msg_publicalbum5          = 'Track Name';
$msg_publicalbum6          = 'Cost';
$msg_publicalbum7          = 'Add to Cart';
$msg_publicalbum8          = 'Add All Tracks to Cart';
$msg_publicalbum9          = 'Add Selected Tracks to Cart';
$msg_publicalbum10         = 'Preview Tracks';
$msg_publicalbum11         = 'Track';
$msg_publicalbum12         = 'This page has been viewed <b>{count}</b> times.';
$msg_publicalbum13         = 'Save <b>{amount}</b> %';
$msg_publicalbum14         = 'Related Albums';


/*--------------------------------------
  TEMPLATES/CART.TPL.PHP
  -------------------------------------*/
global $msg_cart ,$msg_cart2, $msg_cart3, $msg_cart4, $msg_cart5, $msg_cart6, $msg_cart7, $msg_cart8, $msg_cart9;  
  
$msg_cart                  = 'Shopping Cart';
$msg_cart2                 = 'The items currently in your cart are shown below. Use the buttons provided if you wish to remove any items. When you are happy with your selections, click \'Checkout\' to proceed:';  
$msg_cart3                 = 'There are currently 0 items in your cart.';
$msg_cart4                 = '{count} Shopping Cart Items';
$msg_cart5                 = 'Total';
$msg_cart6                 = 'Clear Cart';
$msg_cart7                 = 'Checkout';
$msg_cart8                 = 'From:';
$msg_cart9                 = 'You Save {discount}%';


/*--------------------------------------
  TEMPLATES/CONTACT.TPL.PHP
  -------------------------------------*/
global $msg_contact, $msg_contact2, $msg_contact3, $msg_contact4, $msg_contact5, $msg_contact6, $msg_contact7, $msg_contact8, $msg_contact9,
$msg_contact9, $msg_contact10, $msg_contact11, $msg_contact12, $msg_contact13, $msg_contact14, $msg_contact16, $msg_contact17;

$msg_contact               = 'If you are experiencing any problems, or would like to ask us any questions about our music, please use the form below:';
$msg_contact2              = 'Contact Us';
$msg_contact3              = 'Subject';
$msg_contact4              = 'Comments';
$msg_contact5              = 'Send Message';
$msg_contact6              = 'Please include a subject heading...';
$msg_contact7              = 'Please include some comments...';
$msg_contact8              = 'Your message has been sent.<br /><br />A response will follow as soon as possible.';
$msg_contact9              = 'Name';
$msg_contact10             = 'E-Mail Address';
$msg_contact11             = 'Enter Code';
$msg_contact12             = 'Invalid code, please try again..';
$msg_contact13             = 'Thank You!';
$msg_contact14             = 'Message sent!';
$msg_contact15             = 'Please include your name...';
$msg_contact16             = 'Please include a valid e-mail address...';
$msg_contact17             = 'Click Captcha to Refresh';


/*--------------------------------------
  TEMPLATES/CONTACT.TPL.PHP
  -------------------------------------*/
global $msg_publichome, $msg_publichome2, $msg_publichome3, $msg_publichome4;
  
$msg_publichome            = 'Thank you for your interest in our music. Use the music link in the left hand menu to browse
                              our collection of albums. You can purchase single tracks or whole albums by using the buttons
                              provided. You can also preview mp3 files before you buy.<br /><br />All payments are securely
                              handled by Paypal and you don`t need a Paypal account to pay using your credit or debit card.<br /><br />
                              Please contact me if you have any questions, thank you!
                              ';  
$msg_publichome2           = 'All Major Credit Cards Accepted via Paypal';
$msg_publichome3           = 'Most Popular Tracks';
$msg_publichome4           = 'Most Popular Albums';


/*--------------------------------------
  TEMPLATES/DOWNLOAD_ITEM.TPL.PHP
  -------------------------------------*/
  
global $msg_downloaditem, $msg_downloaditem2;

$msg_downloaditem          = '<br /><br /><span class="sorry">Sorry!</span><br /><br /><span class="sorry_msg">This Download Has Expired!</span><br /><br /><br />Please use the contact option<br />to have this download reset.';  
$msg_downloaditem2         = '<br /><br /><span class="sorry">Error!</span><br /><br /><span class="sorry_msg">You do not have permission<br />to view this page!</span><br /><br /><br />Please use the contact option<br />if you think this is incorrect.';  


/*--------------------------------------
  TEMPLATES/MUSIC.TPL.PHP
  -------------------------------------*/
  
global $msg_music, $msg_music2, $msg_music3;
$msg_music                 = 'Please click the links to view more information about an album and to preview/purchase tracks. Thank you.';
$msg_music2                = 'More Information';
$msg_music3                = 'Tracks: {count}';


/*--------------------------------------
  TEMPLATES/PAYPAL/CANCEL.TPL.PHP
  TEMPLATES/PAYPAL/CHECKOUT.TPL.PHP
  TEMPLATES/PAYPAL/DOWNLOAD.TPL.PHP
  TEMPLATES/PAYPAL/ERROR.TPL.PHP
  TEMPLATES/PAYPAL/THANKS.TPL.PHP
  -------------------------------------*/
  
global $msg_paypal, $msg_paypal2, $msg_paypal3, $msg_paypal4, $msg_paypal5, $msg_paypal6, $msg_paypal7, $msg_paypal8, $msg_paypal9,
$msg_paypal10, $msg_paypal11, $msg_paypal12, $msg_paypal13, $msg_paypal14, $msg_paypal15, $msg_paypal16, $msg_paypal17, $msg_paypal18,
$msg_paypal19, $msg_paypal20, $msg_paypal21, $msg_paypal22, $msg_paypal23, $msg_paypal24, $msg_paypal25, $msg_paypal26, $msg_paypal27,
$msg_paypal28, $msg_paypal29, $msg_paypal30, $msg_paypal31;  

$msg_paypal                = 'Connecting to Paypal server.....Please wait....';  
$msg_paypal2               = 'Music Store Purchases';
$msg_paypal3               = 'Transaction Cancelled!';
$msg_paypal4               = 'Your transaction was successfully cancelled and no payment was sent.<br /><br />Thank you for your interest in our music.';
$msg_paypal5               = 'Invalid Transaction!';
$msg_paypal6               = 'This appears to be an invalid transaction as the payment amount does not match the cart amount.<br /><br />The webmaster has been informed of this attempt and may take further action.<br /><br />If you feel this is an error, please use the contact link in the left hand menu.<br /><br />Thank you.';
$msg_paypal7               = 'Thank You!';
$msg_paypal8               = 'Your transaction has successfully been completed.<br /><br />
                              Please check your inbox at "<b>{email}</b>". This contains a download link to the music tracks you purchased. Please click this link to go to the download page. If you do not receive this e-mail, please use the contact link in the left hand menu.<br /><br />
                              I hope you enjoy your music,<br /><br />
                              <b>{store}</b>';
$msg_paypal9               = 'An Error Has Occured!';
$msg_paypal10              = 'You do not have permission to view this page, sorry.';  
$msg_paypal11              = 'No purchase data has been found. Please double check the link you clicked in your e-mail.<br/><br />If you feel an error has occured, please use the contact link in the left hand menu.<br /><br />Thank you.';                            
$msg_paypal12              = 'Download Page Expired!';
$msg_paypal13              = 'This link has now expired and cannot be accessed anymore. Our system automatically restricts the amount of times a download page can be accessed for security reasons.<br /><br />
                              If you need to access this page again, please use the contact link in the left hand menu to have this link reset.<br /><br />
                              Sorry for any inconvenience,<br /><br />
                              <b>{store}</b>';
$msg_paypal14              = 'Downloads Page';
$msg_paypal15              = 'Thank you for your purchases, your downloads are shown below.<br /><br />Please <b>DO NOT</b> refresh or bookmark this page as it may timeout or have expired when you return.<br /><br />You are permitted to download each file {duration}. If you experience any problems, please use the contact link in the left menu.';                              
$msg_paypal16              = 'once';
$msg_paypal17              = 'twice';
$msg_paypal18              = 'times';
$msg_paypal19              = 'Albums Purchased';
$msg_paypal20              = 'Tracks Purchased';
$msg_paypal21              = 'No album purchase data found';
$msg_paypal22              = 'No track purchase data found';
$msg_paypal23              = 'Hope you enjoy your new music!';
$msg_paypal24              = 'Download Track';
$msg_paypal25              = 'Download Artwork';
$msg_paypal26              = 'Download Tracks';
$msg_paypal27              = 'File does not exist!';
$msg_paypal28              = 'All Tracks = ';
$msg_paypal29              = 'Click button(s) to download!';
$msg_paypal30              = 'Back to Previous Page';
$msg_paypal31              = 'Download Expired';


/*--------------------------------------
  TEMPLATES/SEARCH.TPL.PHP
  -------------------------------------*/
  
global $msg_publicsearch, $msg_publicsearch2, $msg_publicsearch3, $msg_publicsearch4;

$msg_publicsearch          = 'Search Results';
$msg_publicsearch2         = 'Your search results for "<b>{keywords}</b>" are shown below. If your search generated no results, try multiple keywords seperated by a space for a more detailed search.';
$msg_publicsearch3         = '<br /><b>No Results Found...Please Try Again...</b>';
$msg_publicsearch4         = '{count} Search Results';


/*--------------------------------------
  ADMIN/INC/HEADER.PHP
  -------------------------------------*/
global $msg_header, $msg_header2, $msg_header3, $msg_header4, $msg_header5, $msg_header6,
$msg_header7, $msg_header8, $msg_header9, $msg_header10, $msg_header11;

$msg_header                = 'Administration';
$msg_header2               = 'Home';  
$msg_header3               = 'Settings';  
$msg_header4               = 'Manage Albums';  
$msg_header5               = 'Add New Tracks';  
$msg_header6               = 'Manage Tracks';  
$msg_header7               = 'Sales';  
$msg_header8               = 'Search Sales'; 
$msg_header9               = 'Navigational Menu';
$msg_header10              = 'Logout'; 
$msg_header11              = 'Statistics';
  
  
/*--------------------------------------
  ADMIN/INC/FOOTER.PHP
  TEMPLATES/FOOTER.TPL.PHP
  -------------------------------------*/
global $msg_footer, $msg_footer2, $msg_footer3;
  
$msg_footer                = 'Copyright';
$msg_footer2               = 'All Rights Reserved';  
$msg_footer3               = 'Please enable javascript in your browser. Thank you!';


/*--------------------------------------
  ADMIN/DATA_FILES/ADD.PHP
  -------------------------------------*/
global $msg_add, $msg_add2, $msg_add3, $msg_add4, $msg_add5, $msg_add6, $msg_add7, $msg_add8,
$msg_add9, $msg_add10, $msg_add11, $msg_add12, $msg_add13, $msg_add14, $msg_add15;
  
$msg_add                   = 'Here you add your mp3/mp4 tracks. Before adding make sure full length &amp; preview tracks are uploaded into the folders specified in your settings. Use the drop down menu below to select
                              how many tracks you would like to add and then fill out the details for each track. Use the help links for information if you aren`t sure.<br><br>
                              <i>Note that if you omit the track name, mp3 file path or cost, the file will NOT be added.</i>';  
$msg_add2                  = 'Tracks to Add';
$msg_add3                  = 'How many tracks would you like to add? You can refresh this at any time and no form data will be lost.';
$msg_add4                  = 'Track';
$msg_add5                  = 'Add Tracks';
$msg_add6                  = 'Track Name';
$msg_add7                  = 'Add to Album';
$msg_add8                  = 'MP3 File Path';
$msg_add9                  = 'Preview File Path';
$msg_add10                 = 'Length of Track';
$msg_add11                 = 'Cost';
$msg_add12                 = 'Single Purchase';
$msg_add13                 = '<b>{count}</b> tracks were successfully added.<br><br>To manage these tracks, use the menu above.';
$msg_add14                 = 'Display';
$msg_add15                 = 'for all tracks.';


/*--------------------------------------
  ADMIN/DATA_FILES/ALBUMS.PHP
  -------------------------------------*/
global $msg_albums, $msg_albums2, $msg_albums3, $msg_albums4, $msg_albums5, $msg_albums6, $msg_albums7, $msg_albums8,
$msg_albums9, $msg_albums10, $msg_albums11, $msg_albums12, $msg_albums13, $msg_albums14, $msg_albums15, $msg_albums16,
$msg_albums17, $msg_albums18, $msg_albums19; 
  
$msg_albums                = 'MP3s are grouped into albums. If you don`t actually have an album, think of this as a category for the music files. When you add tracks, you`ll
                              need to specify which album to put it into. Albums can be top level categories or child categories of parent categories. Visitors can purchase single tracks or whole albums. Once you add a new album it will appear below.';  
$msg_albums2               = 'Add New Album';
$msg_albums3               = 'Album Name';
$msg_albums4               = 'Current Albums (Click name to edit, click cross to delete)';
$msg_albums5               = 'Album Image URL';
$msg_albums20              = 'Image Dimensions';
$msg_albums21              = 'Height:';
$msg_albums22              = 'Width:';
$msg_albums6               = 'Album Artwork (Zip File)';
$msg_albums7               = 'Comments/Info';
$msg_albums8               = 'Enable Album';
$msg_albums9               = 'There are currently 0 albums in the database.';
$msg_albums10              = 'Update Album';
$msg_albums11              = 'Artist';
$msg_albums12              = 'Keywords';
$msg_albums13              = 'Downloads';
$msg_albums14              = 'Reset Track Downloads';
$msg_albums15              = 'Hits';
$msg_albums16              = 'Category';
$msg_albums17              = 'Top Level Album';
$msg_albums18              = 'Parent Album of';
$msg_albums19              = 'Album Purchase Discount';


/*--------------------------------------
  ADMIN/DATA_FILES/HOME.PHP
  -------------------------------------*/
global $msg_home, $msg_home2, $msg_home3, $msg_home4, $msg_home5, $msg_home6, $msg_home7;
  
$msg_home                  = 'Welcome to Maian Music for Joomla, a simple music store system that enables you to preview and sell your own music
                              in mp3/mp4 format.  This script was orginaly written by <a href="http://www.maianscriptworld.co.uk" title="Maian Script World" target="_blank">Maian Script World</a> and now has been converted to Joomla by <a href="http://www.aretimes.com" title="Are Times" target="_blank">Are Times</a>.
                              The orginal documentation can be found <a href="'.$mainframe->getCfg('live_site').'/components/com_maianmusic/docs/setup/index.html" target="_blank" title="Documentation">here</a>. 
                              To use this system you must have a paypal bussiness account.  It is recommened to enable Auto Return for a more streamlined customer expreince.  When configuring this componnet look for
                               [<b><span style="color:#FF7700">?</span></b>] tooltips for more information.<br><br> 
                              If you have any problems, please post on the <a href="http://www.aretimes.com/component/option,com_fireboard/Itemid,33/" title="Support Forums" target="_blank">support forums</a>.<br><br>
                              Please contact me via our website if you have comments or find any bugs. <br><br>
                              I hope you enjoy your music system,<br><br>Alao.<br><br><b>Are Times</b><br><a href="http://www.aretimes.com" title="Are Times" target="_blank">http://www.aretimes.com</a>
                              ';
$msg_home2                 = 'Donation';                                
$msg_home3                 = 'If you like this script and would like to show support please consider either making a donation or purchacing music from Are Times';
$msg_home4                 = 'Donations are not necessary, but very much appreciated. Thank you!';
$msg_home5                 = 'Music Store Overview';
$msg_home6                 = 'You currently have <b>{tracks}</b> tracks, grouped into <b>{albums}</b> albums.<br><br>
                              Paypal Fees: <b>{fees}</b><br>
                              Profit: <b>{profit}</b><br><br>
                              <b>{a_purchases}</b> albums and <b>{t_purchases}</b> single tracks have currently been purchased.
                              ';
$msg_home7                 = 'Please remove or rename the installation directory!!';   
                         
                              
/*--------------------------------------
  ADMIN/DATA_FILES/LOGIN.PHP
  -------------------------------------*/   
global $msg_login, $msg_login2, $msg_login3, $msg_login4, $msg_login5, $msg_login6, $msg_login7;  
  
$msg_login                 = 'Administration Login';                             
$msg_login2                = 'Please login to your administration area below:';
$msg_login3                = 'Username';
$msg_login4                = 'Password';
$msg_login5                = 'Login';
$msg_login6                = 'Invalid';
$msg_login7                = 'Remember Me';


/*--------------------------------------
  ADMIN/DATA_FILES/SALES.PHP
  -------------------------------------*/
global $msg_sales, $msg_sales2, $msg_sales3, $msg_sales4, $msg_sales5, $msg_sales6, $msg_sales7, $msg_sales8, $msg_sales9, $msg_sales9,
$msg_sales10, $msg_sales11, $msg_sales12, $msg_sales13, $msg_sales14, $msg_sales15, $msg_sales16, $msg_sales17, $msg_sales18, $msg_sales19,
$msg_sales20, $msg_sales21, $msg_sales22, $msg_sales23, $msg_sales24, $msg_sales25, $msg_sales26, $msg_sales27, $msg_sales28, $msg_sales29,
$msg_sales30, $msg_sales31, $msg_sales32, $msg_sales33, $msg_sales34, $msg_sales35, $msg_sales36, $msg_sales37, $msg_sales38, $msg_sales39,
$msg_sales40, $msg_sales41; 
  
$msg_sales                 = 'Your processed sales are shown below. Use the order by options if required. Use the links provided to manage your sales or contact buyers. If you need to locate an entry, use the search option from the menu.';  
$msg_sales2                = 'Show';
$msg_sales3                = 'Per Page';
$msg_sales4                = 'Newest Sales';
$msg_sales5                = 'Oldest Sales';
$msg_sales6                = 'Tracks Purchased';
$msg_sales7                = 'Albums Purchased';
$msg_sales8                = 'Highest Grossing';
$msg_sales9                = 'Lowest Grossing';
$msg_sales10               = 'Buyers Name A-Z';
$msg_sales11               = 'Buyers Name Z-A';
$msg_sales12               = 'Viewing {count} Sales';
$msg_sales13               = 'There are currently <b>0</b> sales in the database.';
$msg_sales14               = 'Remove Selected Sales';
$msg_sales15               = 'Albums Purchased';
$msg_sales16               = 'Tracks Purchased';
$msg_sales17               = '<b>0</b> albums purchased.';
$msg_sales18               = '<b>0</b> tracks purchased.';
$msg_sales19               = 'by';
$msg_sales20               = 'Albums';
$msg_sales21               = 'Tracks';
$msg_sales22               = 'View Sales Information';
$msg_sales23               = 'Contact Buyer';
$msg_sales24               = 'Subject';
$msg_sales25               = 'Comments';
$msg_sales26               = 'Or if you have an e-mail client, click <a href="mailto:{email}" title="Click to launch e-mail client"><b><u>here</u></b></a>.';
$msg_sales27               = 'Message Sent!';
$msg_sales28               = 'Send Message';
$msg_sales29               = 'Reset Downloads &amp; Re-Send Download E-Mail';
$msg_sales30               = 'Buyer/Paypal Information';
$msg_sales31               = 'E-Mail Sent to Buyer!';
$msg_sales32               = 'Click to View';
$msg_sales33               = 'Buyer';
$msg_sales34               = 'E-Mail';
$msg_sales35               = 'Date';
$msg_sales36               = 'Address';
$msg_sales37               = 'Buyer Memo';
$msg_sales38               = 'Payment Status';
$msg_sales39               = 'Gross/Fee/Total';
$msg_sales40               = 'Paypal Transaction ID';
$msg_sales41               = 'Invoice No';


/*--------------------------------------
  ADMIN/DATA_FILES/SEARCH.PHP
  -------------------------------------*/
global $msg_search, $msg_search2, $msg_search3, $msg_search4, $msg_search5 ,$msg_search6, $msg_search7, $msg_search8,
$msg_search9, $msg_search10, $msg_search11, $msg_search12;  
  
$msg_search                = 'This feature lets you search your sales. Useful if you have lots of entries and need to locate a specific one. Please specify your criteria below. You can enter one or all search terms, but you must include at least one option:';
$msg_search2               = 'Enter Search Criteria';
$msg_search3               = 'Where \'name\' like';
$msg_search4               = 'Where \'e-mail\' like';
$msg_search5               = 'Where \'invoice no\' =';
$msg_search6               = 'Where \'trans id\' =';
$msg_search7               = 'Where \'date\' between';
$msg_search8               = 'Search';
$msg_search9               = 'No matches found...Please try another search...';
$msg_search10              = 'Search Results';
$msg_search11              = 'Your search results are shown below';
$msg_search12              = 'New Search';


/*--------------------------------------
  ADMIN/DATA_FILES/SETTINGS.PHP
  -------------------------------------*/
global $msg_settings, $msg_settings2, $msg_settings3, $msg_settings4, $msg_settings5, $msg_settings6, $msg_settings7, $msg_settings8, $msg_settings9,
$msg_settings10, $msg_settings11, $msg_settings12, $msg_settings13, $msg_settings14, $msg_settings15, $msg_settings16, $msg_settings17, $msg_settings18, 
$msg_settings19, $msg_settings20, $msg_settings21, $msg_settings22, $msg_settings23, $msg_settings24, $msg_settings25, $msg_settings26, $msg_settings27,
$msg_settings28, $msg_settings29, $msg_settings30, $msg_settings31, $msg_settings32, $msg_settings33, $msg_settings34, $msg_settings35, $msg_settings36,
$msg_settings37, $msg_settings38, $msg_settings39, $msg_settings40, $msg_settings41, $msg_settings42, $msg_settings43, $msg_settings44;
  
$msg_settings              = 'Update your program settings below. All fields should be completed unless stated as optional.';  
$msg_settings2             = 'Website/General Settings';
$msg_settings3             = 'Music Store Name';
$msg_settings4             = 'E-Mail Address';
$msg_settings5             = 'Homepage URL';
$msg_settings6             = 'URL to Installation Folder';
$msg_settings7             = 'Language';
$msg_settings8             = 'Enable Captcha';
$msg_settings9             = 'MP3/Download Settings';
$msg_settings10            = 'MP3 Folder Path';
$msg_settings11            = 'MP3 Preview Folder Path';
$msg_settings12            = 'Update Settings';
$msg_settings13            = 'Search Engine Friendly URLs';
$msg_settings14            = 'Paypal Settings';
$msg_settings15            = 'Enable Paypal IPN';
$msg_settings16            = 'Enable Sandbox';
$msg_settings17            = 'Live';
$msg_settings18            = 'Log Errors';
$msg_settings19            = 'Page Style';
$msg_settings20            = 'Paypal E-Mail Address';
$msg_settings21            = 'Processing Currency';
$msg_settings22            = '';
$msg_settings23            = 'About Page Text';
$msg_settings24            = '<a href="http://en.wikipedia.org/wiki/HTML" title="Hypertext Markup Language" target="_blank">HTML</a> is allowed';
$msg_settings25            = 'Download Page Expiry';
$msg_settings26            = 'Total Albums for RSS Feed';
$msg_settings27            = 'Total Popular Links';
$msg_settings28            = 'SSL Enabled';
$msg_settings29            = 'SMTP Port';
$msg_settings30            = 'Reset All Album Hits';
$msg_settings31            = 'Download Item Expiry';
$msg_settings32            = 'Licence Page Text';
$msg_settings33            = 'SMTP Settings';
$msg_settings34            = 'Enable SMTP';
$msg_settings35            = 'SMTP Host';
$msg_settings36            = 'SMTP Username';
$msg_settings37            = 'SMTP Password';
$msg_settings38             = 'Mp3 Player Configuration';
$msg_settings39             = 'Player';
$msg_settings40             = 'Payment Data Transfer';
$msg_settings41             = 'Default Page';
$msg_settings42             = 'Most Popular';
$msg_settings43             = 'Music';
$msg_settings44             = 'Music Page Text';

/*--------------------------------------
  ADMIN/DATA_FILES/STATISTICS.PHP
  -------------------------------------*/
global $msg_statistics, $msg_statistics2, $msg_statistics3, $msg_statistics4, $msg_statistics5, $msg_statistics6, $msg_statistics7, $msg_statistics8,
$msg_statistics9, $msg_statistics10, $msg_statistics11;

$msg_statistics            = 'This page lets you see at a glance how many times each album or track has been purchased. Click the buttons to expand an album for track stats.
                              ';
$msg_statistics2           = 'Order By';
$msg_statistics3           = 'Most Hits';
$msg_statistics4           = 'Least Hits';
$msg_statistics5           = 'Album';
$msg_statistics6           = 'Single';
$msg_statistics7           = 'Hits: <b>{hits}</b> | Album Purchases: <b>{albums}</b> | Track Purchases: <b>{tracks}</b>';
$msg_statistics8           = 'View Track Statistics';
$msg_statistics9           = 'This displays a list of each track for this album and the total amount of purchases for each track.';
$msg_statistics10          = 'Expand All';
$msg_statistics11          = 'Collapse All';


/*--------------------------------------
  ADMIN/DATA_FILES/TRACKS.PHP
  -------------------------------------*/
global $msg_tracks, $msg_tracks2, $msg_tracks3, $msg_tracks4;
  
$msg_tracks                = 'This page lets you manage your current tracks. Select an album from below to view tracks in that album and then use the buttons provided to update tracks.';  
$msg_tracks2               = '<b>{count}</b> tracks';
$msg_tracks3               = 'View Tracks';
$msg_tracks4               = 'No Tracks';


/*--------------------------------------
  ADMIN/DATA_FILES/VIEW_TRACKS.PHP
  -------------------------------------*/
global $msg_viewtracks, $msg_viewtracks2, $msg_viewtracks3, $msg_viewtracks4, $msg_viewtracks5, $msg_viewtracks6, $msg_viewtracks7,
$msg_viewtracks8, $msg_viewtracks9;  
  
$msg_viewtracks            = 'Update Tracks';  
$msg_viewtracks2           = 'Click on the links to edit a track. You can update or delete any track and also change the order by option which determines the order
                              in which the tracks are displayed in the public view.';
$msg_viewtracks3           = 'Update This Track';
$msg_viewtracks4           = 'Move Up';
$msg_viewtracks5           = 'Move Down';
$msg_viewtracks6           = 'This album currently has 0 tracks';
$msg_viewtracks7           = 'Cancel';
$msg_viewtracks8           = 'Track successfully updated!';
$msg_viewtracks9           = 'Refresh';


/*---------------------
  RESPONSE DATA FOR IPN
  PAYPAL E-MAILS
----------------------*/
global $msg_ipn, $msg_ipn2, $msg_ipn3, $msg_ipn4, $msg_ipn5, 
$msg_ipn6, $msg_ipn7, $msg_ipn8, $msg_ipn9, $msg_ipn10, $msg_ipn11;

$msg_ipn                   = 'Order Invalid';
$msg_ipn2                  = 'Paypal IPN Error!!';
$msg_ipn3                  = 'If enabled, this error has been logged in the log file.';
$msg_ipn4                  = 'The following input was received from (and sent back to) PayPal:';
$msg_ipn5                  = 'Payment Failed';
$msg_ipn6                  = 'Payment Denied';
$msg_ipn7                  = 'Unknown Payment Status';
$msg_ipn8                  = 'Music Store Purchase Pending!';
$msg_ipn9                  = 'Invalid Purchase Transaction!';
$msg_ipn10                 = 'Music Download Information!';
$msg_ipn11                 = 'Music Store Transaction!';


/*-------------------------------------
  GENERAL VARIABLES
  ------------------------------------*/
global $msg_script, $msg_script2, $msg_script3, $msg_script4, $msg_script5, $msg_script6, $msg_script7, $msg_script8, $msg_script9,
$msg_script10, $msg_script11, $msg_script12;

$msg_script                = 'Maian Music v1.2';
$msg_script2               = 'Yes';
$msg_script3               = 'No';
$msg_script4               = 'Optional';
$msg_script5               = 'First';
$msg_script6               = 'Last';
$msg_script7               = 'Edit';
$msg_script8               = 'Delete';
$msg_script9               = 'Cancel';
$msg_script10              = 'Refresh';
$msg_script11              = 'Print';
$msg_script12              = 'unlimited';


/*-----------------------------
  RSS Feeds
-------------------------------*/
global $msg_rss, $msg_rss2, $msg_rss3;

$msg_rss                   = 'Latest albums @ {website_name}';
$msg_rss2                  = 'These are the latest albums to be added at {website_name}';
$msg_rss3                  = 'Album: ';


/*----------------------
  ADMIN/INC/CALENDAR.PHP
-----------------------*/

global $msg_calendar, $msg_calendar2, $msg_calendar3, $msg_calendar4, $msg_calendar5, $msg_calendar6, $msg_calendar7, $msg_calendar8,
$msg_calendar9, $msg_calendar10, $msg_calendar11, $msg_calendar12;
 
$msg_calendar              = 'January';
$msg_calendar2             = 'February';
$msg_calendar3             = 'March';
$msg_calendar4             = 'April';
$msg_calendar5             = 'May';
$msg_calendar6             = 'June';
$msg_calendar7             = 'July';
$msg_calendar8             = 'August';
$msg_calendar9             = 'September';
$msg_calendar10            = 'October';
$msg_calendar11            = 'November';
$msg_calendar12            = 'December';


/*--------------------------------------------------------------------------------------------------
  ZIP FILE FOLDER NAMES
  These are the names of the folders that are created inside the zip file when someone downloads 
  an album or track. These should NOT contain any illegal characters that may prevent the creation 
  of the folder. If you are unsure, leave them as they are
  --------------------------------------------------------------------------------------------------*/
  
global $msg_folder, $msg_folder2;
$msg_folder                = 'track';
$msg_folder2               = 'album';
  

/*-----------------------------------------------------------------------------------------------------
  JAVASCRIPT VARIABLES
  IMPORTANT: If you want to use apostrophes in these variables, you MUST escape them with 3 backslashes
             Failure to do this will result in the script malfunctioning on javascript code. Unless you
             specifically need them, using double quotes is recommended.
  EXAMPLE: d\\\'apostrophe
------------------------------------------------------------------------------------------------------*/
global $msg_javascript, $msg_javascript2, $msg_javascript3, $msg_javascript4, $msg_javascript5 ,$msg_javascript6, $msg_javascript7, $msg_javascript8,
$msg_javascript9, $msg_javascript10, $msg_javascript11, $msg_javascript12, $msg_javascript13, $msg_javascript14, $msg_javascript15, $msg_javascript16,
$msg_javascript17, $msg_javascript18, $msg_javascript19, $msg_javascript20, $msg_javascript21, $msg_javascript22, $msg_javascript23, $msg_javascript24,
$msg_javascript25, $msg_javascript26, $msg_javascript27, $msg_javascript28, $msg_javascript29, $msg_javascript30, $msg_javascript31, $msg_javascript32, 
$msg_javascript33, $msg_javascript34, $msg_javascript35, $msg_javascript36, $msg_javascript37, $msg_javascript38, $msg_javascript39;

$msg_javascript            = 'Help/Information';
$msg_javascript2           = 'Full url to folder containing files. NO trailing slash.<br><br><b>http://www.yoursite.com/music</b>';
$msg_javascript3           = 'A captcha can help spam coming via your contact option. The <b>GD Library with Freetype support</b> is required to be installed on your server for this to work. See the docs for more information.';
$msg_javascript4           = 'MP3 files should always be stored outside of the web root. This is the relative path from the music root folder to the MP3 folder. Name it manually and make sure it exists. NO trailing slash.<br><br><b>../mp3</b>';
$msg_javascript5           = 'Same as above, but this is the path to the MP3 preview folder. This can be alongside or inside the above MP3 folder. NO trailing slash.<br><br><b>../mp3/mp3_preview</b>';
$msg_javascript6           = 'Enables mod_rewrite for search engine friendly urls. For this to work, your server must support <b>.htaccess</b> Once enabled rename <b>htaccess_COPY.txt</b> file to <b>.htaccess</b><br><br>May result in server error if enabled and <b>.htaccess</b> isn`t supported.';
$msg_javascript7           = 'Paypal enables you to test the system without actually submitting a live payment. This is the <b>sandbox</b> mode and more details can be found <a href="https://developer.paypal.com" title="Sandbox" target="_blank">here</a>.<br><br>Check the box to enable sandbox. Uncheck for live processing.';
$msg_javascript8           = 'This is your business or premier account paypal e-mail address.';
$msg_javascript9           = 'Paypal enables you to create a page style in your Paypal area. If you have one, specify its name here. Leave blank for no page style.';
$msg_javascript10          = 'If an invalid response is sent back from Paypal, you can log the error. This is useful for debugging and I recommend you leave this enabled when testing.';
$msg_javascript11          = 'Specify your processing currency. The list shows the ones supported by Paypal at the time this script was created.';
$msg_javascript12          = 'If you have a preview image you would like to display for this album, specify the full url starting http://<br><br>Note that image displays full size by default and should be <b>65</b>x<b>65</b> pixels.<br><br><i>(Optional)</i>';
$msg_javascript13          = 'If a visitor purchases a full album and you would also like them to be able to download the cover art, put the files in a .zip file, upload and specify the path here starting http://<br><br>If someone purchases a full album, this link will also be included along with the link to download the mp3s.<br><br><i>(Optional)</i>';
$msg_javascript14          = 'Set the status for this album. If disabled, it is not viewable by the public.';
$msg_javascript15          = 'Are you sure?\n\nThis will also delete mp3 files attached to this album.\n\nNote that actual files should be removed manually.';
$msg_javascript16          = 'Specify the mp3 file path <b>ONLY</b> here unless you have the mp3 file inside of another folder in the main mp3 folder. This file should be uploaded into the relevant folder. Examples:<br><br><b>music_file.mp3</b><br><b>album1/music_file.mp3</b>';
$msg_javascript17          = 'If you want to use a shorter track for a preview, specify the file name here. This file should exist in the preview folder in your settings. If no preview file is added, preview will be full length track.<br><br>Optional';
$msg_javascript18          = 'Specify the length of this track. Examples:<br><br>4:32<br>4mins 32 seconds<br>4-32';
$msg_javascript19          = 'Specify the cost you are selling this track at. NO currency symbol before the price. So, if you were selling for &pound;0.75 you would put <b>0.75</b>.';
$msg_javascript20          = 'Is this track available as a single purchase? If not, track can only be purchased by buying whole album.';
$msg_javascript21          = 'Are you sure you wish to delete this track?';
$msg_javascript22          = 'Enter keywords that best describe the music of this album. Appears in the meta keywords head tag on page.';
$msg_javascript23          = 'If you want visitors to get a discount for purchasing a whole album, specify the percentage here. Set as 0 for no discount.';
$msg_javascript24          = 'When someone purchases tracks, they are sent the link to a download page. To prevent them from sending this link to other people you can specify how many times this page can be accessed before the link expires. <b>Set to 0 for unlimited</b>.';
$msg_javascript25          = 'Are you sure you want to clear your cart?';
$msg_javascript26          = 'Delete this item?';
$msg_javascript27          = 'This option lets you batch reset download counts. For individual albums, use the option when updating album. For individual tracks, use the option when updating track.';
$msg_javascript28          = 'If you check the box, all tracks in this album will have the download count set to 0.';
$msg_javascript29          = 'If you check this box, all hits for all albums will be reset to 0. To update individual album, use the manage albums page.';
$msg_javascript30          = 'This is the limit that any purchase can be downloaded. <b>Set to 0 for unlimited</b>.';
$msg_javascript31          = 'Keeps you logged in for 30 days. <b>NOT</b> recommended for shared computers.<br /><br />Cookies must be enabled for this function to work.';
$msg_javascript32          = 'Some hosts disable the PHP mail function and require you to use SMTP to send mail. If the mail isn`t working, try enabling this option. If you are unsure of your SMTP details, contact your hosting company.';
$msg_javascript33          = 'Are you sure you want to delete these sales?';
$msg_javascript34          = 'Are you sure?';
$msg_javascript35          = 'If your site is on a Secure Socket Layer, enable SSL to have the processing return to your secure area. Do <b>NOT</b> enable this is you don`t have a SSL certificate installed on your server.';
$msg_javascript36          = 'How many latest albums do you want to display on the RSS feed? Max 999';
$msg_javascript37          = 'How many popular links do you want to display on homepage? Max 999';
$msg_javascript38          = 'To get your Idenity Token under your Paypal profile go to:<br><br><b>Profile ->Website Payment Preferences</b><br><br> Turn on Payment Data Transfer and copy and paste your Identity Token';
$msg_javascript39          = 'Determines which page the component defaults to';
/*-----------------------------------------------------------------------------------------------------

  Pre-installiation check. 

------------------------------------------------------------------------------------------------------*/

global $setup15, $setup16, $setup17, $setup18, $setup19, $setup20, $setup22;

$setup15          = 'CURL Support <i>(Paypal Processing)</i>';
$setup16          = 'PHP Version';
$setup17          = 'Compatibility Check if not ok contact your host';
$setup18          = 'GD Graphic Support <i>(Captcha)</i>';
$setup19          = '<font style="color:orange">OK</font>';
$setup20          = '<font style="color:red">Not Installed</font>';
$setup22          = '<font style="color:red">Version Too Old</font>';

?>
