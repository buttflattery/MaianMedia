<link rel="alternate" type="application/rss+xml" title="RSS" href="<?php echo $tplDisplayFront['FEED_URL'] ?>" />
<title><?php echo $tplDisplayFront['STORE_NAME'] ?></title>
<div id="mm_header">
	<div id="mm_navigation">
   		<ul>
				<li><a href="<?php echo $tplDisplayFront['H_URL'] ?>" title="<?php echo $tplDisplayFront['HOMEPAGE']; ?>"><?php echo $tplDisplayFront['HOMEPAGE']; ?></a></li>
				<li><a href="<?php echo $tplDisplayFront['A_URL'] ?>" title="<?php echo $tplDisplayFront['ARTISTS']; ?>"><?php echo $tplDisplayFront['ARTISTS']; ?></a></li>
				<li><a href="<?php echo $tplDisplayFront['C_URL'] ?>" title="<?php echo $tplDisplayFront['CONTACT']; ?>"><?php echo $tplDisplayFront['CONTACT']; ?></a></li>
				<li><a href="<?php echo $tplDisplayFront['L_URL'] ?>" title="<?php echo $tplDisplayFront['LICENCE']; ?>"><?php echo $tplDisplayFront['LICENCE']; ?></a></li>
			</ul>

 	</div> 	   		
	
        <div id="mm_cart" onclick="location.href='<?php echo sefRelToAbs('index.php?option=com_maianmusic&section=view-cart')?>'">
		<ul>
		<li></li>
		<font><?php echo $tplDisplayFront['ITEMS_IN_CART'] ?>
		<?php echo $tplDisplayFront['CART_COUNT'] ?></font>
     	(<i><?php echo $tplDisplayFront['CART_TOTAL'] ?></i>)</ul>
 	</div>

        
</div>

<div id="search_box">
 	<form method="get" action="index.php?option=com_maianmusic">
					<input type="hidden" name="option" value="com_maianmusic" />
					<input type="hidden" name="section" value="search" />
					<input id="textfield1" type="text" class="searchBox" name="keywords" value="" />
					<input id="submit1" class="formButton" type="submit" value="Search" title="Search" />
				</form>
 	</div>