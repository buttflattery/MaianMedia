		<div id="mm_main">
			<h2 class="title"><?php echo $tplDisplayData['ALBUM_TEXT']; ?> </h2>
			<?php echo $tplDisplayData['ALBUM_MESSAGE']; ?><br /><br />
			<?php echo $tplDisplayData['CHILDREN']; ?>
			<form method="post" action="<?php echo $tplDisplayData['FORM_ACTION']; ?>">
			<input type="hidden" name="process" value="1" />
			<input type="hidden" name="album" value="<?php echo $tplDisplayData['ALBUM_ID']; ?>" />
			<div id="album_name">
			  <b><?php echo $tplDisplayData['ARTIST']; ?></b><br />
        <?php echo $tplDisplayData['NAME']; ?><br /><br />
        [ <a href="<?php echo $tplDisplayData['ADD_URL']; ?>" title="<?php echo $tplDisplayData['ADD_ALL']; ?>"><?php echo $tplDisplayData['ADD_ALL']; ?></a> ] <?php echo $tplDisplayData['DISCOUNT']; ?><?php echo $tplDisplayData['IMG_INLINE_STYLE']; ?>
			</div>
			
			<p class="button_align"><input class="formButton" type="submit" value="<?php echo $tplDisplayData['ADD_TO_CART']; ?>" title="<?php echo $tplDisplayData['ADD_TO_CART']; ?>" />&nbsp;&nbsp;&nbsp;&nbsp;<input class="formButton" type="button" value="<?php echo $tplDisplayData['CANCEL']; ?>" title="<?php echo $tplDisplayData['CANCEL']; ?>" onclick="window.location='<?php echo $tplDisplayData['URL']; ?>'" /></p>
			
			<div id="tracks">
				<table width="100%" cellspacing="0" cellpadding="0">
					<tr>
        				<th align="left" width="35%" ><b><?php echo $tplDisplayData['TRACK_NAME']; ?></b></th>
       					<th align="left" width="15%"><b><?php echo $tplDisplayData['TRACK_COST']; ?></b></th>
        				<th align="left" width="25%"><b><?php echo $tplDisplayData['TRACK_OPTIONS']; ?></b></th>
      				</tr>
			  		<?php echo $tplDisplayData['ALBUM_DATA']; ?>
			  	</table>
			</div>
			<p class="button_align"><input class="formButton" type="submit" value="<?php echo $tplDisplayData['ADD_TO_CART']; ?>" title="<?php echo $tplDisplayData['ADD_TO_CART']; ?>" />&nbsp;&nbsp;&nbsp;&nbsp;<input class="formButton" type="button" value="<?php echo $tplDisplayData['CANCEL']; ?>" title="<?php echo $tplDisplayData['CANCEL']; ?>" onclick="window.location='<?php echo $tplDisplayData['URL']; ?>'" /></p>
      <p class="hits"><?php echo $tplDisplayData['HITS']; ?></p>
      </form>		
    </div>
