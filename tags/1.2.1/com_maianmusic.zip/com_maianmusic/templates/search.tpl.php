  
  <div id="mm_main" style="height:450px">
      <h2 class="title"><?php echo $tplDisplayData['SEARCH_TEXT']; ?> </h2>
			<?php echo $tplDisplayData['SEARCH_MESSAGE']; ?><br /><br />
			<?php echo $tplDisplayData['SEARCH_DATA']; ?>
			<?php echo $tplDisplayData['PAGE_NUMBERS']; ?>
	</div>
