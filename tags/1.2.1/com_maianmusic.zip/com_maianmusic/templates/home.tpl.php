
<div id="mm_main">

<div id="home-message">   
	<?php echo $tplDisplayHome['HOME_MESSAGE'] ?>
</div>

<div id="popular-div">
<div id="most_popular">
	<div id="most_popular_tracks">
		<?php echo $tplDisplayHome['MOST_POPULAR_TRACKS'] ?>  
	</div>
	<div id="most_popular_albums">
		<?php echo $tplDisplayHome['MOST_POPULAR_ALBUMS'] ?>
	</div>
</div>
			
<div id="most_popular_tracks_list">
	<ul class="popular">
		<?php echo $tplDisplayHome['MOST_POPULAR_TRACKS_LIST'] ?> 
	</ul>
</div>
<div id="most_popular_albums_list">
	<ul class="popular">
		<?php echo $tplDisplayHome['MOST_POPULAR_ALBUMS_LIST'] ?> 
	</ul>
</div>
</div>

</div>


