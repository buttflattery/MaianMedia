More info about the GreyBox here:
http://orangoo.com/labs/GreyBox/
