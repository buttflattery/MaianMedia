<?php
/**
* Joomla Main Music 
* @package MaiainMusic
* @copyright (C) 2008 Are Times 
* @license Released under GNU/GPL License: http://www.gnu.org/copyleft/gpl.html
* @link http://www.aretimes.com
* @author Arelowo Alao & David Ian Bennett
* 
* Based on Maian Music v1.2
* @copyright (C) 2008 Maiain Script World All Rights Reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.maianscriptworld.co.uk
* @author David Ian Bennett
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

// ensure user has access to this function
global $_VERSION;

$version = substr( $_VERSION->getShortVersion(), 0, 3 );

switch ( $version ){
	case '1.5':
		$user = & JFactory::getUser();
		if (!$user->authorize( 'com_languages', 'manage' )) {
			$mainframe->redirect( 'index.php', JText::_('ALERTNOTAUTH') );
		}
    break;
    
    default:
		if (!($acl->acl_check( 'administration', 'edit', 'users', $my->usertype, 'components', 'all' )
  			| $acl->acl_check( 'administration', 'edit', 'users', $my->usertype, 'components', 'com_maianmusic' ))) {
  		mosRedirect( 'index2.php', _NOT_AUTH );

		}
     break;
}

// load .class.php and .html.php files for the component

require_once( $mainframe->getPath( 'admin_html' ) );

// Set paths..
define ('FOLDER_PATH', dirname(__FILE__).'/');
define ('RELATIVE_PATH', $mainframe->getCfg('absolute_path').'/components/com_maianmusic/');
define ('INC_FILES', 1);
define ('PER_PAGE', 25);
define ('ADD_TRACKS_TOTAL', 30);
define ('PARENT',1);

// Load include files..
include_once(RELATIVE_PATH.'inc/functions.php');
include_once(FOLDER_PATH.'admin_inc/functions.php');
include_once(FOLDER_PATH.'admin_classes/class_generic.inc.php');
include_once(FOLDER_PATH.'admin_classes/PaginateIt.php');
include_once(FOLDER_PATH.'admin_classes/class_music.inc.php');
include_once(FOLDER_PATH.'admin_classes/class_mail.inc.php');
include_once(FOLDER_PATH.'admin_classes/class_sales.inc.php');
include_once(RELATIVE_PATH.'classes/class_cart.inc.php');
// Initialise settings..

global $database, $SETTINGS;
$database->setQuery("SELECT * FROM #__mm_settings");
$database->loadObject($SETTINGS);

$SETTINGS->homepage_url = $mainframe->getCfg('live_site');
$SETTINGS->install_url = $mainframe->getCfg('live_site').'/components/com_maianmusic';
//$SETTINGS->install_url = $mainframe->getCfg('live_site');

// Load language file..
if($SETTINGS->language == ""){
	include_once(RELATIVE_PATH.'lang/english.php'); 

}else{
	include_once(RELATIVE_PATH.'lang/'.$SETTINGS->language); 
}

// Define variables..
global $mm_title , $page, $error_string, $count, $limit, $limitvalue, $search;
$mm_title         = $msg_script.' - '.$msg_header;
$page          = (isset($_GET['page']) ? strip_tags($_GET['page']) : '1');
$error_string  = array(); // Not used
$count         = 0;
$limit         = PER_PAGE;
$limitvalue    = $page * $limit - ($limit);
$search        = array();
 
// Initialise classes..
global $MM_MAIL, $MM_MUSIC, $MM_SALE, $MM_CART;

$MM_MAIL             = new mailClass();
$MM_MUSIC            = new musicDB();
$MM_SALE             = new sales();
$MM_CART             = new mm_Cart();
$MM_SALE->prefix     = $database->getPrefix().'mm_';
$MM_MUSIC->prefix    = $database->getPrefix().'mm_';
$MM_CART->prefix     = $database->getPrefix().'mm_';
$MM_MAIL->smtp       = $SETTINGS->smtp;
$MM_MAIL->smtp_host  = $SETTINGS->smtp_host;
$MM_MAIL->smtp_user  = $SETTINGS->smtp_user;
$MM_MAIL->smtp_pass  = $SETTINGS->smtp_pass;
$MM_MAIL->smtp_port  = $SETTINGS->smtp_port;
$MM_MAIL->addTag('{WEBSITE_NAME}',$SETTINGS->website_name);
$MM_MAIL->addTag('{WEBSITE_URL}',$mosConfig_live_site);
$MM_MAIL->addTag('{WEBSITE_EMAIL}',$SETTINGS->email_address);
$task   = trim( mosGetParam( $_REQUEST, 'section', '' ));
// Main switch..
switch ($task)
{
  // Home..
  case 'home': 
  HTML_maianmusic::show_Home();
  break;
  
   
  // Settings..
  case 'settings':

  if (isset($_POST['process']))
  {

    // Trim post vars..
    $_POST = array_map('trim',$_POST);
    include(FOLDER_PATH.'admin_classes/class_settings.inc.php');

    global $MM_SETTINGS;
    $MM_SETTINGS          = new SETTINGS();
    //$MM_SETTINGS->prefix  = '#__mm_';

    // Update SETTINGS..
    $MM_SETTINGS->update($_POST);

    // Reset album hits..
    if (isset($_POST['reset'])) {
      $MM_SETTINGS->resetAllAlbumHits();
    }
    header("Location: index2.php?option=com_maianmusic&section=settings");
    exit;
  }
  HTML_maianmusic::show_Settings();	
  break;

  // Manage Albums..
  case 'albums':

  // Add/Edit..
  if (isset($_POST['process'])){
    // Trim post vars..
    $_POST = array_map('trim',$_POST);

    // Add/Edit album..
    if ($_POST['name']) {
      if (isset($_POST['id']))
      {
        $MM_MUSIC->edit_album($_POST);
        
        // Reset tracks..
        if (isset($_POST['reset'])) {
          $MM_MUSIC->resetTracksDownloadCountInAlbum($_POST['id']);
        }

      } else {
      	$MM_MUSIC->add_album($_POST);
      }
    }
    header("Location: index2.php?option=com_maianmusic&section=albums".(isset($_POST['id']) ? '&id='.$_POST['id'] : '')."");

    exit;

  }

  // Delete..
  if (isset($_GET['del']))

  {
    $MM_MUSIC->clear_data($_GET['del']);
    header("Location: index2.php?option=com_maianmusic&section=albums");
    exit; 
  }

  HTML_maianmusic::show_Manage_Albums();
  break;

  // Add Tracks
  case 'add':

  // Process..
  if (isset($_POST['process'])){

    // Reload..
    if ($_POST['total']==0) {
      header("Location: index2.php?option=com_maianmusic&section=add");
      exit;
    }

    // Adjust count..
    $count = $_POST['total'];

    // Add tracks..
    if (isset($_POST['add'])) {

      $run = $MM_MUSIC->add_tracks($_POST);

      if ($run>0) { 
        $DONE = true;
      }

    }

  }

  HTML_maianmusic::show_Add_Tracks();
  break;

  // Manage Tracks..
  case 'tracks':
	HTML_maianmusic::show_Manage_Tracks();
  break;

  // View/Update Tracks..
  case 'view_tracks':
  // Update track..
  if (isset($_POST['edit']))  {

    $MM_MUSIC->update_track($_POST);

    // Rebuild order index..
    // If a track was moved to another album, we need to rebuild the current album
    // and the one its being moved to..
    $MM_MUSIC->rebuild_order_index($_POST);
    
    // Set session var..
    $_SESSION['updated'] = '1';
    header("Location: index2.php?option=com_maianmusic&section=view_tracks&id=".$_POST['id']."");
    exit;
  }

  // Change order
  if (isset($_GET['up']) || isset($_GET['down'])){
  	
    $MM_MUSIC->change_order((isset($_GET['up']) ? 'up' : 'down'),(isset($_GET['up']) ? $_GET['up'] : $_GET['down']),$_GET['id']);
    header("Location: index2.php?option=com_maianmusic&section=view_tracks&id=".$_GET['id']."");
    exit;
  }

  // Delete track..
  if (isset($_GET['del'])){

    $MM_MUSIC->clear_track($_GET['del']);

    // Rebuild order index..
    // If a track was deleted, we need to rebuild and adjust the order by options..

    $MM_MUSIC->rebuild_order_index_delete($_GET['id']);
    header("Location: index2.php?option=com_maianmusic&section=view_tracks&id=".$_GET['id']."");
    exit; 
  }
	
  HTML_maianmusic::show_View_Tracks();

  break;

  // Stats..
  case 'stats':

  // Expand/Collapse all..
  if (isset($_GET['expand']) || isset($_GET['close'])) {

    if (isset($_GET['expand'])) {

      $_SESSION['expand_stats'] = '1';

    } else {

      unset($_SESSION['expand_stats']);

    }
    header("Location: index2.php?option=com_maianmusic&section=stats".(isset($_GET['order']) ? '&order='.$_GET['order'] : '')."");
    exit;
  }

  // Order by..
  if (isset($_GET['order']))
  {
    switch ($_GET['order']) {
      case 'hits_desc':      $sql = "ORDER BY hits DESC";       break;
      case 'hits_asc':       $sql = "ORDER BY hits";            break;
      case 'downloads_desc': $sql = "ORDER BY downloads DESC";  break;
      case 'downloads_asc':  $sql = "ORDER BY downloads";       break;
    }
  }

  HTML_maianmusic::show_Stats();
  break;

  // Sales..
  case 'sales':

  // View sale..

  if (isset($_GET['view']) || isset($_POST['view']))
  {
    // Reset downloads and re-send download link..
    if (isset($_GET['resend'])) {

      // Get paypal data..
      $paypal = $MM_CART->getCartData($_GET['resend']);

      // Assign mail vars..

      $MM_MAIL->addTag('{NAME}',$paypal->first_name.' '.$paypal->last_name);
      $MM_MAIL->addTag('{INVOICE}',$paypal->invoice);
      $MM_MAIL->addTag('{TRANS_ID}',$paypal->txn_id);
      $MM_MAIL->addTag('{TOTAL}',$paypal->gross);
      $MM_MAIL->addTag('{ALBUMS}',$MM_CART->purchasedItems('albums',$_GET['resend'],$msg_cart8));
      $MM_MAIL->addTag('{TRACKS}',$MM_CART->purchasedItems('tracks',$_GET['resend'],$msg_cart8));
      $MM_MAIL->addTag('{DOWNLOAD_LINK}',sefRelToAbs('index.php?option=com_maianmusic&section=download&code='.$paypal->download_code));

      // Reset downloads..
      $MM_CART->resetCartDownloads($_GET['resend']);

      // Send mail..
      $MM_MAIL->sendMail($paypal->first_name.' '.$paypal->last_name,
                         $paypal->email,
                         $SETTINGS->website_name,
                         $SETTINGS->email_address,
                         '['.$SETTINGS->website_name.'] '.$msg_ipn10,
                         $MM_MAIL->template(RELATIVE_PATH.'templates/email/paypal_thanks.txt'));
      $RESET = true;

    }

    HTML_maianmusic::show_Single_Sale();
    exit;
  }

  // Contact buyer..

  if (isset($_GET['contact']) || isset($_POST['contact']))
  {
    if (isset($_POST['process']))
    {
      // Trim post vars..
      $_POST = array_map('trim',$_POST);

      // Only process if subject and comments are included..
      if ($_POST['subject'] && $_POST['comments']){

        // Send mail..
        $MM_MAIL->sendMail($_POST['buyer'],
                           $_POST['email'],
                           $SETTINGS->website_name,
                           $SETTINGS->email_address,
                           $_POST['subject'],
                           $_POST['comments']);

        $SENT = true;
      }

    }

	HTML_maianmusic::show_Contact();
    exit;
  }

  // Delete selected sales..
  if (isset($_POST['process'])){
    if (!empty($_POST['sale']))
    {
      for ($i=0; $i<count($_POST['sale']); $i++)
      {
        // Split value..
        // [0] = Sale id
        // [1] = Cart Code
        $value = explode("##", $_POST['sale'][$i]);

        // Reset purchase counts for tracks and albums for this purchase..
        $MM_SALE->resetPurchaseCounts($value[1]);

        // Delete sale..
        $MM_SALE->deleteSale($value[0],$value[1]);
      }
    }

    // If the search post var is present, redirect to search results page using session vars set during search..

    if (isset($_POST['search'])) {

      header("Location: index2.php?option=com_maianmusic&section=".$_SESSION['search_query_string'][0].
                                    $_SESSION['search_query_string'][1].
                                    $_SESSION['search_query_string'][2].
                                    $_SESSION['search_query_string'][3].
                                    $_SESSION['search_query_string'][4].
                                    $_SESSION['search_query_string'][5]);

      exit;
    } else {

      header("Location: index2.php?option=com_maianmusic&section=sales");
      exit;
    }  
  }

  // Expand/Close all..
  if (isset($_GET['expand']) || isset($_GET['close'])) {
    if (isset($_GET['expand'])) {
      $_SESSION['expand_sales'] = '1';
    } else {
      unset($_SESSION['expand_sales']);
    }
    header("Location: index2.php?option=com_maianmusic&section=sales".(isset($_GET['order']) ? '&order='.$_GET['order'] : '').(isset($_GET['show']) ? '&show='.$_GET['show'] : '')."");
    exit;
  }

  // Order by..
  if (isset($_GET['order'])){

    switch ($_GET['order']) {
      case 'date_desc':    $sql = "ORDER BY pay_date DESC";      break;
      case 'date_asc':     $sql = "ORDER BY pay_date";           break;
      case 'tracks':       $sql = "ORDER BY total_tracks DESC";  break;
      case 'downloads':    $sql = "ORDER BY total_albums DESC";  break;
      case 'gross_desc':   $sql = "ORDER BY gross DESC";         break;
      case 'gross_asc':    $sql = "ORDER BY gross";              break;
      case 'name_asc':     $sql = "ORDER BY first_name";         break;
      case 'name_desc':    $sql = "ORDER BY first_name DESC";    break;
    }
  }

  // Show per page..overwrites default..
  if (isset($_GET['show'])) {
    $limit       = $_GET['show'];
    $limitvalue  = $page * $limit - ($limit); 
  }

  
  HTML_maianmusic::show_Sales();
  break;

  // Search..
  case 'search':
global $SEARCH_RESULTS,$NO_RESULTS, $q_search;
  // Search database..
  if (isset($_GET['process'])){

    // Trim/clean post vars..
    $_GET = array_map('trim',$_GET);

    $sql_string = '';

    // From date if set..
    if ($_GET['from_day'] && $_GET['from_month'] && $_GET['from_year']) {
      $from_date = $_GET['from_year'].'-'.$_GET['from_month'].'-'.$_GET['from_day'];
    }

    // To date if set..

    if ($_GET['to_day'] && $_GET['to_month'] && $_GET['to_year']) {
      $to_date   = $_GET['to_year'].'-'.$_GET['to_month'].'-'.$_GET['to_day'];
    }

    // Assign data to search array..

    if ($_GET['name']) {
      $search[] = "first_name LIKE '%".mysql_real_escape_string($_GET['name'])."%' OR last_name LIKE '%".mysql_real_escape_string($_GET['name'])."%'";
    }

    if ($_GET['email']) {
      $search[] = "email LIKE '%".mysql_real_escape_string($_GET['email'])."%'";
    }

    if ($_GET['invoice']) {
      $search[] = "invoice = '".mysql_real_escape_string($_GET['invoice'])."'";
    }

    if ($_GET['txn_id']) {
      $search[] = "txn_id = '".mysql_real_escape_string($_GET['txn_id'])."'";
    }

    if (isset($from_date) && isset($to_date)) {
      $search[] = "pay_date BETWEEN '{$from_date}' AND '{$to_date}'";
    }

    // If the search array is empty, no search terms were entered..

    // So, redirect to search page..
    if (!empty($search)){

      // Build query string..
      for ($i=0; $i<count($search); $i++){

        $sql_string .= ($i ? 'OR '.$search[$i].' ' : 'WHERE (active_cart = \'1\') AND '.$search[$i].' ');
      }

      // Query database..
      $database->setQuery("SELECT *,DATE_FORMAT(pay_date,'%e %b %Y') AS p_date 

                               FROM #__mm_paypal 

                               $sql_string

                               LIMIT $limitvalue,$limit

                               ");
	$q_search = $database->loadObjectList();
                            
	
      if (count($q_search)>0) {
        $SEARCH_RESULTS  = true;

        // Assign session vars for directing back to search results after processing..
        // Sneaky, but effective..

        $_SESSION['search_query_string']    = array();
        $_SESSION['search_query_string'][]  = 'section=search&process=1&name='.$_GET['name'];
        $_SESSION['search_query_string'][]  = '&email='.$_GET['email'];
        $_SESSION['search_query_string'][]  = '&invoice='.$_GET['invoice'];
        $_SESSION['search_query_string'][]  = '&txn_id='.$_GET['txn_id'];
        $_SESSION['search_query_string'][]  = '&from_day='.$_GET['from_day'].'&from_month='.$_GET['from_month'].'&from_year='.$_GET['from_year'];
        $_SESSION['search_query_string'][]  = '&to_day='.$_GET['to_day'].'&to_month='.$_GET['to_month'].'&to_year='.$_GET['to_year'];

      } else {
        $NO_RESULTS      = true;
      }                      

    }

    else

    {

      header("Location: index2.php?option=com_maianmusic&section=search");

      exit;

    }

    

  }

  

  HTML_maianmusic::show_SearchSales();
  break;
  
  default:
	header("Location: index2.php?option=com_maianmusic&section=home");
	break;
}

?>