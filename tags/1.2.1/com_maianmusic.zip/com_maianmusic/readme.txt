Welcome to MAIAN MUSIC.
------------------------------------

Thank you for downloading the latest version of Maian Music, a free mp3 music store system released
under the 'Creative Commons Attribution 2.5 Licence. This script is free to use for both commercial and 
non-commercial purposes provided you link back to maianscriptworld.co.uk. See the following for more
information:

http://www.maianscriptworld.co.uk/licence.html


Installation:
----------------------------

For installation instructions, information, frequently asked questions and support,
please open the following url (located in the .zip you downloaded) in your browser:


docs/setup/index.html


I hope you enjoy your new music system.

David Ian Bennett

---------------------------------------------------------------
Maian Music. Copyright � David Ian Bennett. All Rights Reserved.

Maian Script World
http://www.maianscriptworld.co.uk
