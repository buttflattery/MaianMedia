<?php
// no direct access
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class HTML_maianmusic{ 


	function show_Home()
	{
		include_once(FOLDER_PATH.'admin_inc/adminheader.php');
  		include_once(FOLDER_PATH.'data_files/home.php');
  		include_once(FOLDER_PATH.'admin_inc/adminfooter.php');
	}
	
	function show_Settings()
	{
		include_once(FOLDER_PATH.'admin_inc/adminheader.php');
		include_once(FOLDER_PATH.'data_files/settings.php');
  		include_once(FOLDER_PATH.'admin_inc/adminfooter.php');
	}
	
	function show_Manage_Albums()
	{
		include_once(FOLDER_PATH.'admin_inc/adminheader.php');
  		include_once(FOLDER_PATH.'data_files/albums.php');
  		include_once(FOLDER_PATH.'admin_inc/adminfooter.php');
	}
	
	function show_Add_Tracks()
	{
		include(FOLDER_PATH.'admin_inc/adminheader.php');
  		include(FOLDER_PATH.'data_files/add.php');
		include(FOLDER_PATH.'admin_inc/adminfooter.php');
	}
	
	function show_Manage_Tracks()
	{
		include(FOLDER_PATH.'admin_inc/adminheader.php');
  		include(FOLDER_PATH.'data_files/tracks.php');
		include(FOLDER_PATH.'admin_inc/adminfooter.php');
	}
	
	function show_View_Tracks()
	{
		include(FOLDER_PATH.'admin_inc/adminheader.php');
  		include(FOLDER_PATH.'data_files/view_tracks.php');
  		include(FOLDER_PATH.'admin_inc/adminfooter.php');
	}
	
	function show_Single_Sale()
	{
		include(FOLDER_PATH.'data_files/popup/view_sale.php');
	}
	
	function show_Sales()
	{
		include(FOLDER_PATH.'admin_inc/adminheader.php');
  		include(FOLDER_PATH.'data_files/sales.php');
  		include(FOLDER_PATH.'admin_inc/adminfooter.php');
	}
	
 	function show_SearchSales()
	{
		include(FOLDER_PATH.'admin_inc/adminheader.php');
  		include(FOLDER_PATH.'data_files/search.php');
		include(FOLDER_PATH.'admin_inc/adminfooter.php');
	}

 	function show_Stats()
	{
		include(FOLDER_PATH.'admin_inc/adminheader.php');
  		include(FOLDER_PATH.'data_files/statistics.php');
  		include(FOLDER_PATH.'admin_inc/adminfooter.php');
	}
	
	function show_Contact()
	{
		include(FOLDER_PATH.'data_files/popup/contact_buyer.php');
	}
}
?>