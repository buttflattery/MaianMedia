<?php


class mp3players {

function getplayer($mp3, $path, $skin, $id) {
	global $mosConfig_absolute_path, $mosConfig_live_site;
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);
	$mp3Url = $path;
	
	if($mp3 <= 5){
		$mp3 = 0;
	}
	
switch ($mp3) {
	
	case 0: 
	//player.swf
	//$path = $thisParams[0];
	
	$text = '	
	<script type="text/javascript" src="'.$mosConfig_live_site .'/components/com_maianmusic/players/swfobject.js"></script>
		      <div id="playerMini'.$id.'">
           Flash Player
          </div>

          <script type="text/javascript">
            var so = new SWFObject("'.$mosConfig_live_site .'/components/com_maianmusic/players/playerMini.swf", "mymovie", "75", "30", "7", "#FFFFFF");
            so.addVariable("autoPlay", "no");
            so.addVariable("overColor","#40ACC7");
            so.addVariable("soundPath", "'.$mp3Url.'");
            so.addVariable("playerSkin","'.$skin.'");
            so.write("playerMini'.$id.'");
          </script>';
	
	
	return $text;
		break;	

	case 6: 
	//dewplayer.swf	+ volume
	//$path = $thisParams[0];
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);
	$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/components/com_maianmusic/players/dewplayer-vol.swf?son='. $mp3Url .'" width="240" height="20" style="a:active, a:focus {outline: 0};">  
	<param name="movie" value="'. $mosConfig_live_site .'/components/com_maianmusic/players/dewplayer-vol.swf?son='. $mp3Url .'" />
	</object>
	';
	return $text;
		break;
		
	case 7: 
	//dewplayer.swf	standard
	//$path = $thisParams[0];
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);
	$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/components/com_maianmusic/players/dewplayer.swf?son='. $mp3Url .'" width="200" height="20" style="a:active, a:focus {outline: 0};">  
	<param name="movie" value="'. $mosConfig_live_site .'/components/com_maianmusic/players/dewplayer.swf?son='. $mp3Url .'" />
	</object>
	';
	return $text;
		break;	

	case 8: 
	//dewplayer.swf	mini
	//$path = $thisParams[0];
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);
	$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/components/com_maianmusic/players/dewplayer-mini.swf?son='. $mp3Url .'" width="150" height="20" style="a:active, a:focus {outline: 0};">  
	<param name="movie" value="'. $mosConfig_live_site .'/components/com_maianmusic/players/dewplayer-mini.swf?son='. $mp3Url .'" />
	</object>
	';
	return $text;
		break;			

	case 7: 
	//FLASHPLAYER.swf	
	//$path = $thisParams[0];
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);	
	$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/components/com_maianmusic/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" width="150" height="20" style="a:active, a:focus {outline: 0};">  
	<param name="movie" value="'. $mosConfig_live_site .'/components/com_maianmusic/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" />
	</object>
	';
	return $text;
	break;
	
	case 8: 
	//FLASHPLAYER.swf	
	//$path = $thisParams[0];
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);	
	$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/components/com_maianmusic/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" width="150" height="20" style="a:active, a:focus {outline: 0};">  
	<param name="movie" value="'. $mosConfig_live_site .'/components/com_maianmusic/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" />
	</object>
	';
	return $text;	
	break;
	
	case 9: 
	//FLASHPLAYER.swf	
	//$path = $thisParams[0];
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);	
	$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/components/com_maianmusic/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" width="25" height="20" style="a:active, a:focus {outline: 0};">  
	<param name="movie" value="'. $mosConfig_live_site .'/components/com_maianmusic/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" />
	</object>
	';
	$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/mambots/mbox/mbox_plugin/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" width="150" height="20" style="a:active, a:focus {outline: 0};">  
	<param name="movie" value="'. $mosConfig_live_site .'/mambots/mbox/mbox_plugin/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" />
	</object>
	';
	return $text;	
	break;
	
	case 10: 
	//FLASHPLAYER.swf	
	//$path = $thisParams[0];
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);	
	$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/components/com_maianmusic/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&songVolume=90" width="50" height="20" style="a:active, a:focus {outline: 0};">  
	<param name="movie" value="'. $mosConfig_live_site .'/components/com_maianmusic/players/singlemp3player.swf?file='. $mp3Url .'&backColor=ffffff&frontColor=1a1a1a&showDownload=false&trueVolume=90" />
	</object>
	';
	return $text;		
	break;	
	
	case 11: 
	//FLASHPLAYER2.swf	
	//$path = $thisParams[0];
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);	
	$text = '<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/components/com_maianmusic/players/player_mp3.swf?mp3='. $mp3Url .'&amp;showstop=1" width="150" height="20" style="a:active, a:focus {outline: 0};">  
	<param name="movie" value="'. $mosConfig_live_site .'/components/com_maianmusic/players/player_mp3.swf?mp3='. $mp3Url .'&amp;showstop=1" />
	<param name="wmode" value="transparent" />
	</object>
	';
	return $text;
	break;
	
	case 12: 
	//player.swf
	//$path = $thisParams[0];
	//$mp3Url = (ereg("^http", $path) ? $path : $mosConfig_live_site .'/'. $path);
	$text = '
	<object type="application/x-shockwave-flash" data="'. $mosConfig_live_site .'/components/com_maianmusic/players/player.swf?file='. $mp3Url .'&showdownload=false" width="200" height="20" style="a:active, a:focus {outline: 0};">  	
	<param name="movie" value="'. $mosConfig_live_site .'/components/com_maianmusic/players/player.swf?file='. $mp3Url .'&showdownload=false" />
	</object>
	';
	return $text;
		break;	
	
	}
}
	
}
?>