<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: footer.php
  Description: Public Footer

  +++++++++++++++++++++++++++++++++++++++++++++*/
  
if (!defined('PARENT')) {
  exit;
}  
$tplDisplayFooter = array();
$tplDisplayFooter['FOOTER1'] = $msg_script;
$tplDisplayFooter['FOOTER2'] = $msgDisplayFooter;
$tplDisplayFooter['FOOTER3'] = $msgDisplayFooter2;
$tplDisplayFooter['NO_SCRIPT'] = $msgDisplayFooter3;
?>
