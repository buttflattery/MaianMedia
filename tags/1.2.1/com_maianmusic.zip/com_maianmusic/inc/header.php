<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: header.php
  Description: Public Header

  +++++++++++++++++++++++++++++++++++++++++++++*/
  
if (!defined('PARENT')) {
  exit;
}   
global $SETTINGS, $MM_CART,
$mosConfig_live_site,
$msg_public_header2,
$msg_public_header3,
$msg_public_header6,
$msg_public_header7,
$msg_public_header4,
$msg_public_header5,
$msg_public_header8,
$msg_public_header9,
$msg_public_header13,
$msg_public_header12,
$msg_public_header,
$meta_keys,
$msg_public_header10,
$title,
$msg_public_header14;
$tplDisplayFront=array();

$tplDisplayFront['TITLE']=$title;
$tplDisplayFront['STORE_NAME']=str_replace("{website}",cleanData($SETTINGS->website_name),$msg_public_header);
$tplDisplayFront['META_DESC']=$msg_public_header13;
$tplDisplayFront['META_KEYS']=(isset($meta_keys) ? $meta_keys : $msg_public_header14);
$tplDisplayFront['FEED_URL']=sefRelToAbs('index.php?option=com_maianmusic&section=rss');
$tplDisplayFront['FORM_LOAD']= (isset($cartOnLoad) ? ' onload="document.form.submit()"' : '');
$tplDisplayFront['CART_COUNT']= ($MM_CART->cartCount()>0 ? '<a href="'.sefRelToAbs('index.php?option=com_maianmusic&section=view-cart').'" class="cart_count_link">'.$MM_CART->cartCount().'</a>' : $MM_CART->cartCount());
$tplDisplayFront['CART_TOTAL']= get_cur_symbol($MM_CART->cartTotal(), $SETTINGS->paypal_currency);
$tplDisplayFront['ITEMS_IN_CART']=$msg_public_header2;
$tplDisplayFront['HOMEPAGE']=$msg_public_header3;
$tplDisplayFront['ARTISTS']=$msg_public_header4;
$tplDisplayFront['CONTACT']=$msg_public_header5;
$tplDisplayFront['ABOUT']=$msg_public_header6;
$tplDisplayFront['SEARCH']=$msg_public_header7;
$tplDisplayFront['LICENCE']= $msg_public_header12;
$tplDisplayFront['KEYWORDS']=$msg_public_header8;
$tplDisplayFront['KEY_VALUE']=isset($_GET['keywords']) ? cleanData($_GET['keywords']) : '';
$tplDisplayFront['H_URL']=sefRelToAbs('index.php?option=com_maianmusic&section=home');
$tplDisplayFront['A_URL']=sefRelToAbs('index.php?option=com_maianmusic&section=music');
$tplDisplayFront['C_URL']=sefRelToAbs('index.php?option=com_maianmusic&section=contact');
$tplDisplayFront['P_URL']=sefRelToAbs('index.php?option=com_maianmusic&section=about');
$tplDisplayFront['L_URL']=sefRelToAbs('index.php?option=com_maianmusic&section=licence');
$tplDisplayFront['PB_JUKEBOX']= $msg_public_header9;
$tplDisplayFront['PB_MESSAGE']=$msg_public_header10;
?>
