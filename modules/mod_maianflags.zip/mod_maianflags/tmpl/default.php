<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); 
?>
<div id="territories">
	<div id="territoryList">
	<ul>
		<?php echo $flags ?>
	</ul>
	</div>
</div>