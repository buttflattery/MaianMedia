<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: footer.php
  Description: Public Footer

  +++++++++++++++++++++++++++++++++++++++++++++*/
  
defined('_JEXEC') or die('Restricted access'); 


$tplDisplayFooter = array();
$tplDisplayFooter['FOOTER1'] = JText::_(_msg_script);
$tplDisplayFooter['FOOTER2'] = JText::_('_msgDisplayFooter');
$tplDisplayFooter['FOOTER3'] = JText::_('_msgDisplayFooter2');
$tplDisplayFooter['NO_SCRIPT'] = JText::_('_msgDisplayFooter3');
?>
