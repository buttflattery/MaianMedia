		<div id="mText"><?php echo $tplDisplayData['MUSIC_TEXT']; ?></div>
		<h2 class="title"><?php echo $tplDisplayData['MUSIC_TITLE']; ?></h2>
			<br /><?php echo $tplDisplayData['MUSIC_MESSAGE']; ?><br/><br/>
			<div id="music_data" style="<?php echo $tplDisplayData['STYLING']; ?>"><?php echo $tplDisplayData['MUSIC_DATA']; ?></div>
			<?php echo $tplDisplayData['PAGE_NUMBERS']; ?>
