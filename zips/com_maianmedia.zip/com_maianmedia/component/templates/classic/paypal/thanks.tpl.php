      <h2 class="title"><?php echo $tplDisplayData['THANKS_TEXT']; ?></h2>
			<?php echo $tplDisplayData['THANKS_MESSAGE']; ?><br /><br />
			<?php echo $tplDisplayData['DOWNLOAD_MESSAGE']; ?>
