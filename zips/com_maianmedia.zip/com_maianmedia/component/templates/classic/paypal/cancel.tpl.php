      <h2 class="title"><?php echo $tplDisplayData['CANCEL_TEXT']; ?></h2>
			<?php echo $tplDisplayData['CANCEL_MESSAGE']; ?><br /><br />
