      <h2 class="title"><?php echo $tplDisplayData['ERROR_TEXT']; ?></h2>
			<?php echo $tplDisplayData['ERROR_MESSAGE']; ?><br /><br />
