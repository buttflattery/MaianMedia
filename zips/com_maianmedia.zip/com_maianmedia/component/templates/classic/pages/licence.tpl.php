    <h2 class="title"><?php echo $tplDisplayData['LICENCE_TEXT']; ?> </h2>
		<?php echo $tplDisplayData['LICENCE']; ?>