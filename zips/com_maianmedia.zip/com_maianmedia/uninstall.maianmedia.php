<?
/**
 * @package		Joomla
 * @subpackage	com_maianmedia
 * @copyright	Copyright (C) AreTimes & Maian Script World. All rights reserved.
 * @license		GNU/GPL
 * @author 		Arelowo Alao (aretimes.com) & David Bennet (maianscriptworld.co.uk)
 * Joomla! and Maian Music are free software. You must attribute the work in the manner
 * specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

function com_uninstall() {

	echo '<p>Thank you for trying Maian Music for Joomla</p>';
	echo '';
}

?>