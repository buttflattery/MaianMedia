<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php

/*++++++++++++++++++++++++++++++++++++++++

  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk
  Intergration: http://www.aretimes.com

  ++++++++++++++++++++++++++++++++++++++++
  */

$db =& JFactory::getDBO();
include_once(JPATH_COMPONENT.DS.'functions'.DS.'functions.php');

//I guess getUserStateFromRequest is for session or different reasons
$lim   = $mainframe->getUserStateFromRequest("com_maianmedia.limit", 'limit', 5, 'int'); 
$lim0  = JRequest::getVar('limitstart', 0, '', 'int');
jimport('joomla.html.pagination');
$pageNav = new JPagination(JRequest::getVar('pagnation'), $lim0, $lim );
$catGroup = $this->categories;
?>
<form action="index.php" method="post" name="adminForm">
  <div id="editcell">
		<p><b><?php echo JText::_( _msg_header10); ?></b> <br><br>
    <?php echo JText::_(_msg_categories_desc); ?></p>
    <table class="adminlist" width="100%" cellspacing="1" cellpadding="0">
    <thead>
    	<tr>
      		<th>#</th>
      		<th width="20">
				<input type="checkbox" onclick="checkAll(<?php echo count($catGroup); ?>);" value="" name="toggle" />
			</th>
			<th width="8%" nowrap="nowrap">
				<?php 	$image = JHTML::_('image.administrator',  'filesave.png', '/images/', NULL, NULL, JText::_( 'Save Order' ) );
						$href = '<a href="javascript:saveorder('.(count( $catGroup ) -1).', \'saveOrder\')" title="'.JText::_( 'Save Order' ).'">'.$image.'</a>';
							echo JText::_(_msg_tableh4).' '.$href;?>
			</th>
			<th><?php echo JText::_(_msg_tableh1); ?></th>
			<th><?php echo JText::_(_msg_tableh3); ?></th>
			<th><?php echo JText::_(_msg_tableh2); ?></th>
			<th>ID</th>
    	</tr>
    </thead>
    <?php
    if (count($catGroup) > 0)
    {

	$k = 0;
	for ($i=0; $i<count($catGroup); $i++){
		$row = &$catGroup[$i];
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_maianmedia&view=category&controller=category&task=edit&cid[]='. $row->id );
		?>
		<tr class="<?php echo "row$k"; ?>">
			<td width="2%">
				<?php echo $lim0+$i+1; ?>
			</td>
			<td width="2%">
				<?php echo $checked; ?>
			</td>
			<td class="order">
					<input type="text" name="order[]" size="5" value="<?php echo $row->ordering; ?>" <?php echo $disabled ?> class="text_area" style="text-align: center" />
			</td>
			<td>
				<a href="<?php echo $link; ?>"><?php echo $row->title; ?></a>
			</td>
			<td>
				<?php echo $row->alias; ?>
			</td>
			<td width="10%" class="title" align="center"><img height="16" border="0" style="cursor:pointer;" width="16" alt="<?php echo ($row->published == 0) ? JText::_('UNPUBLISHED') : JText::_('PUBLISHED'); ?>" src="images/<?php echo ($row->published == 1) ? 'tick' : 'publish_x';?>.png" onclick="javascript:$$('.inputs').removeProperty('checked');$('cb<?php echo $i ?>').checked='checked';isChecked($('cb<?php echo $i ?>').checked);submitbutton('<?php echo ($row->published == 1) ? 'un' : '';?>publish_cat');" /></td>
			<td width="2%">
				<?php echo $row->id; ?>
			</td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
			<tfoot>
			<tr>
				<td colspan="15">
					<?php echo $pageNav->getListFooter(); ?>
				</td>
			</tr>
			</tfoot>

    <?php
    } else {
    ?>  
    <tr >
      <td colspan=8 align="center" style="padding:10px 0 10px 0;border-top:1px solid #40ABC6"><?php echo JText::_(_msg_categories2); ?></td>
    </tr>
    <?php
    }
    ?>
    </table>
	</div>
<input type="hidden" name="option" value="com_maianmedia" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="1" />
<input type="hidden" name="controller" value="category" />
</form>