<?php
/**
 * Hello View for Hello World Component
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );

/**
 * Settings View
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianViewTrack extends JView
{
	/**
	 * display method of settings view
	 * @return void
	 **/
	function display($tpl = null)
	{

		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__m15_settings Limit 1");
		$settings = $db->loadObject();

		if(JRequest::getVar('task') == 'edit'){
			JToolBarHelper::save('update_tracks'  , 	'save' );
		}else{
			JToolBarHelper::save();
		}

		if(JRequest::getVar('task') == 'add'){
			JToolBarHelper::title(   JText::_(_msg_header5), 'add.png' );
		}else{
			JToolBarHelper::title(   JText::_(_msg_header6), 'tracks.png' );
			//JToolBarHelper::deleteList(JText::_(_msg_javascript15), "remove", "Delete");
		}

		JToolBarHelper::cancel();

		if(JRequest::getVar('cid')) {
			$id = JRequest::getVar('cid');
				
			// Query database for paypal information..
			$db->setQuery("SELECT * FROM #__m15_tracks
                             WHERE track_album = '".$id."'
                             ORDER BY track_order");

			$tracks = $db->loadObjectList();
			$this->assignRef('tracks', $tracks);
			$this->assignRef('settings', $settings);
		}

		jimport('joomla.filesystem.file');
		$authFile = JPATH_COMPONENT.DS.'functions'.DS.'auth.php';
		$data = JFile::read($authFile);

		JPath::setPermissions($authFile, '0755');

		if($data === false){
			JError::raiseNotice( 100, 'Warning: '.JPATH_COMPONENT.DS.'functions'.DS.'auth.php must be readable for the uploader to work' );
		}else{
			$ret = file_put_contents($authFile, $data);

			if($ret === false){
				JError::raiseNotice( 100, 'Warning: '.JPATH_COMPONENT.DS.'functions'.DS.'auth.php must be writable for the uploader to work' );
			}
		}

		if(!JFolder::exists($settings->mp3_path)){
			JError::raiseNotice( 100, 'Warning: '.str_replace  ('{PATH}',$settings->mp3_path,_msg_tracks11));
		}

		if(!JFolder::exists(JPATH_SITE.$settings->preview_path)){
			JError::raiseNotice( 100, 'Warning: '.str_replace  ('{PATH}',JPATH_SITE.$settings->preview_path,_msg_tracks11));
		}

		if($settings->mp3_path == ''){
			JError::raiseNotice( 100, 'Warning: '.str_replace  ('{PATH}',JPATH_SITE.$settings->mp3_path,_msg_tracks11));
		}
		if($settings->preview_path == ''){
			JError::raiseNotice( 100, 'Warning: '.str_replace  ('{PATH}',JPATH_SITE.$settings->preview_path,_msg_tracks11));
		}

		parent::display($tpl);
	}
	
	function getLang(){
		//$lang =& JFactory::getLanguage();
		//$joomlaLang = $lang->get('tag');


		$db =& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__m15_settings Limit 1");

		$settings = $db->loadObject();

		switch ($settings->language) {
			case 'english.php':
				return 'en';
				break;
			case 'spanish.php':
				return 'es';
				break;
			case 'french.php':
				return 'fr';
				break;
			case 'german.php':
				return 'de';
				break;
			case 'swedish.php':
				return 'se';
				break;
			case 'finnish.php':
				return 'fi';
				break;
			case 'czech.php':
				return 'cs';
				break;
			case 'danish.php':
				return 'da';
				break;
			default:
				return 'en';
		}
	}
	
function endecrypt ($pwd, $data, $case='') {
	if ($case == 'de') {
		$data = urldecode($data);
	}

	$key[] = "";
	$box[] = "";
	$temp_swap = "";
	$pwd_length = 0;

	$pwd_length = strlen($pwd);

	for ($i = 0; $i <= 255; $i++) {
		$key[$i] = ord(substr($pwd, ($i % $pwd_length), 1));
		$box[$i] = $i;
	}

	$x = 0;

	for ($i = 0; $i <= 255; $i++) {
		$x = ($x + $box[$i] + $key[$i]) % 256;
		$temp_swap = $box[$i];

		$box[$i] = $box[$x];
		$box[$x] = $temp_swap;
	}

	$temp = "";
	$k = "";

	$cipherby = "";
	$cipher = "";

	$a = 0;
	$j = 0;

	for ($i = 0; $i < strlen($data); $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;

		$temp = $box[$a];
		$box[$a] = $box[$j];

		$box[$j] = $temp;

		$k = $box[(($box[$a] + $box[$j]) % 256)];
		$cipherby = ord(substr($data, $i, 1)) ^ $k;

		$cipher .= chr($cipherby);
	}

	if ($case == 'de') {
		$cipher = urldecode(urlencode($cipher));

	} else {
		$cipher = urlencode($cipher);
	}

	return $cipher;
}
	
	function setValuesjs(){
		echo '
		<script type="text/javascript">
			
			function Select_Value_Set(SelectName, Value) {
		  		eval(\'SelectObject = document.\' +     SelectName + \';\');
		  		for(index = 0; index < SelectObject.length; index++) {
		   			if(SelectObject[index].value == Value){
		     			SelectObject.selectedIndex = index;
		     		}
		   		}
		   }
		
		 	function setText(field_ID, myValue){	
		 		eval(\'SelectObject = document.\' +field_ID + \';\');
		 		SelectObject.value = myValue.split(\' \').join(\'_\');
		 	}
		 	      
		   
		   function Select_Values() {
		
		  		for(i = 0; i < document.adminForm.total.value; i++) {
		  			//alert(\'adminForm.populate_\'+index+" "+document.adminForm.total.value);
		   			Select_Value_Set(\'adminForm.populate_\'+i, document.adminForm.album.value);
		   		}   
			}
			
		</script>


';
	}

	function sortablejs(){
		$uri =& JURI::getInstance();
		echo '<style type = "text/css">
                 ul#sortable-list{
                 list-style:none;
                 padding:0px;
                 margin:0px}
                  ul#sortable-list li{ list-style:none;
                  }
                  #output{font:bold 10px verdana}
              </style>
			<script type="text/javascript">
			
			function getInputsById(tag) {
				var elem = document.getElementsByTagName("input");
				var arr = new Array();
				for (i = 0, iarr = 0; i < elem.length; i++) {
					att = elem[i].getAttribute("id");
					if(att == tag) {
						arr[iarr] = elem[i];
						iarr++;
					}
				}
				return arr;
			}
			
				/* when the DOM is ready */
				window.addEvent(\'domready\', function() {
				
					/* create sortables */
					var sb = new Sortables(\'sortable-list\', {
						/* set options */
			
						clone: true,
						opacity: \'0\',
						handles: \'.handle\',
			
						revert: {
				    		//accepts Fx options
							duration: 500, transition: \'elastic:out\'
						},
						/* initialization stuff here */
						initialize: function() { 
							
						},
						
						onSort: function(el) {
							//passes element you are dragging
							//el.highlight(\'#FFFFFF\');
						},
						
						/* once an item is selected */
						onStart: function(el) { 
							//passes element you are dragging
							//el.highlight(\'#FFFFFF\');
						
						},
						/* when a drag is complete */
						onComplete: function(el) {
							var arr = document.getElementsByTagName("legend");
							var singleArr = getInputsById("track_single");
							var freeArr = getInputsById("freebie");
			
							for (i=0; i<arr.length;i++) {
								x= i+1;
								arr[i].innerHTML="Track "+x;
								singleArr[i].setAttribute("name","track_single_"+i);
								freeArr[i].setAttribute("name","freebie_"+i);
							}//end for
							
						}
					});
				});
			
				</script>
			
			<script type="text/javascript">
			
			 function removeTrack(id)
			 {
					var answer = confirm("'.JText::_(_msg_javascript21).'","'.JText::_(_msg_script2).'","'.JText::_(_msg_script3).'");
			 		if (answer){
						var el = $(\'item_\'+id);
						MTFade (el, \'opacity\',0);
						ajaxRequest(\'item_\'+id, \'index.php?option=com_maianmedia&format=raw&controller=tracks&task=removeTrack&deleteThis=\'+id, 0);
						window.setTimeout(\'runChange()\', 1000);
			 		}
			 		
			 }
			
			 function MTFade (div,prop,val) {
						new Fx.Style(div, prop, {duration: 250} ).start(val);
			 }
			 
			 function runChange()
			 {
			 	var arr = document.getElementsByTagName("legend");
				
				for (i=0; i<arr.length;i++) {
					x= i+1;
					arr[i].innerHTML="Track "+x+"<img class=\'toggle_track\' src=\''.$uri->base().'components/com_maianmedia/images/expand.png\'/>";
			
				}//end for
				
			 }
			
			function expandAll(count){
			
				for (id=0; id<count;id++){
					var row = document.getElementById("albumRow_"+id);
					row.style.display = "";
				
					var row = document.getElementById("mp3Row_"+id);
					row.style.display = "";
				
					var row = document.getElementById("previewRow_"+id);
					row.style.display = "";
				
					var row = document.getElementById("otherRow_"+id);
					row.style.display = "";
					
					var row = document.getElementById("keywordRow_"+id);
					row.style.display = "";
					
				}// end for
			
			}
			
			function collapseAll(count){
			
				for (id=0; id<count;id++){
					var row = document.getElementById("albumRow_"+id);
					row.style.display = \'none\';
				
					var row = document.getElementById("mp3Row_"+id);
					row.style.display = \'none\';
				
					var row = document.getElementById("previewRow_"+id);
					row.style.display = \'none\';
				
					var row = document.getElementById("otherRow_"+id);
					row.style.display = \'none\';
					
					var row = document.getElementById("keywordRow_"+id);
					row.style.display = \'none\';
					
				}// for
			}
			 
			function displayRow(id){
			
				var row = document.getElementById("albumRow_"+id);
			
				if (row.style.display == "") row.style.display = \'none\';
			
				else row.style.display = "";
				
				var row = document.getElementById("mp3Row_"+id);
			
				if (row.style.display == "") row.style.display = \'none\';
			
				else row.style.display = "";
				
				var row = document.getElementById("previewRow_"+id);
			
				if (row.style.display == "") row.style.display = \'none\';
			
				else row.style.display = "";
				
				var row = document.getElementById("otherRow_"+id);
			
				if (row.style.display == "") row.style.display = \'none\';
			
				else row.style.display = "";
				
				var row = document.getElementById("keywordRow_"+id);
			
				if (row.style.display == "") row.style.display = \'none\';
			
				else row.style.display = "";
			}
			 
			</script>';
	}
}
