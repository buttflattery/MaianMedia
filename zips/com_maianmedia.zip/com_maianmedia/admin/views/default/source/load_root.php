<?php
defined('_JEXEC') or die('Restricted access');

include_once(JPATH_COMPONENT.DS.'functions'.DS.'common.php');

$path=realpath($_GET['abs_path']);
$root=array(
	array(
		'property' => array(
			'name' => basename($path)
		),
		'type' => 'folder',
		'data' => array(
			'abs_path' => $path
		)
	)
);

echo json_safe_encode($root);
?>