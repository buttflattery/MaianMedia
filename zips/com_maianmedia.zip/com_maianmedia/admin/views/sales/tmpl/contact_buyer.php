<?php
/*++++++++++++++++++++++++++++++++++++++++
  Script: Maian Music v1.2
  Written by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Website: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++
  This File: contact_buyer.php
  Description: Contact Buyer
  ++++++++++++++++++++++++++++++++++++++++*/$db =& JFactory::getDBO();
$db->setQuery("SELECT * FROM #__m15_paypal
                       WHERE id = '".(isset($_GET['id']) ? $_GET['id'] : $_POST['id'])."'
                       LIMIT 1
                       ");
$BUYER = $db->loadObject();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr" id="minwidth" >
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title></title>
<link href="stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="pop">
<form method="post" action="index.php?option=com_maianmedia&controller=sales&format=raw&task=contact">
<input type="hidden" name="process" value="1">
<input type="hidden" name="contact" value="<?php echo $BUYER->id; ?>">
<input type="hidden" name="email" value="<?php echo $BUYER->email; ?>">
<input type="hidden" name="buyer" value="<?php echo cleanData($BUYER->first_name.' '.$BUYER->last_name); ?>">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
    <td align="left" style="padding:5px">
    <?php
    if (isset($this->SENT))
    {
    ?>
    <div style="display:block;text-align:center;color:#FF7700;font-weight:bold;letter-spacing:1px;margin:5px 0 10px 0"><?php echo JText::_( _msg_sales27); ?></div>
    <?php
    }
    ?>
    <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
        <td align="left" style="padding:5px"><span style="display:block;margin-bottom:3px"><b><?php echo JText::_( _msg_sales24); ?></b>:</span>
        <input class="formBox" type="text" name="subject" maxlength="250" size="30" value="<?php echo (isset($_POST['subject']) ? cleanData($_POST['subject']) : ''); ?>"></td>
    </tr>
    <tr>
      <td align="left" style="padding:5px"><span style="display:block;margin-bottom:3px"><b><?php echo JText::_( _msg_sales25); ?></b>:</span>
      <textarea name="comments" rows="8" cols="40" style="width:98%"><?php echo (isset($_POST['comments']) ? cleanData($_POST['comments']) : ''); ?></textarea><br />
      </td>
    </tr>
    <tr>
        <td align="left" style="padding:5px">
        <input class="formButton" type="submit" value="<?php echo JText::_( _msg_sales28); ?>" title="<?php echo JText::_( _msg_sales28); ?>"><br><br>
        <?php echo str_replace("{email}",$BUYER->email,JText::_( _msg_sales26)); ?>
        </td>
    </tr>
    </table>
    </td>
</tr>
</table>
</form>
</div>    
</body>
</html>
