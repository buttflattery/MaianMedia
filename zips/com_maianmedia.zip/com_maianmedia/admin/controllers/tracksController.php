<?php
/**
 * @package		Joomla
 * @subpackage	com_maianmedia
 * @copyright	Copyright (C) Vamba & Matthew Thomson. All rights reserved.
 * @license		GNU/GPL
 * @author 		Arelowo Alao (aretimes.com) & David Bennet (maianscriptworld.co.uk)
 * @based on  	com_ignitegallery
 * @author 		Matthew Thomson (ignitejoomlaextensions.com)
 * Joomla! and Maian Music are free software. You must attribute the work in the manner
 * specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 */
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * Hello World Component Controller
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class MaianControllerTracks extends MaianControllerDefault
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		//$this->registerTask( 'add'  , 	'edit' );
	}

	/* save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('Tracks');
		$start = JRequest::getVar('limitstart');

		if ($model->store($post)) {
			$msg = JText::_( JText::_(str_replace("{count}",$model->tracksAdded,_msg_add13)) );
		} else {
			$msg = JText::_( 'There was an error saving these tracks' );
		}

		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_maianmedia&controller=tracks&view=tracks&limitstart='.$start;
		$this->setRedirect($link, $msg);
	}

	/* save a record (and redirect to main page)
	 * @return void
	 */
	function update_tracks()
	{
		$model = $this->getModel('Tracks');

		if ($model->update($post)) {
			$msg = JText::_( 'Tracks Updated!' );
		} else {
			$msg = JText::_( 'There was an error saving these tracks' );
		}

		$start = JRequest::getVar('limitstart');
		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_maianmedia&controller=tracks&view=tracks&limitstart='.$start;
		$this->setRedirect($link, $msg);
	}

	function edit()
	{
		JRequest::setVar( 'view', 'track' );
		JRequest::setVar( 'layout', 'view_tracks'  );
		//JRequest::setVar('hidemainmenu', 0);

		// Register Extra tasks
		//$this->registerTask( 'save'  , 	'update_track' );

		parent::display();
	}
	function cancel()
	{
		$msg = JText::_(_msg_op_cancel);
		$start = JRequest::getVar('limitstart');
		$this->setRedirect( 'index.php?option=com_maianmedia&controller=tracks&view=tracks&limitstart='.$start, $msg );
	}

	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		// loading view for this task
		JRequest::setVar( 'view', 'tracks' );
		parent::display();
	}

	function removeTrack()
	{
		$db =& JFactory::getDBO();
		$cid = JRequest::getVar('deleteThis');

		$db->setQuery("SELECT track_album FROM #__m15_tracks WHERE id=$cid");
		$album_id = $db->LoadObject();

		$db->setQuery("DELETE FROM #__m15_tracks WHERE id=$cid");
		$db->query();

		$db->setQuery("SELECT id FROM #__m15_tracks WHERE track_album=$album_id->track_album ORDER BY track_order");
		$list = $db->loadObjectList();

		$i = 1;
		foreach ($list AS $TRACK){
			$db->SetQuery("UPDATE #__m15_tracks SET track_order=$i WHERE id=".$TRACK->id);
			$i++;
		}


		//$this->setRedirect( 'index.php?option=com_maianmedia&controller=tracks&amp;task=edit&amp;view=track&amp;cid=&'.$album, $msg );

	}

	function add()
	{
		JRequest::setVar( 'view', 'track' );
		JRequest::setVar( 'layout', 'default');
		JRequest::setVar('hidemainmenu', 1);
			
		parent::display();

	}

	function manager(){
		include(JPATH_COMPONENT.DS.'functions'.DS.'FileManager.php');

		$db =& JFactory::getDBO();

		$db->setQuery("Select * from #__m15_settings Limit 1");
		$settings = $db->loadObject();

		if($type == '0'){
			$dest = $settings->mp3_path;
		}else{
			$dest = JPATH_SITE.$settings->preview_path;
		}

		$browser = new FileManager(array(
			'directory' => $dest,
			'assetBasePath' => 'components/com_maianmedia/images/managerAssets',
			'upload' => true,
			'destroy' =>true,			
		));

		$browser->fireEvent(!empty($_GET['event']) ? $_GET['event'] : null);
	}

	function getTracks()
	{
		jimport( 'joomla.environment.uri' );

		$numOf = JRequest::getVar('arrayElements');

		$uri =& JURI::getInstance();
		$root_url = $uri->root(); //root url
		$root_base = $uri->base(); //base url
		$root_current = $uri->current(); //current url pathj

		JRequest::setVar( 'view', 'track' );
		JRequest::setVar( 'layout', 'table'  );
		JRequest::setVar( 'type', 'track' );

		require_once(JPATH_COMPONENT.DS.'views'.DS.'track'.DS.'tmpl'.DS.'table.php');

	}

	function move_file(){
		$upload = JRequest::getVar('uploadTrack_');
		$filename = JRequest::getVar('filename');
		$type = JRequest::getVar('checked');
		$subFolder = JRequest::getVar('sub_folder_');
		$subFolder = str_replace(" ","_",$subFolder );

		$db =& JFactory::getDBO();

		$db->setQuery("Select * from #__m15_settings Limit 1");
		$settings = $db->loadObject();
		//Retrieve file details from uploaded file, sent from upload form
		//$file = JRequest::getVar('file_upload', null, 'files', 'array');

		//Import filesystem libraries. Perhaps not necessary, but does not hurt
		jimport('joomla.filesystem.file');

		//Clean up filename to get rid of strange characters like spaces etc
		$filename = JFile::makeSafe($filename);

		//Set up the source and destination of the file
		if($type == '0'){
			$dest = $settings->mp3_path;
		}else{

			$dest = JPATH_SITE.$settings->preview_path;


		}

		$dest = str_replace("\\","//",$dest);

		$src = JPATH_COMPONENT.DS."uploader".DS."tmp".DS.$filename;

		//First check if the folder from settings exist
		if ( JFolder::exists($dest)) {

			if(!JFolder::exists($dest.DS.$subFolder)){
				JFolder::create($dest.DS.$subFolder);
				$dest = $dest.DS.$subFolder.DS.str_replace(" ","_",$filename);
			}else{
				$dest = $dest.DS.str_replace(" ","_",$filename);
			}

			if (JFile::copy($src, $dest)){

				echo '<input id=\'subId\' type=\'hidden\' value=\'30\'value=\''.$subFolder.'\' />';
				echo '<input id=\'inputPath\' type=\'hidden\' value=\'30\'value=\''.$type.'\' />';
			} else {
				jimport( 'joomla.error.error' );
				$errors = JError::getErrors();
				echo '<div class=\'sucErr\'><div>'.JText::_(_msg_tracks12).'</div><br><div>'.$errors.'</div></div>';
			}
		} else {
			echo '<div class=\'sucErr\'>'.JText::_(str_replace("{PATH}",$dest,_msg_tracks11)).'</div>';
		}

		JFile::delete($src);
	}

	function endecrypt ($pwd, $data, $case='') {
		if ($case == 'de') {
			$data = urldecode($data);
		}

		$key[] = "";
		$box[] = "";
		$temp_swap = "";
		$pwd_length = 0;

		$pwd_length = strlen($pwd);

		for ($i = 0; $i <= 255; $i++) {
			$key[$i] = ord(substr($pwd, ($i % $pwd_length), 1));
			$box[$i] = $i;
		}

		$x = 0;

		for ($i = 0; $i <= 255; $i++) {
			$x = ($x + $box[$i] + $key[$i]) % 256;
			$temp_swap = $box[$i];

			$box[$i] = $box[$x];
			$box[$x] = $temp_swap;
		}

		$temp = "";
		$k = "";

		$cipherby = "";
		$cipher = "";

		$a = 0;
		$j = 0;

		for ($i = 0; $i < strlen($data); $i++) {
			$a = ($a + 1) % 256;
			$j = ($j + $box[$a]) % 256;

			$temp = $box[$a];
			$box[$a] = $box[$j];

			$box[$j] = $temp;

			$k = $box[(($box[$a] + $box[$j]) % 256)];
			$cipherby = ord(substr($data, $i, 1)) ^ $k;

			$cipher .= chr($cipherby);
		}

		if ($case == 'de') {
			$cipher = urldecode(urlencode($cipher));

		} else {
			$cipher = urlencode($cipher);
		}

		return $cipher;
	}

	function updateHash($sessionid, $data){

		$md5loc = strpos($data, '$md5=');
		$header = substr($data,0,$md5loc+5);
		$header = $header.'\''.$sessionid."';?>";

		return $header;
	}

	function uploaderjs(){
		jimport('joomla.filesystem.file');

		$merge = '$merge';
		$session = & JFactory::getSession();

		$user =& JFactory::getUser();

		$md5 =md5($user->password);

		$authFile = JPATH_COMPONENT.DS.'functions'.DS.'auth.php';
		JPath::setPermissions($authFile, '0755');
		$data = JFile::read($authFile);
		
		$sess = $session->getId();
		
		$data = $this->updateHash($md5, $data);
		$data = JFile::write($authFile,$data);
			
		$session = $this->endecrypt($md5,$session->getId());
		$sessionid = str_replace('%','-per-',$session);
		$sessionid = str_replace('.','-dot-',$sessionid);

		$filesize = str_replace('M','',ini_get("upload_max_filesize"));
		$output = "
			FileManager.implement({
				
				options: {
					resizeImages: true,
					upload: true,
					uploadAuthData: {session : '".$sessionid."'}
				},
				
				hooks: {
					show: {
						upload: function(){
							this.startUpload();
						}
					},
					
					cleanup: {
						upload: function(){
							if(!this.options.upload || !this.upload) return;
							
							if(this.upload.uploader) this.upload.uploader.set('opacity', 0).dispose();
						}
					}
				},
				
				onDialogOpen: function(){
					if(this.swf && this.swf.box) this.swf.box.setStyle('visibility', 'hidden');
				},
				
				onDialogClose: function(){
					if(this.swf && this.swf.box) this.swf.box.setStyle('visibility', 'visible');
				},
				
				startUpload: function(){
					if(!this.options.upload || this.swf) return;
					
					var self = this;
					this.upload = {
						button: this.addMenuButton('upload').addEvents({
							click: function(){
								return false;
							},
							mouseenter: function(){
								this.addClass('hover');
							},
							mouseleave: function(){
								this.removeClass('hover');
								this.blur();
							},
							mousedown: function(){
								this.focus();
							}
						}),
						list: new Element('ul', {'class': 'filemanager-uploader-list'}),
						uploader: new Element('div', {opacity: 0}).adopt(
							new Element('h2', {text: this.language.upload}),
							new Element('div', {'class': 'filemanager-uploader'})
						)
					};
					this.upload.uploader.getElement('div').adopt(this.upload.list);
					this.closeIcon.appearOn(this.upload.button, 0.8);
					
					if(this.options.resizeImages){
						var resizer = new Element('div', {'class': 'checkbox'}),
							check = (function(){ this.toggleClass('checkboxChecked'); }).bind(resizer);
						check();
						this.upload.label = new Element('label').adopt(
							resizer, new Element('span', {text: this.language.resizeImages})
						).addEvent('click', check).inject(this.menu);
					}
					
					var File = new Class({
			
						Extends: Swiff.Uploader.File,
						
						initialize: function(base, data){
							this.parent(base, data);
							this.setOptions({
								url: self.options.url+'&session=".$sessionid."&'+Hash.toQueryString($merge({}, self.options.uploadAuthData, {
									event: 'upload',
									directory: self.normalize(self.Directory),
									resize: self.options.resizeImages && resizer.hasClass('checkboxChecked') ? 1 : 0
								}))
							});
						},
						
						render: function(){
							if(this.invalid){
								var message = self.language.uploader.unknown, sub = {
									name: this.name,
									size: Swiff.Uploader.formatUnit(this.size, 'b')
								};
								
								if(self.language.uploader[this.validationError])
									message = self.language.uploader[this.validationError];
								
								if(this.validationError=='sizeLimitMin')
										sub.size_min = Swiff.Uploader.formatUnit(this.base.options.fileSizeMin, 'b');
								else if(this.validationError=='sizeLimitMax')
										sub.size_max = Swiff.Uploader.formatUnit(this.base.options.fileSizeMax, 'b');
								
								new Dialog(new Element('div', {html: message.substitute(sub, /\\?\$\{([^{}]+)\}/g)}) , {language: {confirm: self.language.ok}, buttons: ['confirm']});
								return this;
							}
							
							this.addEvents({
								open: this.onOpen,
								remove: this.onRemove,
								requeue: this.onRequeue,
								progress: this.onProgress,
								stop: this.onStop,
								complete: this.onComplete
							});
							
							this.ui = {};
							this.ui.icon = new Asset.image(self.options.assetBasePath+'Icons/'+this.extension+'.png', {
								onerror: function(){ new Asset.image(self.options.assetBasePath+'Icons/default.png').replaces(this); }
							});
							this.ui.element = new Element('li', {'class': 'file', id: 'file-' + this.id});
							this.ui.title = new Element('span', {'class': 'file-title', text: this.name});
							this.ui.size = new Element('span', {'class': 'file-size', text: Swiff.Uploader.formatUnit(this.size, 'b')});
							
							var tips, file = this;
							this.ui.cancel = new Asset.image(self.options.assetBasePath+'cancel.png', {'class': 'file-cancel', title: self.language.cancel}).addEvent('click', function(){
								file.remove();
								tips.hide();
								tips.detach(this);
							});
							tips = new FileManager.Tips(this.ui.cancel);
							
							var progress = new Element('img', {'class': 'file-progress', src: self.options.assetBasePath+'bar.gif'});
			
							this.ui.element.adopt(
								this.ui.cancel,
								progress,
								this.ui.icon,
								this.ui.title,
								this.ui.size
							).inject(self.upload.list).highlight();
							
							this.ui.progress = new Fx.ProgressBar(progress).set(0);
										
							this.base.reposition();
			
							return this.parent();
						},
			
						onOpen: function(){
							this.ui.element.addClass('file-running');
						},
			
						onRemove: function(){
							this.ui = this.ui.element.destroy();
						},
			
						onProgress: function(){
							this.ui.progress.start(this.progress.percentLoaded);
						},
			
						onStop: function(){
							this.remove();
						},
						onComplete: function(){
							this.ui.progress = this.ui.progress.cancel().element.destroy();
							this.ui.cancel = this.ui.cancel.destroy();
							//alert(this.response.text);
							var response = JSON.decode(this.response.text);
							if(!response.status)
								new Dialog((''+response.error).substitute(self.language, /\\?\$\{([^{}]+)\}/g) , {language: {confirm: self.language.ok}, buttons: ['confirm']});
							
							this.ui.element.set('tween', {duration: 2000}).highlight(response.status ? '#e6efc2' : '#f0c2c2');
							(function(){
								this.ui.element.setStyle('overflow', 'hidden').morph({
									opacity: 0,
									height: 0
								}).get('morph').chain(function(){
									this.element.destroy();
									if(!self.upload.list.getElements('li').length)
										self.upload.uploader.fade(0).get('tween').chain(function(){
											self.fillInfo();
										});
								});
							}).delay(5000, this);
						}
			
					});
			
					this.swf = new Swiff.Uploader({
						id: 'SwiffFileManagerUpload',
						path: this.options.assetBasePath+'Swiff.Uploader.swf',
						allowScriptAccess: 'sameDomain',
						queued: false,
						target: this.upload.button,
						method: 'get',
						allowDuplicates: true,
						fileSizeMax: ".$filesize." * 1024 * 1024,
						instantStart: true,
						fileClass: File,
						onBrowse: function(){},
						onCancel: function(){},
						zIndex: this.SwiffZIndex || 9999,
						onSelectSuccess: function(){
							self.fillInfo();
							self.info.getElement('h2.filemanager-headline').setStyle('display', 'none');
							self.preview.adopt(self.upload.uploader);
							self.upload.uploader.fade(1);
						},
						onComplete: function(){
							self.load(self.Directory, true);
						},
						onFail: function(error){
							$$(self.upload.button, self.upload.label).dispose();
							new Dialog(new Element('div', {html: self.language.flash[error] || self.language.flash.flash}), {language: {confirm: self.language.ok}, buttons: ['confirm']});
						}
					});

				}
				
			});";
		echo $output;
	}

}