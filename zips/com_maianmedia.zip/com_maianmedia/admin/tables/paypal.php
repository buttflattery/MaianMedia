<?php
/**
 * Hello World table class
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Hello Table class
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class TablePaypal extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null; 	
	var $jos_id = null; 	  
	var $first_name = null;
	var $last_name 	= null;
	var $pay_date 	= null;
	var $address 	= null;
	var $email 	= null;
	var $memo 	 = null;
	var $payment_status = null;
	var $pending_reason = null;
	var $total = null;
	var $gross = null;
	var $fee = null;
	var $txn_id = null;
	var $invoice = null;	 	
	var $visits = null;
	var $download_code 	= null; 	
	var $cart_code 	= null;
	var $purchases 	= null;
	var $active_cart = null;
	var $total_tracks = null;
	var $total_albums = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TablePaypal(& $db) {
		parent::__construct('#__m15_paypal', 'id', $db);
	}
}