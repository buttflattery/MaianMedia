<?php
/**
 * Album table class
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class TableBakPages extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;
	var $name = null;
	var $text = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableBakPages(& $db) {
		parent::__construct('#__mbak_pages', 'id', $db);
	}
}
?>